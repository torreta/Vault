-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: localhost    Database: clean_pos
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `SequelizeMeta`
--

DROP TABLE IF EXISTS `SequelizeMeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `SequelizeMeta` (
  `name` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SequelizeMeta`
--

LOCK TABLES `SequelizeMeta` WRITE;
/*!40000 ALTER TABLE `SequelizeMeta` DISABLE KEYS */;
INSERT INTO `SequelizeMeta` VALUES ('20200409155253-create-dbo-discount-types.js'),('20200528154503-create-identifications-types.js'),('20200528154504-create-categories.js'),('20200528154505-create-product-price-type.js'),('20200528154505-create-tax.js'),('20200528154506-create-dbo-storage-subcategories.js'),('20200528154506-create-dbo-type-currency.js'),('20200528154507-create-currency.js'),('20200528154508-create-creditnote-reason.js'),('20200528154508-create-debitnote-reason.js'),('20200528154508-create-invoice-status-finance.js'),('20200528154508-create-invoice-status.js'),('20200528154508-create-transaction-status.js'),('20200528154509-create-cliente-price-type.js'),('20200528154510-create-rols.js'),('20200528154511-create-payment-type.js'),('20200528154512-create-banks.js'),('20200528154514-create-cash-register-close-status.js'),('20200528154522-create-cash-registers.js'),('20200529023824-create-my-company.js'),('20200529134125-create-exchange-rate.js'),('20200529141052-create-dbo-config-country.js'),('20200529141053-create-dbo-config-tax-withholding.js'),('20200529141054-create-clients.js'),('20200529141055-add-discount-types-id-in-clients.js'),('20200529142230-create-users.js'),('20200529143219-create-bank-payment-type.js'),('20200529144641-create-cash-register-start.js'),('20200529144642-create-dbo-pos-cash-register-end.js'),('20200529145147-create-dbo-daily-close.js'),('20200529145148-create-cash-register-close.js'),('20200529153135-create-cash-register-initiation.js'),('20200529165011-create-invoice.js'),('20200529192310-create-dbo-config-zone.js'),('20200529192312-create-company.js'),('20200529193310-create-products-status.js'),('20200529193311-create-product.js'),('20200529200234-create-payment.js'),('20200529231256-create-entry-type.js'),('20200529231602-create-location.js'),('20200529231834-create-cash-register-close-payment.js'),('20200529231834-create-transaction.js'),('20200529231835-create-inventory.js'),('20200529231835-create-transaction-item.js'),('20200529234716-create-inventory-history.js'),('20200530001120-create-withdraw-type.js'),('20200530001121-create-withdraw.js'),('20200530003636-create-cash-register-close-withdraws.js'),('20200530003637-create-invoices-item.js'),('20200601212414-create-dbo-finance-creditnotes-status.js'),('20200601212420-create-dbo-finance-creditnotes-type.js'),('20200601212429-create-dbo-finance-creditnotes.js'),('20200601212438-create-dbo-finance-creditnotes-items.js'),('20200601212444-create-dbo-finance-creditnotes-history.js'),('20200601213209-create-dbo-finance-debitnotes-status.js'),('20200601213219-create-dbo-finance-debitnotes-type.js'),('20200601213225-create-dbo-finance-debitnotes.js'),('20200601213237-create-dbo-finance-debitnotes-items.js'),('20200601213242-create-dbo-finance-debitnotes-history.js'),('20200602140343-create-dbo-storage-final-price-product.js'),('20200602145137-create-dbo-storage-product-subcategories.js'),('20200714170050-create-dbo-administration-invoices-items-prices.js'),('20200813163658-create-dbo-printer.js'),('20200813165748-create-dbo-printer-document-types.js'),('20200813172013-create-dbo-printer-current.js'),('20200813172421-create-dbo-printer-pending.js'),('20200813172506-create-dbo-printer-history.js'),('20200813172836-create-dbo-printer-invoices-items.js'),('20200813173103-create-dbo-printer-messages.js'),('20200813173125-create-dbo-printer-log.js'),('20200813173126-create-view-categories.js'),('20200817120336-create-view-users.js'),('20200817132521-create-view-payments.js'),('20200817132740-create-view-subcategories.js'),('20200817140342-create-view-price-types-client.js'),('20200817140903-create-view-banks.js'),('20200817142226-create-view-exchange_rate.js'),('20200817142645-create-view-locations.js'),('20200817145527-create-view-payment_types.js'),('20200817150026-create-view-inventories.js'),('20200817152326-create-view-price-types-product.js'),('20200817153306-create-view-companies.js'),('20200817154334-create-view-bank-payment-types.js'),('20200817154335-create-view-bank-payment-types -invoices.js'),('20200818044611-create-view-types-currencies.js'),('20200818091527-create-view-users-types.js'),('20200818092504-create-view-transactions.js'),('20200818093753-create-view-debitnote_types.js'),('20200818094516-create-view-taxes.js'),('20200818095533-create-view-creditnote_types.js'),('20200818103502-create-view-cash-registers.js'),('20200819094516-create-view-currencies.js'),('20200819153746-create-reason.js'),('20200819153805-create-refunds-status.js'),('20200819154208-create-refund.js'),('20200819165850-create-reason-items.js'),('20200819170038-create-refunds-items.js'),('20200824140019-create-view-products-solds.js'),('20200825213633-create-view_refunds.js'),('20200826173921-create-view-history-sold-purchase-products.js'),('20200903141107-create-dbo-administration-products-price-amount-history.js'),('20200903184924-create-preview-update-massive.js'),('20200921133630-create-dbo-config-currency-denomination.js'),('20200921144555-create-cash-register-end-detail.js'),('20200924164305-create-view-currency-denominations.js'),('20200930174344-create-dbo-pos-cash-register-electronic-end.js'),('20201007094514-create-view-changesGrid.js'),('20201007094516-create-view-paymentsGrid.js'),('20201007163841-create-dbo-administration-invoices-all-currencies.js'),('20201007163845-create-view-invoices.js'),('20201013174355-add-column-on-dbo-config-my-company.js'),('20201015125859-create-dbo-config-email.js'),('20201019153306-create-view-cash-register-closes.js'),('20201020161454-create-dbo-pos-cash-register-start-details.js'),('20201023163612-create-dbo-pos-cash-register-close-amount.js'),('20201029141640-create-dbo-finances-balances.js'),('20201029141645-create-dbo-finances-balances-histories.js'),('20201030171816-create-view-clients.js'),('20201111145037-view_creditsnotes.js'),('20201111152141-view_debitnotes.js'),('20201111184658-create-dbo-supplier-characteristic.js'),('20201111184856-create-dbo-supplier-characteristics-value.js'),('20201125133026-create-dbo-supplier-product-characteristics.js'),('20210708143209-create-dbo-pos-cash-register-daily.js'),('20210708143335-add_column_cash_register_daily_id_to_dbo_pos_cash_registers.js'),('20210804153251-create-dbo-pos-cash-register-bank-payment-type.js'),('20210901143331-create-dbo-pos-cash-register-all-currencies.js'),('20210901143331-create-view-product-price-bs.js'),('20210901143331-create-view-product-price-usd.js'),('20210901143331-create-view-totals-cash-bs.js'),('20210901143331-create-view-totals-cash-usd.js'),('20210901143331-create-view-totals-cash.js'),('20210901143332-create-index-unique-invoice-item.js'),('20210901143332-create-index-unique-product-inventory.js'),('20210901143332-create-trigger_quantity_inventory.js'),('20210901143332-create-trigger_reserve_inventory_update.js'),('20210901143332-create-trigger-fiscal-invoice.js'),('20210901143332-create-view-manage-prices.js'),('20210901143332-create-view-previewUpdatePrice.js'),('20210901143333-add-column-after-quantity-and-before-quantity-to-transaction-item.js'),('20210910161142-add-column-invoice-id-to-dbo-storage-transactions.js'),('20210916144832-create-dbo-administration-product-cost.js'),('20211004143056-add-column-exchange-rate-provider-to-transactions.js'),('20211006121722-add-column-cost-id-to-transaction-items.js'),('20211013060251-create-dbo-administration-creditdays.js'),('20211013060606-view_creditdays.js'),('20211013155848-add-column-credit-day-expire-date-delivery-date-to-transactions.js'),('20211013155848-create-view-manage-prices.js'),('20211013155848-create-view-paymentsGrid.js'),('20211015122707-create-dbo-administration-payment-expenses.js'),('20211018170616-replace-view-inventories.js'),('20211027142906-alter-colum-products-price-amounts.js'),('20211027170741-alter-column-product-price-amount-histories.js'),('20211027170915-alter-column-transactions.js'),('20211027170952-alter-column-transaction-items.js'),('20211027171029-alter-column-product-costs.js'),('20211027174624-create-view-product-subcategories.js'),('20211027174625-replace-view-inventories.js'),('20211109140258-create-dbo-accountancy-company-type.js'),('20211109140413-create-dbo-accountancy-clasification-type.js'),('20211109140557-create-dbo-accountancy-activity-type.js'),('20211109140636-create-dbo-accountancy-accounts.js'),('20211109180400-create-view-accountancy-account.js'),('20211110151605-create-dbo-accountancy-operation-totals.js'),('20211110151606-create-dbo-accountancy-operation.js'),('20211110184154-add-column-bank_payment_types-to-accountancy_account.js'),('20211111153404-add-column-dbo_config_companies-to-accountancy_account_id.js'),('20211116212752-create-dbo-accountancy-operation-type.js'),('20211116212753-add_column_to_accountancy_operations.js'),('20211116212753-create-view-operations.js'),('20211122184216-add_column_price_on_transaction_items.js'),('20211127141228-create-dbo-system-product-presentation.js'),('20211127142146-add_column_presentation_to_dbo_storage_products.js'),('20211208140514-create-dbo-pos-cash-register-global.js'),('20211208144225-create-dbo-pos-cash-register-global-history.js'),('20211221163914-create-dbo-finance-pay-type.js'),('20211221163915-create-dbo-finance-pay-to-clients.js'),('20211222163356-create_view_pay_to_clients.js'),('20211229145115-create-dbo-administration-my-company-account.js'),('20211229145219-create-dbo-administration-company-account.js'),('20211229155208-create_view_my_company_accounts.js'),('20220103192925-create-dbo-retention-operation-types.js'),('20220103194214-create-dbo-retention-document-types.js'),('20220103194445-create-dbo-retention-tax-types.js'),('20220103194640-retention_tax_codes.js'),('20220103195630-create-dbo-retention-tax-status.js'),('20220103195836-create-dbo-retention-tax-invoice.js'),('20220103210743-create-dbo-retention-tax-history.js'),('20220111134346-create_view_company_accounts.js'),('20220113143734-drop_columns_to_payment_expenses.js'),('20220113144622-add_columns_to_payment_expenses.js'),('20220114143322-create-dbo-storage-transaction-pay-status.js'),('20220114143901-add_columns_transction_to_payment_expenses.js'),('20220114162537-create_view_purchases.js'),('20220126230906-dbo_retention_tax_history.js'),('20220126231001-dbo_retention_tax_invoice.js'),('20220128143553-modify_view_accountancy_operations.js'),('20220128154907-create-dbo-storage-transaction-summary-validate.js'),('20220128155250-add_colum_to_transaction.js'),('20220209150059-add_column_to_dbo_storage_transaction_summary_validates.js'),('20220209155253-create-dbo-discount-types.js'),('20220215142817-create-dbo-configuration-accountancy-type.js'),('20220215142956-create-dbo-configuration-accountancy-operation-type.js'),('20220224170724-create-dbo-payment-exchange-rate-amount.js'),('20220225160906-add_column_to_accountancy_operations.js'),('20220225165748-create-dbo-finance-payment-expense-status.js'),('20220225165834-add_column_to_payment_expenses.js'),('20220302212255-dbo_retention_tax_invoice.js'),('20220303175038-add_column_to_accountancy_operations.js'),('20220303175039-create_view_to_payments_exoenses.js'),('20220307210402-create-selected-payment.js'),('20220307210403-create-view-selected-payments-grid.js'),('20220307210404-add_column_to_accountancy_operations.js'),('20220308163947-modify_view_accountancy_operations.js'),('20220308182830-add_column_converted_to_transactions.js'),('20220309202203-dbo_retention_tax_invoice.js'),('20220309210105-add_column_to_accountancy_operations.js'),('20220311160718-create-dbo-storage-brand.js'),('20220311160752-add_brand_to_products.js'),('20220312210118-add_column_reference_to_payment_expenses_and_prepayment.js'),('20220314155739-add_column_to_transactions.js'),('20220314202832-create_view_to_payments_exoenses_w_reference.js'),('20220315131458-add_column_advancedpayment_to_accountancy_operations.js'),('20220316215727-altercolumn__dbo_retention_tax_invoice_control_number.js'),('20220318234930-latest_replace_view_inventories.js'),('20220330143906-add_column_igtf_to_invoice.js'),('20220330144718-add_column_tax_product_to_taxes.js'),('20220407145744-add_column_discount_to_transactions.js'),('20220407145839-add_columns_initial_to_transaction_summary_validate.js'),('20220407162919-addcolumn_creditanddebitnot_to_transactions.js'),('20220407172250-add_column_discount_to_transaction_items.js'),('20220410105959-addcolumn_retention_number_config_mycompanies.js'),('20220411140325-add_column_width_papper_to_printers.js'),('20220412234512-new_view_transaction_retentions.js'),('20220419222847-fixed_view_selected_payments_grid.js'),('20220422151401-add_columm_observation_balance_history.js'),('20220426141307-add_tax_code_to_product_taxes.js'),('20220426154010-create-dbo-finance-balance-provider.js'),('20220426155145-create-dbo-finance-balance-provider-history.js'),('20220513224134-add_column_dbo_pos_daily_closes.js'),('20220524142352-add_culumn_company_bank_account_dbo_pos_withdraws.js'),('20220607192840-add_column_balance_to_payment_expenses.js'),('20220616152528-add_column_refunds_to_transaction.js'),('20220617155847-create-dbo-system-customedconfig.js'),('20220621142339-create-dbo-finance-bankstatements.js'),('20220622194921-create-dbo-finance-systemstatements.js'),('20220622222444-add_culumn_company_bank_account_dbo_pos_withdraws.js'),('20220630161222-budget_status.js'),('20220630161225-budget.js'),('20220630161233-budget_item.js'),('20220630161253-dbo_administration_budget_all_currencies.js'),('20220630161306-dbo_administration_budget_items_prices.js'),('20220630164750-create-index-unique-budget-item.js'),('20220630164809-add_column_igtf_to_budget.js'),('20220701151357-add_reference_column_company_bank_account_dbo_pos_withdraws.js'),('20220701154325-new_view_create_pay_to_clientes.js'),('20220713155021-addcosts_colum_dbo_administration_invoices_items_prices.js'),('20220713155031-addexchangerate_colum_dbo_administration_invoices_items.js'),('20220713155035-addexchangerate_colum_dbo_administration_invoices.js'),('20220713194926-addtotalcosts_colum_dbo_administration_invoices_items_prices.js'),('20220713194958-addtotalcosts_colum_dbo_administration_invoices_items.js'),('20220713195018-addtotalcosts_colum_dbo_administration_invoices.js'),('20220713195029-addtotalcosts_colum_dbo_administration_invoices_all_currencies.js'),('20220720171651-create-dbo-finance-payments-informal.js'),('20220720172135-create-dbo-administration-informal-providers.js'),('20220721163244-create-dbo-administration-massive-uploads-preparation.js'),('20220722003328-add_informal_payment_dbo_accounting_operations.js'),('20220729211456-create-dbo-administration-standinginvoices.js'),('20220803222932-modified_view_totals_cash.js'),('20220803223447-create_view_total_cash_usd_footer.js'),('20220803223644-create_view_total_cash_bs_footer.js'),('20220803223955-create_view_totals_cash_footer.js'),('20220811232713-add_column_transactions.js'),('20220815183545-add_columns_to_printers.js'),('20220818210608-add_column_informalpayments.js'),('20220906160118-add_column_create_retention_to_dbo_config_my_companies.js'),('20220914142714-create-dbo-storage-code-bar-product.js'),('20221026144708-create-dbo-administration-product-shortages.js'),('20221026145359-create-dbo-administration-product-shortage-histories.js'),('20221026145528-add-column-min-quantity-to-product-shrotage-on-my-company.js'),('20221103191957-create-dbo-system-notification-types.js'),('20221103192340-create-dbo-system-notifications.js'),('20221103193620-create-dbo-system-notification-user-statuses.js'),('20230221003332-create-dbo-accountancy-ledger-purchases.js'),('20230221003536-create-dbo-accountancy-ledger-sales.js'),('20230221003744-create-dbo-accountancy-ledger-sales-items.js'),('20230421194858-update_column_manufacture_id_dbo_storage_products.js'),('20230426182942-add_column_printer_id_on_cash_register_close.js'),('20230427151637-create-dbo-printer-ledger-pending.js'),('20230502191045-add-boolean-fiscal-categories-to-products.js'),('20230503202052-add-colum-printer-id-to-cash-register-close-daily.js'),('20230510154918-add-colum-user_printer_id_to_invoices.js'),('20230613134311-add_column_on_invoice.js'),('20230613140424-create-dbo-config-binnacle-actions.js'),('20230613140828-create-dbo-administration-binnacle.js'),('20231011195205-create-dbo-pos-cash-register-categories.js'),('20231016203118-add-column-filter-category-to-dbo_pos_cash_registers.js'),('20231018183729-create-dbo-administration-product-weight-unit.js'),('20231018193138-add_column_weight_unit_on_products.js'),('20231019155343-add_column_weight_on_inventories.js'),('20231019161422-add_column_weight_on_inventory_histories.js'),('20231019162640-add_column_weight_on_transaction_items.js'),('20231019211045-add-column-location_id-to-dbo_pos_cash_registers.js'),('20231020174514-add_column_weight_on_invoice_items.js'),('20231101162029-add_column_note_invoice_in_dbo_config_my_companies.js'),('20231107152012-add_column_weight_quantity_in_budgets.js'),('20231114165803-create-dbo-finance-standingpayments.js'),('20231114184938-add_exchange_rate_dbo_administration_standing_invoices.js'),('20231121183028-add_profit_percentage_column_to_administration_product_prices.js'),('20231127181841-add-column-to-preview-update-massive.js'),('20231201153704-add-column-converted-to-dbo_administration_budgets.js'),('20240105144551-create-dbo-printer-status-data.js'),('20240105145205-add-column-document_id-to-dbo_accountancy_ledger_sales.js'),('20240122200055-add-column-code_editable-to-dbo_storage_products.js'),('20240214140608-create-dbo-navigation-routes.js'),('20240214154705-create-dbo-settings-routes.js'),('20240311152211-create-dbo-storage-product-lot.js'),('20240311152434-create-dbo-storage-transaction-lot.js'),('20240311152556-create-dbo_system_user_roles.js'),('20240311172737-change-view-users.js'),('20240404172428-add-column-disabled-to-dbo_storage_product_lots.js'),('20240509143337-modify-view-invoices.js'),('20240524213554-create-dbo-administration-collection-type.js'),('20240524213621-create-dbo-finance-collection-accounts.js'),('20240524213622-create-dbo-finance-collection-payment-statuses.js'),('20240524213623-create-dbo-administration-collection-statuses.js'),('20240524213624-create-dbo-administration-collections.js'),('20240524213625-create-dbo-administration-collection-invoices.js'),('20240524213626-create-dbo-finance-collection-payments.js'),('20240531155915-alter_column_amount_on_dbo_administration_product_price_amount.js'),('20240617141940-create-dbo-finance-balance-collection-accounts.js'),('20240625172659-create-dbo-storage-active-ingredient.js'),('20240625172813-create-dbo-storage-product-active-ingredient.js'),('20240625211509-add_obseravation_on_dbo_pos_cash_register_electronic_ends.js'),('20240628130547-create-dbo-storage-shop.js'),('20240628131754-add_columns_on_dbo_storage_products.js'),('20240726195915-add-column-profit_percentage-to_dbo_storage_transaction_items.js'),('20240810173133-add-column-observation-to-dbo_administration_product_costs.js'),('20240814154325-create-dbo-storage-operations.js'),('20240814154413-create-dbo-storage-operation-items.js'),('20240816174905-add-column-show-to-dbo_pos_withdraw_types.js'),('20240826155053-create-dbo-finance-bank-mobile-payment.js'),('20240828152416-create-dbo-finance-payment-bank.js'),('20240902195608-add-column-storage_operation_item_id-to-dbo_storage_transaction_items.js'),('20240905144205-add-column-transaction_id-to-dbo_storage_operations.js'),('20240905171214-create-dbo-config-genders.js'),('20240905171248-add-column-email-and-gender-to-dbo_sales_clients.js'),('20240905173301-change-view_clients-with-email-and-gender-fields.js'),('20240905192825-add_column_on_clientes_bank_id.js');
/*!40000 ALTER TABLE `SequelizeMeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SequelizeSeeds`
--

DROP TABLE IF EXISTS `SequelizeSeeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `SequelizeSeeds` (
  `name` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SequelizeSeeds`
--

LOCK TABLES `SequelizeSeeds` WRITE;
/*!40000 ALTER TABLE `SequelizeSeeds` DISABLE KEYS */;
INSERT INTO `SequelizeSeeds` VALUES ('20200618141243-identificationsTypes.js'),('20200618141330-currencies.js'),('20200622161301-tax.js'),('20200622162111-exchange_rate.js'),('20200622164003-product_price_type.js'),('20200622164655-location.js'),('20200623010537-product_status.js'),('20200623011032-roles.js'),('20200623011754-type_currency.js'),('20200623011755-payments_types.js'),('20200623014148-cash_register.js'),('20200623014921-debitnote_type.js'),('20200623015232-debitnote_status.js'),('20200623015545-creditnote_status.js'),('20200623015856-creditnote_type.js'),('20200623023429-creditnoteitem_reason.js'),('20200623023441-debitnoteitem_reason.js'),('20200623160126-entry_type.js'),('20200623191239-transaction_status.js'),('20200623220234-client_price_type.js'),('20200630011413-banks.js'),('20200630011414-banks-payment-Type.js'),('20200630011414-defaultUser.js'),('20200630011415-invoicesStatus.js'),('20200630011416-invoicesFinanceStatus.js'),('20200630011430-tax_withholding.js'),('20200630011431-dbo_printes.js'),('20200630011431-withdraw-types.js'),('20200630011432-cash-register.js'),('20200630011432-dbo_printer_decument_type.js'),('20200820175752-reason.js'),('20200820181923-refund_status.js'),('20200921125453-dbo_config_currency_denomination.js'),('20200921125454-dbo-supplier-characteristics.js'),('20200921125455-dbo_supplier_characteristics-values.js'),('20200921125457-dbo-contries.js'),('20200921125457-dbo-zones.js'),('20210812134912-emailInitaition.js'),('20211013160634-dbo_discount_types.js'),('20211013160635-dbo_administration_creditdays.js'),('20211109141303-seed_dbo_accountancy_company_type.js'),('20211122142056-add_new_values_in_inventory_entry_types.js'),('20211127141305-seed_dbo_system_product_presentation.js'),('20211207190815-add_new_value_bank.js'),('20211208152512-dbo_pos_cash_register_global.js'),('20211216145937-dbo_accountancy_operation_type.js'),('20211221170529-dbo_finance_pay_type.js'),('20220103192939-retention_operations.js'),('20220103194305-retention_documents.js'),('20220103194453-retention_tax_types.js'),('20220103195720-retention_tax_status.js'),('20220114143348-dbo_storage_transaction_pay_status.js'),('20220126224201-dbo_retention_tax_codes.js'),('20220204153426-add_values_to_dbo_storage_inventory_entry_types.js'),('20220209143353-dbo_discount_types.js'),('20220210150947-add_status_to_dbo_storage_products_conditions.js'),('20220215144131-dbo_configuration_accountancy_types.js'),('20220225165901-dbo_finance_payment_expense_status.js'),('20220330144838-add_value_to_taxes.js'),('20220616144826-add-inventory-entry-types.js'),('20220617160629-dbo_system_customedconfigs.js'),('20220627220415-accounting_operations.js'),('20220628181245-add_parametrizable_flat_discount.js'),('20220630181808-dbo_administration_budget_statuses.js'),('20220711220415-accounting_operations-retentions.js'),('20220722213935-non_fiscal_note_configs.js'),('20220823192511-adaptableInventoryConfig.js'),('20220826171215-add_value_to_customedconfig.js'),('20220922145131-add_new_types_to_configuration_accountancy_types.js'),('20220922150002-add_values_to_configuration_accountancy_operation_types.js'),('20221004181108-newprinterdoctype.js'),('20221104155002-notification_types.js'),('20230421162246-add_value_to_dbo_system_customedconfigs.js'),('20230509151023-add_value_to_dbo_system_customedconfigs.js'),('20230523133643-add_users_defaults.js'),('20230613141933-initial_binnacle_values.js'),('20230613142049-add_value_on_dbo_system_customedconfigs.js'),('20230925140517-add_customedconfig_parameters.js'),('20231018183805-add_value_dbo_administration_product_weight_unit.js'),('20240122213113-add-costumedconfig-parameters-code-editable-on-products.js'),('20240214140625-default_value_navigation_route.js'),('20240214154827-default_value_setting_route.js'),('20240311140209-add_values_on_system_customerconfigs.js'),('20240311152644-add-system-user-roles.js'),('20240311175016-add-adminsis-user.js'),('20240311175245-associate-default-system-users-with-old-roles.js'),('20240312181915-add-costumedconfig-parameters-for-allow-system-roles.js'),('20240503184029-add-costumedconfig-parameters-for-hide-igtf-preview.js'),('20240527172854-add_collection_statuses.js'),('20240619023812-add_collection_payment_statuses.js'),('20240625173911-add_navigations_settings.js'),('20240628134049-dbo_storage_shops.js'),('20240628154531-add_navigations_settings.js'),('20240703135925-add-costumedconfig-parameters-for-exchange-rate-indexation.js'),('20240801141810-add-new-entry_type_id-to-dbo_storage_entry_types.js'),('20240826142341-add_navigations_settings.js'),('20240826160449-dbo_finance_bank_mobile_payment.js'),('20240828152618-dbo_finance_payment_bank.js'),('20240905171627-add-genders-to-dbo_config_genders.js'),('20240910130939-add_setting_routes.js');
/*!40000 ALTER TABLE `SequelizeSeeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cash_register_end_details`
--

DROP TABLE IF EXISTS `cash_register_end_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `cash_register_end_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cash_register_end_id` int NOT NULL,
  `dbo_config_currency_denomination_id` int NOT NULL,
  `quantity` int DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_register_end_id` (`cash_register_end_id`),
  KEY `dbo_config_currency_denomination_id` (`dbo_config_currency_denomination_id`),
  CONSTRAINT `cash_register_end_details_ibfk_1` FOREIGN KEY (`cash_register_end_id`) REFERENCES `dbo_pos_cash_register_ends` (`id`),
  CONSTRAINT `cash_register_end_details_ibfk_2` FOREIGN KEY (`dbo_config_currency_denomination_id`) REFERENCES `dbo_config_currency_denominations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cash_register_end_details`
--

LOCK TABLES `cash_register_end_details` WRITE;
/*!40000 ALTER TABLE `cash_register_end_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `cash_register_end_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_accountancy_accounts`
--

DROP TABLE IF EXISTS `dbo_accountancy_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_accountancy_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `company_type_id` int DEFAULT NULL,
  `clasification_type_id` int DEFAULT NULL,
  `activity_type_id` int DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `movement` tinyint(1) DEFAULT '0',
  `budget` tinyint(1) DEFAULT '0',
  `level` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `company_type_id` (`company_type_id`),
  KEY `clasification_type_id` (`clasification_type_id`),
  KEY `activity_type_id` (`activity_type_id`),
  CONSTRAINT `dbo_accountancy_accounts_ibfk_1` FOREIGN KEY (`company_type_id`) REFERENCES `dbo_accountancy_company_types` (`id`),
  CONSTRAINT `dbo_accountancy_accounts_ibfk_2` FOREIGN KEY (`clasification_type_id`) REFERENCES `dbo_accountancy_clasification_types` (`id`),
  CONSTRAINT `dbo_accountancy_accounts_ibfk_3` FOREIGN KEY (`activity_type_id`) REFERENCES `dbo_accountancy_activity_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_accountancy_accounts`
--

LOCK TABLES `dbo_accountancy_accounts` WRITE;
/*!40000 ALTER TABLE `dbo_accountancy_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_accountancy_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_accountancy_activity_types`
--

DROP TABLE IF EXISTS `dbo_accountancy_activity_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_accountancy_activity_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `short` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_accountancy_activity_types`
--

LOCK TABLES `dbo_accountancy_activity_types` WRITE;
/*!40000 ALTER TABLE `dbo_accountancy_activity_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_accountancy_activity_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_accountancy_clasification_types`
--

DROP TABLE IF EXISTS `dbo_accountancy_clasification_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_accountancy_clasification_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `short` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_accountancy_clasification_types`
--

LOCK TABLES `dbo_accountancy_clasification_types` WRITE;
/*!40000 ALTER TABLE `dbo_accountancy_clasification_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_accountancy_clasification_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_accountancy_company_types`
--

DROP TABLE IF EXISTS `dbo_accountancy_company_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_accountancy_company_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `short` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_accountancy_company_types`
--

LOCK TABLES `dbo_accountancy_company_types` WRITE;
/*!40000 ALTER TABLE `dbo_accountancy_company_types` DISABLE KEYS */;
INSERT INTO `dbo_accountancy_company_types` VALUES (1,'Ajuste','A','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,'Contado','C','2024-10-16 22:37:12','2024-10-16 22:37:12'),(3,'Normal','N','2024-10-16 22:37:12','2024-10-16 22:37:12'),(4,'Utilidad Ajuste','U','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_accountancy_company_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_accountancy_ledger_purchases`
--

DROP TABLE IF EXISTS `dbo_accountancy_ledger_purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_accountancy_ledger_purchases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_date` datetime NOT NULL,
  `transaction_id` int DEFAULT NULL,
  `entry_type_id` int DEFAULT NULL,
  `document_type_name` varchar(255) NOT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `debit_note_number` varchar(255) DEFAULT NULL,
  `credit_note_number` varchar(255) DEFAULT NULL,
  `company_id` int NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `company_identification_number` varchar(255) DEFAULT NULL,
  `real_total` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `subtotal_without_tax` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `subtotal_tax_base` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `total_tax_amount` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `afected_invoice_number` varchar(255) DEFAULT NULL,
  `retention_id` int DEFAULT NULL,
  `retention_document_number` varchar(255) DEFAULT NULL,
  `total_retention_amount` decimal(20,4) DEFAULT '0.0000',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `entry_type_id` (`entry_type_id`),
  KEY `company_id` (`company_id`),
  KEY `retention_id` (`retention_id`),
  CONSTRAINT `dbo_accountancy_ledger_purchases_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_purchases_ibfk_2` FOREIGN KEY (`entry_type_id`) REFERENCES `dbo_storage_inventory_entry_types` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_purchases_ibfk_3` FOREIGN KEY (`company_id`) REFERENCES `dbo_config_companies` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_purchases_ibfk_4` FOREIGN KEY (`retention_id`) REFERENCES `dbo_retention_tax_invoices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_accountancy_ledger_purchases`
--

LOCK TABLES `dbo_accountancy_ledger_purchases` WRITE;
/*!40000 ALTER TABLE `dbo_accountancy_ledger_purchases` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_accountancy_ledger_purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_accountancy_ledger_sales`
--

DROP TABLE IF EXISTS `dbo_accountancy_ledger_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_accountancy_ledger_sales` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_date` datetime NOT NULL,
  `document_type` int NOT NULL,
  `document_type_name` varchar(255) DEFAULT NULL,
  `invoice_id` int NOT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `client_identification_number` varchar(255) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `real_total` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `subtotal_without_tax` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `subtotal_tax_base` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `total_tax_amount` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `total_retention_tax` decimal(20,4) DEFAULT '0.0000',
  `total_discount` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `total_net` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `total_cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `total_igtf` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `utility` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `utility_percentage` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `afected_invoice_number` varchar(255) DEFAULT NULL,
  `afected_invoice_id` int DEFAULT NULL,
  `fiscal_sequence` varchar(255) NOT NULL,
  `credit` tinyint(1) DEFAULT '0',
  `fiscal` tinyint(1) NOT NULL DEFAULT '1',
  `cash_register_dailies_id` int DEFAULT NULL,
  `printer_id` int DEFAULT NULL,
  `printer_description` varchar(255) DEFAULT NULL,
  `credit_note_id` int DEFAULT NULL,
  `credit_note_number` varchar(255) DEFAULT NULL,
  `debit_note_id` int DEFAULT NULL,
  `debit_note_number` varchar(255) DEFAULT NULL,
  `refund_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `document_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `client_id` (`client_id`),
  KEY `afected_invoice_id` (`afected_invoice_id`),
  KEY `cash_register_dailies_id` (`cash_register_dailies_id`),
  KEY `printer_id` (`printer_id`),
  KEY `credit_note_id` (`credit_note_id`),
  KEY `debit_note_id` (`debit_note_id`),
  KEY `refund_id` (`refund_id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_ibfk_3` FOREIGN KEY (`afected_invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_ibfk_4` FOREIGN KEY (`cash_register_dailies_id`) REFERENCES `dbo_pos_cash_register_dailies` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_ibfk_5` FOREIGN KEY (`printer_id`) REFERENCES `dbo_printer` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_ibfk_6` FOREIGN KEY (`credit_note_id`) REFERENCES `dbo_finance_creditnotes` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_ibfk_7` FOREIGN KEY (`debit_note_id`) REFERENCES `dbo_finance_debitnotes` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_ibfk_8` FOREIGN KEY (`refund_id`) REFERENCES `dbo_administration_refunds` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_accountancy_ledger_sales`
--

LOCK TABLES `dbo_accountancy_ledger_sales` WRITE;
/*!40000 ALTER TABLE `dbo_accountancy_ledger_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_accountancy_ledger_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_accountancy_ledger_sales_items`
--

DROP TABLE IF EXISTS `dbo_accountancy_ledger_sales_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_accountancy_ledger_sales_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_date` datetime NOT NULL,
  `ledger_sale_detail_id` int NOT NULL,
  `invoice_id` int NOT NULL,
  `invoice_item_id` int NOT NULL,
  `product_id` int NOT NULL,
  `tax_id` int NOT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `total_quantity` int DEFAULT '0',
  `real_total` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `subtotal_tax_base` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `subtotal_without_tax` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `total_tax_amount` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `category_id` int NOT NULL,
  `category_name` varchar(255) DEFAULT NULL,
  `subcategory_id` int NOT NULL,
  `subcategory_name` varchar(255) DEFAULT NULL,
  `invoice_credit` tinyint(1) NOT NULL,
  `invoice_fiscal` tinyint(1) NOT NULL,
  `refund_id` int DEFAULT NULL,
  `refund_item_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ledger_sale_detail_id` (`ledger_sale_detail_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `invoice_item_id` (`invoice_item_id`),
  KEY `product_id` (`product_id`),
  KEY `tax_id` (`tax_id`),
  KEY `category_id` (`category_id`),
  KEY `subcategory_id` (`subcategory_id`),
  KEY `refund_id` (`refund_id`),
  KEY `refund_item_id` (`refund_item_id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_items_ibfk_1` FOREIGN KEY (`ledger_sale_detail_id`) REFERENCES `dbo_accountancy_ledger_sales` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_items_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_items_ibfk_3` FOREIGN KEY (`invoice_item_id`) REFERENCES `dbo_administration_invoices_items` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_items_ibfk_4` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_items_ibfk_5` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_items_ibfk_6` FOREIGN KEY (`category_id`) REFERENCES `dbo_storage_categories` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_items_ibfk_7` FOREIGN KEY (`subcategory_id`) REFERENCES `dbo_storage_subcategories` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_items_ibfk_8` FOREIGN KEY (`refund_id`) REFERENCES `dbo_administration_refunds` (`id`),
  CONSTRAINT `dbo_accountancy_ledger_sales_items_ibfk_9` FOREIGN KEY (`refund_item_id`) REFERENCES `dbo_administration_refunds_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_accountancy_ledger_sales_items`
--

LOCK TABLES `dbo_accountancy_ledger_sales_items` WRITE;
/*!40000 ALTER TABLE `dbo_accountancy_ledger_sales_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_accountancy_ledger_sales_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_accountancy_operation_types`
--

DROP TABLE IF EXISTS `dbo_accountancy_operation_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_accountancy_operation_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_accountancy_operation_types`
--

LOCK TABLES `dbo_accountancy_operation_types` WRITE;
/*!40000 ALTER TABLE `dbo_accountancy_operation_types` DISABLE KEYS */;
INSERT INTO `dbo_accountancy_operation_types` VALUES (1,'COMPRA CRÉDITO','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,'COMPRA CONTADO','2024-10-16 22:37:12','2024-10-16 22:37:12'),(3,'VENTA CRÉDITO','2024-10-16 22:37:12','2024-10-16 22:37:12'),(4,'VENTA CONTADO','2024-10-16 22:37:12','2024-10-16 22:37:12'),(5,'DEVOLUCIÓN','2024-10-16 22:37:12','2024-10-16 22:37:12'),(6,'PAGO SERVICIOS','2024-10-16 22:37:12','2024-10-16 22:37:12'),(7,'ABONO','2024-10-16 22:37:12','2024-10-16 22:37:12'),(8,'RETENCIÓN de I.V.A','2024-10-16 22:37:12','2024-10-16 22:37:12'),(9,'RETENCIÓN de I.S.L.R.','2024-10-16 22:37:12','2024-10-16 22:37:12'),(10,'RESUMEN VENTAS CRÉDITO','2024-10-16 22:37:13','2024-10-16 22:37:13'),(11,'RESUMEN COMPRAS CRÉDITO','2024-10-16 22:37:13','2024-10-16 22:37:13'),(12,'RESUMEN VENTAS CONTADO','2024-10-16 22:37:13','2024-10-16 22:37:13'),(13,'RESUMEN COMPRAS CONTADO','2024-10-16 22:37:13','2024-10-16 22:37:13'),(14,'RESUMEN RETENCIONES IVA','2024-10-16 22:37:13','2024-10-16 22:37:13'),(15,'RESUMEN RETENCIONES ISRL','2024-10-16 22:37:13','2024-10-16 22:37:13');
/*!40000 ALTER TABLE `dbo_accountancy_operation_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_accountancy_operations`
--

DROP TABLE IF EXISTS `dbo_accountancy_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_accountancy_operations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accountancy_total_id` int DEFAULT NULL,
  `accountancy_id` int NOT NULL,
  `transaction_id` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `payment_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `line` int DEFAULT NULL,
  `correlative_number` int DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `day_number` varchar(255) DEFAULT NULL,
  `debit` decimal(20,2) NOT NULL DEFAULT '0.00',
  `credit` decimal(20,2) NOT NULL DEFAULT '0.00',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `operation_number` int NOT NULL,
  `operation_type_id` int NOT NULL,
  `payment_expenses_id` int DEFAULT NULL,
  `retention_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `provider_id` int DEFAULT NULL,
  `rif` varchar(255) DEFAULT NULL,
  `advanced_payment_id` int DEFAULT NULL,
  `payment_informal_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `accountancy_total_id` (`accountancy_total_id`),
  KEY `accountancy_id` (`accountancy_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `payment_id` (`payment_id`),
  KEY `user_id` (`user_id`),
  KEY `dbo_accountancy_operations_operation_type_id_foreign_idx` (`operation_type_id`),
  KEY `dbo_accountancy_operations_payment_expenses_id_foreign_idx` (`payment_expenses_id`),
  KEY `dbo_accountancy_operations_retention_id_foreign_idx` (`retention_id`),
  KEY `dbo_accountancy_operations_client_id_foreign_idx` (`client_id`),
  KEY `dbo_accountancy_operations_provider_id_foreign_idx` (`provider_id`),
  KEY `dbo_accountancy_operations_advanced_payment_id_foreign_idx` (`advanced_payment_id`),
  KEY `dbo_accountancy_operations_payment_informal_id_foreign_idx` (`payment_informal_id`),
  CONSTRAINT `dbo_accountancy_operations_advanced_payment_id_foreign_idx` FOREIGN KEY (`advanced_payment_id`) REFERENCES `dbo_finance_selected_payments` (`id`),
  CONSTRAINT `dbo_accountancy_operations_client_id_foreign_idx` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_accountancy_operations_ibfk_1` FOREIGN KEY (`accountancy_total_id`) REFERENCES `dbo_accountancy_operations_totals` (`id`),
  CONSTRAINT `dbo_accountancy_operations_ibfk_2` FOREIGN KEY (`accountancy_id`) REFERENCES `dbo_accountancy_accounts` (`id`),
  CONSTRAINT `dbo_accountancy_operations_ibfk_3` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`),
  CONSTRAINT `dbo_accountancy_operations_ibfk_4` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_accountancy_operations_ibfk_5` FOREIGN KEY (`payment_id`) REFERENCES `dbo_finance_payments` (`id`),
  CONSTRAINT `dbo_accountancy_operations_ibfk_6` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_accountancy_operations_operation_type_id_foreign_idx` FOREIGN KEY (`operation_type_id`) REFERENCES `dbo_accountancy_operation_types` (`id`),
  CONSTRAINT `dbo_accountancy_operations_payment_expenses_id_foreign_idx` FOREIGN KEY (`payment_expenses_id`) REFERENCES `dbo_administration_payment_expenses` (`id`),
  CONSTRAINT `dbo_accountancy_operations_payment_informal_id_foreign_idx` FOREIGN KEY (`payment_informal_id`) REFERENCES `dbo_finance_payments_informals` (`id`),
  CONSTRAINT `dbo_accountancy_operations_provider_id_foreign_idx` FOREIGN KEY (`provider_id`) REFERENCES `dbo_config_companies` (`id`),
  CONSTRAINT `dbo_accountancy_operations_retention_id_foreign_idx` FOREIGN KEY (`retention_id`) REFERENCES `dbo_retention_tax_invoices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_accountancy_operations`
--

LOCK TABLES `dbo_accountancy_operations` WRITE;
/*!40000 ALTER TABLE `dbo_accountancy_operations` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_accountancy_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_accountancy_operations_totals`
--

DROP TABLE IF EXISTS `dbo_accountancy_operations_totals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_accountancy_operations_totals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accountancy_id` int NOT NULL,
  `user_id` int NOT NULL,
  `line` int NOT NULL,
  `correlative_number` int NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `day_number` varchar(255) DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT '0.00',
  `credit` decimal(20,2) DEFAULT '0.00',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `accountancy_id` (`accountancy_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_accountancy_operations_totals_ibfk_1` FOREIGN KEY (`accountancy_id`) REFERENCES `dbo_accountancy_accounts` (`id`),
  CONSTRAINT `dbo_accountancy_operations_totals_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_accountancy_operations_totals`
--

LOCK TABLES `dbo_accountancy_operations_totals` WRITE;
/*!40000 ALTER TABLE `dbo_accountancy_operations_totals` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_accountancy_operations_totals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_binnacles`
--

DROP TABLE IF EXISTS `dbo_administration_binnacles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_binnacles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `action_id` int DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action_id` (`action_id`),
  CONSTRAINT `dbo_administration_binnacles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_binnacles_ibfk_2` FOREIGN KEY (`action_id`) REFERENCES `dbo_config_binnacle_actions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_binnacles`
--

LOCK TABLES `dbo_administration_binnacles` WRITE;
/*!40000 ALTER TABLE `dbo_administration_binnacles` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_binnacles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_budget_statuses`
--

DROP TABLE IF EXISTS `dbo_administration_budget_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_budget_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_budget_statuses`
--

LOCK TABLES `dbo_administration_budget_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_administration_budget_statuses` DISABLE KEYS */;
INSERT INTO `dbo_administration_budget_statuses` VALUES (1,'GUARDADA','2024-10-16 22:37:13','2024-10-16 22:37:13'),(2,'GENERADA','2024-10-16 22:37:13','2024-10-16 22:37:13'),(3,'CERRADA','2024-10-16 22:37:13','2024-10-16 22:37:13'),(4,'FACTURADA','2024-10-16 22:37:13','2024-10-16 22:37:13'),(5,'ANULADA','2024-10-16 22:37:13','2024-10-16 22:37:13');
/*!40000 ALTER TABLE `dbo_administration_budget_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_budgets`
--

DROP TABLE IF EXISTS `dbo_administration_budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_budgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `budget_number` int DEFAULT NULL,
  `total_product` int DEFAULT '0',
  `total_unit` int DEFAULT '0',
  `total` decimal(20,2) DEFAULT '0.00',
  `tax_base` decimal(20,2) DEFAULT '0.00',
  `subtotal` decimal(20,2) DEFAULT '0.00',
  `tax` decimal(20,2) DEFAULT '0.00',
  `retention_tax` decimal(20,2) DEFAULT '0.00',
  `tax_to_pay` decimal(20,2) DEFAULT '0.00',
  `total_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_base_without_discount` decimal(20,2) DEFAULT '0.00',
  `subtotal_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_without_discount` decimal(20,2) DEFAULT '0.00',
  `real_total` decimal(20,2) DEFAULT '0.00',
  `tax_id` int DEFAULT '1',
  `discount` decimal(20,2) DEFAULT '0.00',
  `client_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `status_id` int DEFAULT '1',
  `tax_discount` tinyint(1) NOT NULL DEFAULT '0',
  `printed` tinyint(1) NOT NULL DEFAULT '0',
  `reprintedDate` datetime DEFAULT NULL,
  `currency_id` int DEFAULT '2',
  `parnet_type` tinyint(1) NOT NULL DEFAULT '0',
  `seller_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `igtf` float(20,6) DEFAULT '0.000000',
  `real_total_add_igtf` float(20,6) DEFAULT '0.000000',
  `converted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax_id` (`tax_id`),
  KEY `client_id` (`client_id`),
  KEY `user_id` (`user_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `status_id` (`status_id`),
  KEY `currency_id` (`currency_id`),
  KEY `seller_id` (`seller_id`),
  CONSTRAINT `dbo_administration_budgets_ibfk_1` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_administration_budgets_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_administration_budgets_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_budgets_ibfk_4` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_budgets_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `dbo_administration_budget_statuses` (`id`),
  CONSTRAINT `dbo_administration_budgets_ibfk_6` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_administration_budgets_ibfk_7` FOREIGN KEY (`seller_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_budgets`
--

LOCK TABLES `dbo_administration_budgets` WRITE;
/*!40000 ALTER TABLE `dbo_administration_budgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_budgets_all_currencies`
--

DROP TABLE IF EXISTS `dbo_administration_budgets_all_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_budgets_all_currencies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `budget_id` int DEFAULT NULL,
  `budget_number` int DEFAULT NULL,
  `total_product` int DEFAULT '0',
  `total_unit` int DEFAULT '0',
  `total` decimal(20,2) DEFAULT '0.00',
  `tax_base` decimal(20,2) DEFAULT '0.00',
  `subtotal` decimal(20,2) DEFAULT '0.00',
  `tax` decimal(20,2) DEFAULT '0.00',
  `retention_tax` decimal(20,2) DEFAULT '0.00',
  `tax_to_pay` decimal(20,2) DEFAULT '0.00',
  `total_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_base_without_discount` decimal(20,2) DEFAULT '0.00',
  `subtotal_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_without_discount` decimal(20,2) DEFAULT '0.00',
  `real_total` decimal(20,2) DEFAULT '0.00',
  `tax_id` int DEFAULT '1',
  `discount` decimal(20,2) DEFAULT '0.00',
  `client_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `status_id` int DEFAULT '1',
  `printed` tinyint(1) NOT NULL DEFAULT '0',
  `reprintedDate` datetime DEFAULT NULL,
  `currency_id` int DEFAULT '2',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `budget_id` (`budget_id`),
  KEY `tax_id` (`tax_id`),
  KEY `client_id` (`client_id`),
  KEY `user_id` (`user_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `status_id` (`status_id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_administration_budgets_all_currencies_ibfk_1` FOREIGN KEY (`budget_id`) REFERENCES `dbo_administration_budgets` (`id`),
  CONSTRAINT `dbo_administration_budgets_all_currencies_ibfk_2` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_administration_budgets_all_currencies_ibfk_3` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_administration_budgets_all_currencies_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_budgets_all_currencies_ibfk_5` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_budgets_all_currencies_ibfk_6` FOREIGN KEY (`status_id`) REFERENCES `dbo_administration_budget_statuses` (`id`),
  CONSTRAINT `dbo_administration_budgets_all_currencies_ibfk_7` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_budgets_all_currencies`
--

LOCK TABLES `dbo_administration_budgets_all_currencies` WRITE;
/*!40000 ALTER TABLE `dbo_administration_budgets_all_currencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_budgets_all_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_budgets_items`
--

DROP TABLE IF EXISTS `dbo_administration_budgets_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_budgets_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quantity` int DEFAULT NULL,
  `cost` decimal(20,2) DEFAULT NULL,
  `discount` decimal(20,2) DEFAULT '0.00',
  `discount_raw` decimal(20,2) DEFAULT '0.00',
  `price` decimal(20,2) DEFAULT NULL,
  `tax_base` decimal(20,2) DEFAULT '0.00',
  `subtotal` decimal(20,2) DEFAULT '0.00',
  `tax_amount` decimal(20,2) DEFAULT '0.00',
  `total` decimal(20,2) DEFAULT '0.00',
  `tax_base_without_discount` decimal(20,2) DEFAULT '0.00',
  `subtotal_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_amount_without_discount` decimal(20,2) DEFAULT '0.00',
  `total_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_id` int DEFAULT NULL,
  `budget_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `unit_price_after_discount` decimal(20,2) DEFAULT '0.00',
  `inventory_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `weight_quantity` float(20,6) DEFAULT '0.000000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_index_budgets_items` (`product_id`,`budget_id`),
  KEY `tax_id` (`tax_id`),
  KEY `budget_id` (`budget_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `inventory_id` (`inventory_id`),
  CONSTRAINT `dbo_administration_budgets_items_ibfk_1` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_administration_budgets_items_ibfk_2` FOREIGN KEY (`budget_id`) REFERENCES `dbo_administration_budgets` (`id`),
  CONSTRAINT `dbo_administration_budgets_items_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_administration_budgets_items_ibfk_4` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_budgets_items_ibfk_5` FOREIGN KEY (`inventory_id`) REFERENCES `dbo_storage_inventories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_budgets_items`
--

LOCK TABLES `dbo_administration_budgets_items` WRITE;
/*!40000 ALTER TABLE `dbo_administration_budgets_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_budgets_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_budgets_items_prices`
--

DROP TABLE IF EXISTS `dbo_administration_budgets_items_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_budgets_items_prices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unit_price` decimal(20,2) DEFAULT '0.00',
  `discount` decimal(20,2) DEFAULT '0.00',
  `discount_raw` decimal(20,2) DEFAULT '0.00',
  `subtotal` decimal(20,2) DEFAULT '0.00',
  `tax_base` decimal(20,2) DEFAULT '0.00',
  `tax` decimal(20,2) DEFAULT '0.00',
  `total_price` decimal(20,2) DEFAULT '0.00',
  `subtotal_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_base_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_without_discount` decimal(20,2) DEFAULT '0.00',
  `total_price_without_discount` decimal(20,2) DEFAULT '0.00',
  `currency_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `budget_item_id` int DEFAULT NULL,
  `tax_id` int DEFAULT NULL,
  `budget_id` int DEFAULT NULL,
  `unit_price_after_discount` decimal(20,2) DEFAULT '0.00',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `budget_item_id` (`budget_item_id`),
  KEY `tax_id` (`tax_id`),
  KEY `budget_id` (`budget_id`),
  CONSTRAINT `dbo_administration_budgets_items_prices_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_administration_budgets_items_prices_ibfk_2` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_budgets_items_prices_ibfk_3` FOREIGN KEY (`budget_item_id`) REFERENCES `dbo_administration_budgets_items` (`id`),
  CONSTRAINT `dbo_administration_budgets_items_prices_ibfk_4` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_administration_budgets_items_prices_ibfk_5` FOREIGN KEY (`budget_id`) REFERENCES `dbo_administration_budgets` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_budgets_items_prices`
--

LOCK TABLES `dbo_administration_budgets_items_prices` WRITE;
/*!40000 ALTER TABLE `dbo_administration_budgets_items_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_budgets_items_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_collection_invoices`
--

DROP TABLE IF EXISTS `dbo_administration_collection_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_collection_invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `collection_id` int NOT NULL,
  `invoice_id` int NOT NULL,
  `exchange_rate_id` int NOT NULL,
  `user_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `collection_id` (`collection_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_administration_collection_invoices_ibfk_1` FOREIGN KEY (`collection_id`) REFERENCES `dbo_administration_collections` (`id`),
  CONSTRAINT `dbo_administration_collection_invoices_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_administration_collection_invoices_ibfk_3` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_collection_invoices_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_collection_invoices`
--

LOCK TABLES `dbo_administration_collection_invoices` WRITE;
/*!40000 ALTER TABLE `dbo_administration_collection_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_collection_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_collection_statuses`
--

DROP TABLE IF EXISTS `dbo_administration_collection_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_collection_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_collection_statuses`
--

LOCK TABLES `dbo_administration_collection_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_administration_collection_statuses` DISABLE KEYS */;
INSERT INTO `dbo_administration_collection_statuses` VALUES (1,'GENERADA','2024-10-16 22:53:35','2024-10-16 22:53:35'),(2,'VERIFICADA','2024-10-16 22:53:35','2024-10-16 22:53:35'),(3,'APROBADA','2024-10-16 22:53:35','2024-10-16 22:53:35');
/*!40000 ALTER TABLE `dbo_administration_collection_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_collection_types`
--

DROP TABLE IF EXISTS `dbo_administration_collection_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_collection_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_collection_types`
--

LOCK TABLES `dbo_administration_collection_types` WRITE;
/*!40000 ALTER TABLE `dbo_administration_collection_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_collection_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_collections`
--

DROP TABLE IF EXISTS `dbo_administration_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_collections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operation_code` varchar(255) NOT NULL DEFAULT '0',
  `operation_number` varchar(255) NOT NULL DEFAULT '0',
  `entry_type_id` int NOT NULL,
  `total_invoices` int NOT NULL DEFAULT '0',
  `total_amount_invoices` decimal(20,2) NOT NULL DEFAULT '0.00',
  `total_payments` int NOT NULL DEFAULT '0',
  `total_amount_payments` decimal(20,2) NOT NULL DEFAULT '0.00',
  `cash_register_id` int DEFAULT NULL,
  `collection_status_id` int NOT NULL,
  `user_id` int NOT NULL,
  `collection_account_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `exchange_diff` tinyint(1) NOT NULL DEFAULT '0',
  `exchange_diff_amount` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `entry_type_id` (`entry_type_id`),
  KEY `cash_register_id` (`cash_register_id`),
  KEY `collection_status_id` (`collection_status_id`),
  KEY `user_id` (`user_id`),
  KEY `collection_account_id` (`collection_account_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  CONSTRAINT `dbo_administration_collections_ibfk_1` FOREIGN KEY (`entry_type_id`) REFERENCES `dbo_storage_inventory_entry_types` (`id`),
  CONSTRAINT `dbo_administration_collections_ibfk_2` FOREIGN KEY (`cash_register_id`) REFERENCES `dbo_pos_cash_register_closes` (`id`),
  CONSTRAINT `dbo_administration_collections_ibfk_3` FOREIGN KEY (`collection_status_id`) REFERENCES `dbo_administration_collection_statuses` (`id`),
  CONSTRAINT `dbo_administration_collections_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_collections_ibfk_5` FOREIGN KEY (`collection_account_id`) REFERENCES `dbo_storage_inventory_entry_types` (`id`),
  CONSTRAINT `dbo_administration_collections_ibfk_6` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_collections`
--

LOCK TABLES `dbo_administration_collections` WRITE;
/*!40000 ALTER TABLE `dbo_administration_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_company_accounts`
--

DROP TABLE IF EXISTS `dbo_administration_company_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_company_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_id` int NOT NULL,
  `bank_id` int NOT NULL,
  `currency_id` int NOT NULL,
  `user_id` int NOT NULL,
  `number_account` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  KEY `bank_id` (`bank_id`),
  KEY `currency_id` (`currency_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_administration_company_accounts_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `dbo_config_companies` (`id`),
  CONSTRAINT `dbo_administration_company_accounts_ibfk_2` FOREIGN KEY (`bank_id`) REFERENCES `dbo_finance_banks` (`id`),
  CONSTRAINT `dbo_administration_company_accounts_ibfk_3` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_administration_company_accounts_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_company_accounts`
--

LOCK TABLES `dbo_administration_company_accounts` WRITE;
/*!40000 ALTER TABLE `dbo_administration_company_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_company_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_creditdays`
--

DROP TABLE IF EXISTS `dbo_administration_creditdays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_creditdays` (
  `id` int NOT NULL AUTO_INCREMENT,
  `days` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_creditdays`
--

LOCK TABLES `dbo_administration_creditdays` WRITE;
/*!40000 ALTER TABLE `dbo_administration_creditdays` DISABLE KEYS */;
INSERT INTO `dbo_administration_creditdays` VALUES (1,0,'Contado','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,0,'Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(3,1,'Un Día de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(4,2,'Dos Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(5,3,'Tres Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(6,4,'Cuatro Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(7,5,'Cinco Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(8,6,'Seis Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(9,7,'Una Semana de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(10,8,'Ocho Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(11,9,'Nueve Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(12,10,'Diez Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(13,11,'Once Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(14,12,'Doce Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(15,13,'Trece Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(16,14,'Dos Semanas de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12'),(17,15,'Quince Días de Crédito','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_administration_creditdays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_informal_providers`
--

DROP TABLE IF EXISTS `dbo_administration_informal_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_informal_providers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_informal_providers`
--

LOCK TABLES `dbo_administration_informal_providers` WRITE;
/*!40000 ALTER TABLE `dbo_administration_informal_providers` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_informal_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_invoice_finance_statuses`
--

DROP TABLE IF EXISTS `dbo_administration_invoice_finance_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_invoice_finance_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_invoice_finance_statuses`
--

LOCK TABLES `dbo_administration_invoice_finance_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_administration_invoice_finance_statuses` DISABLE KEYS */;
INSERT INTO `dbo_administration_invoice_finance_statuses` VALUES (1,'PENDIENTE','2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,'PAGADA','2024-10-16 22:37:11','2024-10-16 22:37:11');
/*!40000 ALTER TABLE `dbo_administration_invoice_finance_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_invoice_statuses`
--

DROP TABLE IF EXISTS `dbo_administration_invoice_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_invoice_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_invoice_statuses`
--

LOCK TABLES `dbo_administration_invoice_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_administration_invoice_statuses` DISABLE KEYS */;
INSERT INTO `dbo_administration_invoice_statuses` VALUES (1,'GUARDADA','2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,'GENERADA','2024-10-16 22:37:11','2024-10-16 22:37:11'),(3,'CERRADA','2024-10-16 22:37:11','2024-10-16 22:37:11'),(4,'FACTURADA','2024-10-16 22:37:11','2024-10-16 22:37:11'),(5,'ANULADA','2024-10-16 22:37:11','2024-10-16 22:37:11');
/*!40000 ALTER TABLE `dbo_administration_invoice_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_invoices`
--

DROP TABLE IF EXISTS `dbo_administration_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_number` int DEFAULT NULL,
  `saleorder_number` int DEFAULT NULL,
  `total_product` int DEFAULT '0',
  `total_unit` int DEFAULT '0',
  `total` decimal(20,2) DEFAULT '0.00',
  `tax_base` decimal(20,2) DEFAULT '0.00',
  `subtotal` decimal(20,2) DEFAULT '0.00',
  `tax` decimal(20,2) DEFAULT '0.00',
  `retention_tax` decimal(20,2) DEFAULT '0.00',
  `tax_to_pay` decimal(20,2) DEFAULT '0.00',
  `total_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_base_without_discount` decimal(20,2) DEFAULT '0.00',
  `subtotal_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_without_discount` decimal(20,2) DEFAULT '0.00',
  `real_total` decimal(20,2) DEFAULT '0.00',
  `tax_id` int DEFAULT '1',
  `discount` decimal(20,2) DEFAULT '0.00',
  `client_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `status_id` int DEFAULT '1',
  `finance_status_id` int DEFAULT '1',
  `credit` tinyint(1) NOT NULL DEFAULT '0',
  `fiscal` tinyint(1) NOT NULL DEFAULT '1',
  `tax_discount` tinyint(1) NOT NULL DEFAULT '0',
  `printed` tinyint(1) NOT NULL DEFAULT '0',
  `reprintedDate` datetime DEFAULT NULL,
  `currency_id` int DEFAULT '2',
  `cash_register_close_id` int DEFAULT NULL,
  `parnet_type` tinyint(1) NOT NULL DEFAULT '0',
  `seller_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `igtf` float(20,6) DEFAULT '0.000000',
  `real_total_add_igtf` float(20,6) DEFAULT '0.000000',
  `original_exchangerate_amount` float(20,6) DEFAULT '0.000000',
  `total_tax_cost` float(20,6) DEFAULT '0.000000',
  `subtotal_cost` float(20,6) DEFAULT '0.000000',
  `total_cost` float(20,6) DEFAULT '0.000000',
  `billing_user_id` int DEFAULT NULL,
  `quantity_change_seller` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tax_id` (`tax_id`),
  KEY `client_id` (`client_id`),
  KEY `user_id` (`user_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `status_id` (`status_id`),
  KEY `finance_status_id` (`finance_status_id`),
  KEY `currency_id` (`currency_id`),
  KEY `cash_register_close_id` (`cash_register_close_id`),
  KEY `seller_id` (`seller_id`),
  KEY `dbo_administration_invoices_billing_user_id_foreign_idx` (`billing_user_id`),
  CONSTRAINT `dbo_administration_invoices_billing_user_id_foreign_idx` FOREIGN KEY (`billing_user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_invoices_ibfk_1` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_administration_invoices_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_administration_invoices_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_invoices_ibfk_4` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_invoices_ibfk_5` FOREIGN KEY (`status_id`) REFERENCES `dbo_administration_invoice_statuses` (`id`),
  CONSTRAINT `dbo_administration_invoices_ibfk_6` FOREIGN KEY (`finance_status_id`) REFERENCES `dbo_administration_invoice_finance_statuses` (`id`),
  CONSTRAINT `dbo_administration_invoices_ibfk_7` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_administration_invoices_ibfk_8` FOREIGN KEY (`cash_register_close_id`) REFERENCES `dbo_pos_cash_register_closes` (`id`),
  CONSTRAINT `dbo_administration_invoices_ibfk_9` FOREIGN KEY (`seller_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_invoices`
--

LOCK TABLES `dbo_administration_invoices` WRITE;
/*!40000 ALTER TABLE `dbo_administration_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_invoices` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 */ /*!50003 TRIGGER `validate_fiscal` BEFORE UPDATE ON `dbo_administration_invoices` FOR EACH ROW BEGIN 
          IF ((OLD.fiscal = 1 && NEW.invoice_number = 0 && NEW.finance_status_id = 2 && NEW.status_id = 3) || (OLD.fiscal = 1 && NEW.invoice_number = 0 && NEW.status_id = 4))  THEN
              SIGNAL SQLSTATE '45000' 
              SET MESSAGE_TEXT = 'Error al crear factura fiscal - numeracion';
          
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `dbo_administration_invoices_all_currencies`
--

DROP TABLE IF EXISTS `dbo_administration_invoices_all_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_invoices_all_currencies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int DEFAULT NULL,
  `invoice_number` int DEFAULT NULL,
  `total_product` int DEFAULT '0',
  `total_unit` int DEFAULT '0',
  `total` decimal(20,2) DEFAULT '0.00',
  `tax_base` decimal(20,2) DEFAULT '0.00',
  `subtotal` decimal(20,2) DEFAULT '0.00',
  `tax` decimal(20,2) DEFAULT '0.00',
  `retention_tax` decimal(20,2) DEFAULT '0.00',
  `tax_to_pay` decimal(20,2) DEFAULT '0.00',
  `total_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_base_without_discount` decimal(20,2) DEFAULT '0.00',
  `subtotal_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_without_discount` decimal(20,2) DEFAULT '0.00',
  `real_total` decimal(20,2) DEFAULT '0.00',
  `tax_id` int DEFAULT '1',
  `discount` decimal(20,2) DEFAULT '0.00',
  `client_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `status_id` int DEFAULT '1',
  `finance_status_id` int DEFAULT '1',
  `credit` tinyint(1) NOT NULL DEFAULT '0',
  `fiscal` tinyint(1) NOT NULL DEFAULT '1',
  `printed` tinyint(1) NOT NULL DEFAULT '0',
  `reprintedDate` datetime DEFAULT NULL,
  `currency_id` int DEFAULT '2',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `total_tax_cost` float(20,6) DEFAULT '0.000000',
  `subtotal_cost` float(20,6) DEFAULT '0.000000',
  `total_cost` float(20,6) DEFAULT '0.000000',
  `original_exchangerate_amount` float(20,6) DEFAULT '0.000000',
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `tax_id` (`tax_id`),
  KEY `client_id` (`client_id`),
  KEY `user_id` (`user_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `status_id` (`status_id`),
  KEY `finance_status_id` (`finance_status_id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_administration_invoices_all_currencies_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_administration_invoices_all_currencies_ibfk_2` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_administration_invoices_all_currencies_ibfk_3` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_administration_invoices_all_currencies_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_invoices_all_currencies_ibfk_5` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_invoices_all_currencies_ibfk_6` FOREIGN KEY (`status_id`) REFERENCES `dbo_administration_invoice_statuses` (`id`),
  CONSTRAINT `dbo_administration_invoices_all_currencies_ibfk_7` FOREIGN KEY (`finance_status_id`) REFERENCES `dbo_administration_invoice_finance_statuses` (`id`),
  CONSTRAINT `dbo_administration_invoices_all_currencies_ibfk_8` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_invoices_all_currencies`
--

LOCK TABLES `dbo_administration_invoices_all_currencies` WRITE;
/*!40000 ALTER TABLE `dbo_administration_invoices_all_currencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_invoices_all_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_invoices_items`
--

DROP TABLE IF EXISTS `dbo_administration_invoices_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_invoices_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quantity` int DEFAULT NULL,
  `cost` decimal(20,2) DEFAULT NULL,
  `discount` decimal(20,2) DEFAULT '0.00',
  `discount_raw` decimal(20,2) DEFAULT '0.00',
  `price` decimal(20,2) DEFAULT NULL,
  `tax_base` decimal(20,2) DEFAULT '0.00',
  `subtotal` decimal(20,2) DEFAULT '0.00',
  `tax_amount` decimal(20,2) DEFAULT '0.00',
  `total` decimal(20,2) DEFAULT '0.00',
  `tax_base_without_discount` decimal(20,2) DEFAULT '0.00',
  `subtotal_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_amount_without_discount` decimal(20,2) DEFAULT '0.00',
  `total_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_id` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `inventory_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `unit_price_after_discount` decimal(20,2) DEFAULT '0.00',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `original_exchangerate_amount` float(20,6) DEFAULT '0.000000',
  `total_tax_cost` float(20,6) DEFAULT '0.000000',
  `total_cost` float(20,6) DEFAULT '0.000000',
  `subtotal_cost` float(20,6) DEFAULT '0.000000',
  `weight_quantity` float(20,6) DEFAULT '0.000000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_index_invoices_items` (`product_id`,`invoice_id`),
  KEY `tax_id` (`tax_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `inventory_id` (`inventory_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  CONSTRAINT `dbo_administration_invoices_items_ibfk_1` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_administration_invoices_items_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_administration_invoices_items_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_administration_invoices_items_ibfk_4` FOREIGN KEY (`inventory_id`) REFERENCES `dbo_storage_inventories` (`id`),
  CONSTRAINT `dbo_administration_invoices_items_ibfk_5` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_invoices_items`
--

LOCK TABLES `dbo_administration_invoices_items` WRITE;
/*!40000 ALTER TABLE `dbo_administration_invoices_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_invoices_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_invoices_items_prices`
--

DROP TABLE IF EXISTS `dbo_administration_invoices_items_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_invoices_items_prices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unit_price` decimal(20,2) DEFAULT '0.00',
  `discount` decimal(20,2) DEFAULT '0.00',
  `discount_raw` decimal(20,2) DEFAULT '0.00',
  `subtotal` decimal(20,2) DEFAULT '0.00',
  `tax_base` decimal(20,2) DEFAULT '0.00',
  `tax` decimal(20,2) DEFAULT '0.00',
  `total_price` decimal(20,2) DEFAULT '0.00',
  `subtotal_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_base_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_without_discount` decimal(20,2) DEFAULT '0.00',
  `total_price_without_discount` decimal(20,2) DEFAULT '0.00',
  `currency_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `invoice_item_id` int DEFAULT NULL,
  `tax_id` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `unit_price_after_discount` decimal(20,2) DEFAULT '0.00',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `unit_cost` float(20,6) DEFAULT '0.000000',
  `original_exchangerate_amount` float(20,6) DEFAULT '0.000000',
  `total_tax_cost` float(20,6) DEFAULT '0.000000',
  `subtotal_cost` float(20,6) DEFAULT '0.000000',
  `total_cost` float(20,6) DEFAULT '0.000000',
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `invoice_item_id` (`invoice_item_id`),
  KEY `tax_id` (`tax_id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `dbo_administration_invoices_items_prices_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_administration_invoices_items_prices_ibfk_2` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_invoices_items_prices_ibfk_3` FOREIGN KEY (`invoice_item_id`) REFERENCES `dbo_administration_invoices_items` (`id`),
  CONSTRAINT `dbo_administration_invoices_items_prices_ibfk_4` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_administration_invoices_items_prices_ibfk_5` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_invoices_items_prices`
--

LOCK TABLES `dbo_administration_invoices_items_prices` WRITE;
/*!40000 ALTER TABLE `dbo_administration_invoices_items_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_invoices_items_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_massive_uploads_preparations`
--

DROP TABLE IF EXISTS `dbo_administration_massive_uploads_preparations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_massive_uploads_preparations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bar_code` varchar(255) DEFAULT NULL,
  `product_description` varchar(255) DEFAULT NULL,
  `category_presentation` varchar(255) DEFAULT NULL,
  `general_gender` varchar(255) DEFAULT NULL,
  `subcategory_artifact` varchar(255) DEFAULT NULL,
  `line` varchar(255) DEFAULT NULL,
  `subline_cut` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `size_number` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `register_number` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `units_to_change` varchar(255) DEFAULT NULL,
  `total_bags` varchar(255) DEFAULT NULL,
  `units_bags` varchar(255) DEFAULT NULL,
  `total_units` varchar(255) DEFAULT NULL,
  `missing_units` varchar(255) DEFAULT NULL,
  `note_observation` varchar(255) DEFAULT NULL,
  `cost_product` varchar(255) DEFAULT NULL,
  `sale_price` varchar(255) DEFAULT NULL,
  `sencamer_code` varchar(255) DEFAULT NULL,
  `tax_code` varchar(255) DEFAULT NULL,
  `provider_id_number` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `model_code` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_massive_uploads_preparations`
--

LOCK TABLES `dbo_administration_massive_uploads_preparations` WRITE;
/*!40000 ALTER TABLE `dbo_administration_massive_uploads_preparations` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_massive_uploads_preparations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_my_company_accounts`
--

DROP TABLE IF EXISTS `dbo_administration_my_company_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_my_company_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bank_id` int NOT NULL,
  `currency_id` int NOT NULL,
  `user_id` int NOT NULL,
  `number_account` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `bank_id` (`bank_id`),
  KEY `currency_id` (`currency_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_administration_my_company_accounts_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `dbo_finance_banks` (`id`),
  CONSTRAINT `dbo_administration_my_company_accounts_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_administration_my_company_accounts_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_my_company_accounts`
--

LOCK TABLES `dbo_administration_my_company_accounts` WRITE;
/*!40000 ALTER TABLE `dbo_administration_my_company_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_my_company_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_payment_expenses`
--

DROP TABLE IF EXISTS `dbo_administration_payment_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_payment_expenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` decimal(20,2) DEFAULT NULL,
  `exchange_rate_provider` decimal(20,2) DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `provider_id` int DEFAULT NULL,
  `transaction_id` int DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `company_acc_id` int DEFAULT NULL,
  `provider_acc_id` int DEFAULT NULL,
  `status_id` int DEFAULT '1',
  `reference` varchar(255) DEFAULT NULL,
  `payment_credit` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `currency_id` (`currency_id`),
  KEY `user_id` (`user_id`),
  KEY `provider_id` (`provider_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `dbo_administration_payment_expenses_company_acc_id_foreign_idx` (`company_acc_id`),
  KEY `dbo_administration_payment_expenses_provider_acc_id_foreign_idx` (`provider_acc_id`),
  KEY `dbo_administration_payment_expenses_status_id_foreign_idx` (`status_id`),
  CONSTRAINT `dbo_administration_payment_expenses_company_acc_id_foreign_idx` FOREIGN KEY (`company_acc_id`) REFERENCES `dbo_administration_my_company_accounts` (`id`),
  CONSTRAINT `dbo_administration_payment_expenses_ibfk_3` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_payment_expenses_ibfk_4` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_administration_payment_expenses_ibfk_5` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_payment_expenses_ibfk_6` FOREIGN KEY (`provider_id`) REFERENCES `dbo_config_companies` (`id`),
  CONSTRAINT `dbo_administration_payment_expenses_ibfk_7` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`),
  CONSTRAINT `dbo_administration_payment_expenses_provider_acc_id_foreign_idx` FOREIGN KEY (`provider_acc_id`) REFERENCES `dbo_administration_company_accounts` (`id`),
  CONSTRAINT `dbo_administration_payment_expenses_status_id_foreign_idx` FOREIGN KEY (`status_id`) REFERENCES `dbo_finance_payment_expense_statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_payment_expenses`
--

LOCK TABLES `dbo_administration_payment_expenses` WRITE;
/*!40000 ALTER TABLE `dbo_administration_payment_expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_payment_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_product_costs`
--

DROP TABLE IF EXISTS `dbo_administration_product_costs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_product_costs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int DEFAULT NULL,
  `cost_bs` float(24,6) DEFAULT NULL,
  `cost_usd` float(24,6) DEFAULT NULL,
  `exchange_rate_provider` float(24,6) DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `provider_id` int DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `observation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `user_id` (`user_id`),
  KEY `provider_id` (`provider_id`),
  CONSTRAINT `dbo_administration_product_costs_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_administration_product_costs_ibfk_2` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_product_costs_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_product_costs_ibfk_4` FOREIGN KEY (`provider_id`) REFERENCES `dbo_config_companies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_product_costs`
--

LOCK TABLES `dbo_administration_product_costs` WRITE;
/*!40000 ALTER TABLE `dbo_administration_product_costs` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_product_costs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_product_price_types`
--

DROP TABLE IF EXISTS `dbo_administration_product_price_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_product_price_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `percentage` decimal(5,4) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_product_price_types`
--

LOCK TABLES `dbo_administration_product_price_types` WRITE;
/*!40000 ALTER TABLE `dbo_administration_product_price_types` DISABLE KEYS */;
INSERT INTO `dbo_administration_product_price_types` VALUES (1,'Precio 1 0%',0.0000,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'Precio 2 30%',0.3000,'2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_administration_product_price_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_product_shortage_histories`
--

DROP TABLE IF EXISTS `dbo_administration_product_shortage_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_product_shortage_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_shortage_id` int NOT NULL,
  `transaction_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `active` tinyint(1) NOT NULL,
  `observation` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_shortage_id` (`product_shortage_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_administration_product_shortage_histories_ibfk_1` FOREIGN KEY (`product_shortage_id`) REFERENCES `dbo_administration_product_shortages` (`id`),
  CONSTRAINT `dbo_administration_product_shortage_histories_ibfk_2` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`),
  CONSTRAINT `dbo_administration_product_shortage_histories_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_product_shortage_histories`
--

LOCK TABLES `dbo_administration_product_shortage_histories` WRITE;
/*!40000 ALTER TABLE `dbo_administration_product_shortage_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_product_shortage_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_product_shortages`
--

DROP TABLE IF EXISTS `dbo_administration_product_shortages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_product_shortages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `inventory_id` int NOT NULL,
  `min_quantity` int NOT NULL,
  `active` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `inventory_id` (`inventory_id`),
  CONSTRAINT `dbo_administration_product_shortages_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_administration_product_shortages_ibfk_2` FOREIGN KEY (`inventory_id`) REFERENCES `dbo_storage_inventories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_product_shortages`
--

LOCK TABLES `dbo_administration_product_shortages` WRITE;
/*!40000 ALTER TABLE `dbo_administration_product_shortages` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_product_shortages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_product_weight_units`
--

DROP TABLE IF EXISTS `dbo_administration_product_weight_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_product_weight_units` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `abbreviation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_product_weight_units`
--

LOCK TABLES `dbo_administration_product_weight_units` WRITE;
/*!40000 ALTER TABLE `dbo_administration_product_weight_units` DISABLE KEYS */;
INSERT INTO `dbo_administration_product_weight_units` VALUES (1,'Kilogramos','Kg','2024-10-16 22:53:35','2024-10-16 22:53:35'),(2,'Libras','Lb','2024-10-16 22:53:35','2024-10-16 22:53:35'),(3,'Litros','L','2024-10-16 22:53:35','2024-10-16 22:53:35'),(4,'Centímetros Cúbicos','cm³','2024-10-16 22:53:35','2024-10-16 22:53:35');
/*!40000 ALTER TABLE `dbo_administration_product_weight_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_products_price_amount_histories`
--

DROP TABLE IF EXISTS `dbo_administration_products_price_amount_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_products_price_amount_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount_old` decimal(24,6) DEFAULT NULL,
  `amount_new` decimal(24,6) DEFAULT NULL,
  `amount_exchange_rate_old` decimal(24,6) DEFAULT NULL,
  `amount_exchange_rate_new` decimal(24,6) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `percentage` decimal(5,4) DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `old_exchange_rate_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `old_exchange_rate_id` (`old_exchange_rate_id`),
  KEY `currency_id` (`currency_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `dbo_administration_products_price_amount_histories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_products_price_amount_histories_ibfk_2` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_products_price_amount_histories_ibfk_3` FOREIGN KEY (`old_exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_products_price_amount_histories_ibfk_4` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_administration_products_price_amount_histories_ibfk_5` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_products_price_amount_histories`
--

LOCK TABLES `dbo_administration_products_price_amount_histories` WRITE;
/*!40000 ALTER TABLE `dbo_administration_products_price_amount_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_products_price_amount_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_products_price_amounts`
--

DROP TABLE IF EXISTS `dbo_administration_products_price_amounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_products_price_amounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` decimal(24,2) DEFAULT '0.00',
  `user_id` int DEFAULT NULL,
  `tax_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `product_price_type_id` int DEFAULT NULL,
  `inventory_history_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `profit_percentage` decimal(10,4) DEFAULT '0.0000',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `tax_id` (`tax_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `currency_id` (`currency_id`),
  KEY `product_price_type_id` (`product_price_type_id`),
  KEY `inventory_history_id` (`inventory_history_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `dbo_administration_products_price_amounts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_products_price_amounts_ibfk_2` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_administration_products_price_amounts_ibfk_3` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_products_price_amounts_ibfk_4` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_administration_products_price_amounts_ibfk_5` FOREIGN KEY (`product_price_type_id`) REFERENCES `dbo_administration_product_price_types` (`id`),
  CONSTRAINT `dbo_administration_products_price_amounts_ibfk_6` FOREIGN KEY (`inventory_history_id`) REFERENCES `dbo_storage_inventory_history` (`id`),
  CONSTRAINT `dbo_administration_products_price_amounts_ibfk_7` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_products_price_amounts`
--

LOCK TABLES `dbo_administration_products_price_amounts` WRITE;
/*!40000 ALTER TABLE `dbo_administration_products_price_amounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_products_price_amounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_reason_items`
--

DROP TABLE IF EXISTS `dbo_administration_reason_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_reason_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_reason_items`
--

LOCK TABLES `dbo_administration_reason_items` WRITE;
/*!40000 ALTER TABLE `dbo_administration_reason_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_reason_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_refunds`
--

DROP TABLE IF EXISTS `dbo_administration_refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_refunds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `total_quantity` int DEFAULT NULL,
  `total_product` int DEFAULT NULL,
  `subtotal` decimal(20,2) DEFAULT NULL,
  `tax_amount` decimal(20,2) DEFAULT NULL,
  `total` decimal(20,2) DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `refunds_status_id` int NOT NULL,
  `reason_id` int NOT NULL,
  `user_id` int NOT NULL,
  `client_id` int NOT NULL,
  `credit_note_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`refunds_status_id`,`reason_id`,`user_id`,`client_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `refunds_status_id` (`refunds_status_id`),
  KEY `reason_id` (`reason_id`),
  KEY `user_id` (`user_id`),
  KEY `client_id` (`client_id`),
  KEY `credit_note_id` (`credit_note_id`),
  CONSTRAINT `dbo_administration_refunds_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_administration_refunds_ibfk_2` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_refunds_ibfk_3` FOREIGN KEY (`refunds_status_id`) REFERENCES `dbo_refunds_statuses` (`id`),
  CONSTRAINT `dbo_administration_refunds_ibfk_4` FOREIGN KEY (`reason_id`) REFERENCES `dbo_refunds_reasons` (`id`),
  CONSTRAINT `dbo_administration_refunds_ibfk_5` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_administration_refunds_ibfk_6` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_administration_refunds_ibfk_7` FOREIGN KEY (`credit_note_id`) REFERENCES `dbo_finance_creditnotes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_refunds`
--

LOCK TABLES `dbo_administration_refunds` WRITE;
/*!40000 ALTER TABLE `dbo_administration_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_refunds_items`
--

DROP TABLE IF EXISTS `dbo_administration_refunds_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_refunds_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` decimal(20,2) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `subtotal` decimal(20,2) DEFAULT NULL,
  `tax` decimal(20,2) DEFAULT NULL,
  `total` decimal(20,2) DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `invoice_item_id` int DEFAULT NULL,
  `refund_id` int DEFAULT NULL,
  `reason_item_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `invoice_item_id` (`invoice_item_id`),
  KEY `refund_id` (`refund_id`),
  KEY `reason_item_id` (`reason_item_id`),
  CONSTRAINT `dbo_administration_refunds_items_ibfk_1` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_administration_refunds_items_ibfk_2` FOREIGN KEY (`invoice_item_id`) REFERENCES `dbo_administration_invoices_items` (`id`),
  CONSTRAINT `dbo_administration_refunds_items_ibfk_3` FOREIGN KEY (`refund_id`) REFERENCES `dbo_administration_refunds` (`id`),
  CONSTRAINT `dbo_administration_refunds_items_ibfk_4` FOREIGN KEY (`reason_item_id`) REFERENCES `dbo_refunds_reasons` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_refunds_items`
--

LOCK TABLES `dbo_administration_refunds_items` WRITE;
/*!40000 ALTER TABLE `dbo_administration_refunds_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_refunds_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_administration_standinginvoices`
--

DROP TABLE IF EXISTS `dbo_administration_standinginvoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_administration_standinginvoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `exchange_rate` decimal(20,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_administration_standinginvoices`
--

LOCK TABLES `dbo_administration_standinginvoices` WRITE;
/*!40000 ALTER TABLE `dbo_administration_standinginvoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_administration_standinginvoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_binnacle_actions`
--

DROP TABLE IF EXISTS `dbo_config_binnacle_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_binnacle_actions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_binnacle_actions`
--

LOCK TABLES `dbo_config_binnacle_actions` WRITE;
/*!40000 ALTER TABLE `dbo_config_binnacle_actions` DISABLE KEYS */;
INSERT INTO `dbo_config_binnacle_actions` VALUES (1,'CREACIÓN DE VENTA','2024-10-16 22:53:34','2024-10-16 22:53:34'),(2,'ELIMINACIÓN DE VENTA','2024-10-16 22:53:34','2024-10-16 22:53:34'),(3,'DEVOLUCIÓN DE VENTA','2024-10-16 22:53:34','2024-10-16 22:53:34'),(4,'CAMBIO DE VENDEDOR EN FACTURAS','2024-10-16 22:53:34','2024-10-16 22:53:34'),(5,'CREACIÓN DE PRESUPUESTO','2024-10-16 22:53:34','2024-10-16 22:53:34'),(6,'ELIMINACIÓN DE PRESUPUESTO','2024-10-16 22:53:34','2024-10-16 22:53:34'),(7,'CONVERSION','2024-10-16 22:53:34','2024-10-16 22:53:34');
/*!40000 ALTER TABLE `dbo_config_binnacle_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_companies`
--

DROP TABLE IF EXISTS `dbo_config_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_companies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `identification_number` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `telephone_1` varchar(255) DEFAULT NULL,
  `telephone_2` varchar(255) DEFAULT NULL,
  `regent` varchar(255) DEFAULT NULL,
  `country_id` int DEFAULT NULL,
  `zone_id` int DEFAULT NULL,
  `identification_type_id` int DEFAULT NULL,
  `tax_withholding_id` int DEFAULT '1',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `accountancy_account_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  KEY `zone_id` (`zone_id`),
  KEY `identification_type_id` (`identification_type_id`),
  KEY `tax_withholding_id` (`tax_withholding_id`),
  KEY `dbo_config_companies_accountancy_account_id_foreign_idx` (`accountancy_account_id`),
  CONSTRAINT `dbo_config_companies_accountancy_account_id_foreign_idx` FOREIGN KEY (`accountancy_account_id`) REFERENCES `dbo_accountancy_accounts` (`id`),
  CONSTRAINT `dbo_config_companies_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `dbo_config_countries` (`id`),
  CONSTRAINT `dbo_config_companies_ibfk_2` FOREIGN KEY (`zone_id`) REFERENCES `dbo_config_zones` (`id`),
  CONSTRAINT `dbo_config_companies_ibfk_3` FOREIGN KEY (`identification_type_id`) REFERENCES `dbo_config_identifications_types` (`id`),
  CONSTRAINT `dbo_config_companies_ibfk_4` FOREIGN KEY (`tax_withholding_id`) REFERENCES `dbo_config_tax_withholdings` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_companies`
--

LOCK TABLES `dbo_config_companies` WRITE;
/*!40000 ALTER TABLE `dbo_config_companies` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_config_companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_countries`
--

DROP TABLE IF EXISTS `dbo_config_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_countries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_countries`
--

LOCK TABLES `dbo_config_countries` WRITE;
/*!40000 ALTER TABLE `dbo_config_countries` DISABLE KEYS */;
INSERT INTO `dbo_config_countries` VALUES (1,'USA','USA','2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,'VENEZUELA','VE','2024-10-16 22:37:11','2024-10-16 22:37:11'),(3,'LIBANO','LB','2024-10-16 22:37:11','2024-10-16 22:37:11');
/*!40000 ALTER TABLE `dbo_config_countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_currencies`
--

DROP TABLE IF EXISTS `dbo_config_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_currencies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `abbreviation` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_currencies`
--

LOCK TABLES `dbo_config_currencies` WRITE;
/*!40000 ALTER TABLE `dbo_config_currencies` DISABLE KEYS */;
INSERT INTO `dbo_config_currencies` VALUES (1,'Dolar','$','2024-10-16 22:37:09','2024-10-16 22:37:09'),(2,'Bolivar','Bs','2024-10-16 22:37:09','2024-10-16 22:37:09');
/*!40000 ALTER TABLE `dbo_config_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_currency_denominations`
--

DROP TABLE IF EXISTS `dbo_config_currency_denominations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_currency_denominations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `currency_id` int DEFAULT NULL,
  `value` decimal(20,2) NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_config_currency_denominations_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_currency_denominations`
--

LOCK TABLES `dbo_config_currency_denominations` WRITE;
/*!40000 ALTER TABLE `dbo_config_currency_denominations` DISABLE KEYS */;
INSERT INTO `dbo_config_currency_denominations` VALUES (1,1,100.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,1,50.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(3,1,20.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(4,1,10.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(5,1,5.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(6,1,1.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(7,1,0.50,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(8,1,0.25,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(9,1,0.10,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(10,1,0.05,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(11,1,0.01,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(12,2,100.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(13,2,50.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(14,2,20.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(15,2,10.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(16,2,5.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(17,2,1.00,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(18,2,0.50,1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(19,2,0.20,1,'2024-10-16 22:37:11','2024-10-16 22:37:11');
/*!40000 ALTER TABLE `dbo_config_currency_denominations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_emails`
--

DROP TABLE IF EXISTS `dbo_config_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_emails` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email_origin` varchar(255) DEFAULT NULL,
  `email_extension_origin` varchar(255) DEFAULT NULL,
  `pass_origin` varchar(255) DEFAULT NULL,
  `email_destination` varchar(255) DEFAULT NULL,
  `email_extension_destination` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_emails`
--

LOCK TABLES `dbo_config_emails` WRITE;
/*!40000 ALTER TABLE `dbo_config_emails` DISABLE KEYS */;
INSERT INTO `dbo_config_emails` VALUES (1,'correo-origen','gmail.com','123123123','correo-destino','gmail.com','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_config_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_exchange_rates`
--

DROP TABLE IF EXISTS `dbo_config_exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_exchange_rates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `exchange_rate` decimal(20,2) DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_config_exchange_rates_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_exchange_rates`
--

LOCK TABLES `dbo_config_exchange_rates` WRITE;
/*!40000 ALTER TABLE `dbo_config_exchange_rates` DISABLE KEYS */;
INSERT INTO `dbo_config_exchange_rates` VALUES (1,1.00,2,'2024-10-16 22:37:09','2024-10-16 22:37:09'),(2,4.30,1,'2024-10-16 22:37:09','2024-10-16 22:37:09');
/*!40000 ALTER TABLE `dbo_config_exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_genders`
--

DROP TABLE IF EXISTS `dbo_config_genders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_genders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_genders`
--

LOCK TABLES `dbo_config_genders` WRITE;
/*!40000 ALTER TABLE `dbo_config_genders` DISABLE KEYS */;
INSERT INTO `dbo_config_genders` VALUES (1,'Masculino','2024-10-16 22:53:37','2024-10-16 22:53:37'),(2,'Femenino','2024-10-16 22:53:37','2024-10-16 22:53:37');
/*!40000 ALTER TABLE `dbo_config_genders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_identifications_types`
--

DROP TABLE IF EXISTS `dbo_config_identifications_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_identifications_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_identifications_types`
--

LOCK TABLES `dbo_config_identifications_types` WRITE;
/*!40000 ALTER TABLE `dbo_config_identifications_types` DISABLE KEYS */;
INSERT INTO `dbo_config_identifications_types` VALUES (1,'V','2024-10-16 22:37:09','2024-10-16 22:37:09'),(2,'J','2024-10-16 22:37:09','2024-10-16 22:37:09'),(3,'G','2024-10-16 22:37:09','2024-10-16 22:37:09'),(4,'P','2024-10-16 22:37:09','2024-10-16 22:37:09'),(5,'R','2024-10-16 22:37:09','2024-10-16 22:37:09'),(6,'E','2024-10-16 22:37:09','2024-10-16 22:37:09'),(7,'I','2024-10-16 22:37:09','2024-10-16 22:37:09'),(8,'M','2024-10-16 22:37:09','2024-10-16 22:37:09');
/*!40000 ALTER TABLE `dbo_config_identifications_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_my_companies`
--

DROP TABLE IF EXISTS `dbo_config_my_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_my_companies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `identification_number` varchar(255) DEFAULT NULL,
  `direction` varchar(255) DEFAULT NULL,
  `telephone_1` varchar(255) DEFAULT NULL,
  `telephone_2` varchar(255) DEFAULT NULL,
  `identification_type_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `transaction_initial` int DEFAULT NULL,
  `initial_invoice` int DEFAULT NULL,
  `note_credit` int DEFAULT NULL,
  `note_debit` int DEFAULT NULL,
  `sales_number_init` int DEFAULT NULL,
  `image_base_64` varchar(10000) DEFAULT NULL,
  `retention_number` int DEFAULT '0',
  `create_retentions` tinyint(1) DEFAULT '0',
  `min_quantity` int DEFAULT '0',
  `invoice_note` varchar(500) DEFAULT '',
  `show_ticket_image` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `identification_type_id` (`identification_type_id`),
  CONSTRAINT `dbo_config_my_companies_ibfk_1` FOREIGN KEY (`identification_type_id`) REFERENCES `dbo_config_identifications_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_my_companies`
--

LOCK TABLES `dbo_config_my_companies` WRITE;
/*!40000 ALTER TABLE `dbo_config_my_companies` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_config_my_companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_tax_withholdings`
--

DROP TABLE IF EXISTS `dbo_config_tax_withholdings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_tax_withholdings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `percentage` decimal(20,2) DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_tax_withholdings`
--

LOCK TABLES `dbo_config_tax_withholdings` WRITE;
/*!40000 ALTER TABLE `dbo_config_tax_withholdings` DISABLE KEYS */;
INSERT INTO `dbo_config_tax_withholdings` VALUES (1,0.00,'0% Retención','2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,0.75,'75% Retención','2024-10-16 22:37:11','2024-10-16 22:37:11'),(3,1.00,'100% Retención','2024-10-16 22:37:11','2024-10-16 22:37:11');
/*!40000 ALTER TABLE `dbo_config_tax_withholdings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_taxes`
--

DROP TABLE IF EXISTS `dbo_config_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_taxes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `percentage` decimal(5,4) DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `product` tinyint(1) DEFAULT '1',
  `tax_code` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_taxes`
--

LOCK TABLES `dbo_config_taxes` WRITE;
/*!40000 ALTER TABLE `dbo_config_taxes` DISABLE KEYS */;
INSERT INTO `dbo_config_taxes` VALUES (1,0.1600,'IVA 16%','2024-10-16 22:37:09','2024-10-16 22:37:09',1,''),(2,0.0000,'Sin IVA','2024-10-16 22:37:09','2024-10-16 22:37:09',1,''),(3,0.0300,'IGTF 3%','2024-10-16 22:37:13','2024-10-16 22:37:13',0,'');
/*!40000 ALTER TABLE `dbo_config_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_config_zones`
--

DROP TABLE IF EXISTS `dbo_config_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_config_zones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_config_zones`
--

LOCK TABLES `dbo_config_zones` WRITE;
/*!40000 ALTER TABLE `dbo_config_zones` DISABLE KEYS */;
INSERT INTO `dbo_config_zones` VALUES (1,'CARACAS','001','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,'LIBANO','002','2024-10-16 22:37:12','2024-10-16 22:37:12'),(3,'USA','003','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_config_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_configuration_accountancy_operation_types`
--

DROP TABLE IF EXISTS `dbo_configuration_accountancy_operation_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_configuration_accountancy_operation_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `acc_id` int NOT NULL,
  `acc_type_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `acc_id` (`acc_id`),
  KEY `acc_type_id` (`acc_type_id`),
  CONSTRAINT `dbo_configuration_accountancy_operation_types_ibfk_1` FOREIGN KEY (`acc_id`) REFERENCES `dbo_accountancy_accounts` (`id`),
  CONSTRAINT `dbo_configuration_accountancy_operation_types_ibfk_2` FOREIGN KEY (`acc_type_id`) REFERENCES `dbo_configuration_accountancy_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_configuration_accountancy_operation_types`
--

LOCK TABLES `dbo_configuration_accountancy_operation_types` WRITE;
/*!40000 ALTER TABLE `dbo_configuration_accountancy_operation_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_configuration_accountancy_operation_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_configuration_accountancy_types`
--

DROP TABLE IF EXISTS `dbo_configuration_accountancy_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_configuration_accountancy_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_configuration_accountancy_types`
--

LOCK TABLES `dbo_configuration_accountancy_types` WRITE;
/*!40000 ALTER TABLE `dbo_configuration_accountancy_types` DISABLE KEYS */;
INSERT INTO `dbo_configuration_accountancy_types` VALUES (1,'COMPRAS','2024-10-16 22:37:13','2024-10-16 22:37:13'),(2,'COSTO DE VENTA','2024-10-16 22:37:13','2024-10-16 22:37:13'),(3,'VENTA DE MERCANCIAS','2024-10-16 22:37:13','2024-10-16 22:37:13'),(4,'GASTOS','2024-10-16 22:37:13','2024-10-16 22:37:13'),(5,'BIENES','2024-10-16 22:37:13','2024-10-16 22:37:13'),(6,'SERVICIOS','2024-10-16 22:37:13','2024-10-16 22:37:13'),(7,'SALDO A CLIENTES','2024-10-16 22:37:13','2024-10-16 22:37:13'),(8,'CUENTAS POR PAGAR','2024-10-16 22:37:13','2024-10-16 22:37:13'),(9,'CUENTAS POR COBRAR','2024-10-16 22:37:13','2024-10-16 22:37:13'),(10,'INVENTARIO DE MERCANCIAS','2024-10-16 22:37:13','2024-10-16 22:37:13'),(11,'CREDITO DE IVA','2024-10-16 22:37:13','2024-10-16 22:37:13'),(12,'DEBITO DE IVA','2024-10-16 22:37:13','2024-10-16 22:37:13'),(13,'RETENCIONES','2024-10-16 22:37:13','2024-10-16 22:37:13'),(14,'RETENCIONES POR APROVECHAR','2024-10-16 22:37:13','2024-10-16 22:37:13'),(15,'PERDIDA EN CAMBIO','2024-10-16 22:37:13','2024-10-16 22:37:13'),(16,'GANANCIA EN CAMBIO','2024-10-16 22:37:13','2024-10-16 22:37:13'),(17,'VUELTOS','2024-10-16 22:37:13','2024-10-16 22:37:13'),(18,'DEVOLUCIONES VENTAS','2024-10-16 22:37:13','2024-10-16 22:37:13'),(19,'DEVOLUCIONES COMPRAS','2024-10-16 22:37:13','2024-10-16 22:37:13'),(20,'CAJA EN BOLIVARES','2024-10-16 22:37:13','2024-10-16 22:37:13'),(21,'CAJA EN DIVISAS','2024-10-16 22:37:13','2024-10-16 22:37:13'),(22,'IGTF VENTAS','2024-10-16 22:37:14','2024-10-16 22:37:14'),(23,'DESCUENTO VENTAS','2024-10-16 22:37:14','2024-10-16 22:37:14'),(24,'DESCUENTO COMPRAS','2024-10-16 22:37:14','2024-10-16 22:37:14');
/*!40000 ALTER TABLE `dbo_configuration_accountancy_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_discount_types`
--

DROP TABLE IF EXISTS `dbo_discount_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_discount_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `percentage` decimal(5,4) DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_discount_types`
--

LOCK TABLES `dbo_discount_types` WRITE;
/*!40000 ALTER TABLE `dbo_discount_types` DISABLE KEYS */;
INSERT INTO `dbo_discount_types` VALUES (1,0.0000,'0%','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,0.0100,'1% ','2024-10-16 22:37:12','2024-10-16 22:37:12'),(3,0.0200,'2%','2024-10-16 22:37:12','2024-10-16 22:37:12'),(4,0.0300,'3% ','2024-10-16 22:37:12','2024-10-16 22:37:12'),(5,0.0400,'4%','2024-10-16 22:37:12','2024-10-16 22:37:12'),(6,0.0500,'5% ','2024-10-16 22:37:12','2024-10-16 22:37:12'),(7,0.1000,'10%','2024-10-16 22:37:12','2024-10-16 22:37:12'),(8,0.2000,'20% ','2024-10-16 22:37:12','2024-10-16 22:37:12'),(9,0.5000,'50%','2024-10-16 22:37:12','2024-10-16 22:37:12'),(10,0.0000,'0%','2024-10-16 22:37:13','2024-10-16 22:37:13'),(11,0.0100,'1% ','2024-10-16 22:37:13','2024-10-16 22:37:13'),(12,0.0200,'2%','2024-10-16 22:37:13','2024-10-16 22:37:13'),(13,0.0300,'3% ','2024-10-16 22:37:13','2024-10-16 22:37:13'),(14,0.0400,'4%','2024-10-16 22:37:13','2024-10-16 22:37:13'),(15,0.0500,'5% ','2024-10-16 22:37:13','2024-10-16 22:37:13'),(16,0.1000,'10%','2024-10-16 22:37:13','2024-10-16 22:37:13'),(17,0.2000,'20% ','2024-10-16 22:37:13','2024-10-16 22:37:13'),(18,0.5000,'50%','2024-10-16 22:37:13','2024-10-16 22:37:13');
/*!40000 ALTER TABLE `dbo_discount_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_balance_collection_accounts`
--

DROP TABLE IF EXISTS `dbo_finance_balance_collection_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_balance_collection_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `collection_account_id` int NOT NULL,
  `collection_id` int NOT NULL,
  `collection_invoice_id` int DEFAULT NULL,
  `balance_before` decimal(20,2) NOT NULL,
  `balance_after` decimal(20,2) NOT NULL,
  `amount` decimal(20,2) NOT NULL DEFAULT '0.00',
  `exchange_rate_id` int NOT NULL,
  `operation` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `user_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `collection_account_id` (`collection_account_id`),
  KEY `collection_id` (`collection_id`),
  KEY `collection_invoice_id` (`collection_invoice_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_finance_balance_collection_accounts_ibfk_1` FOREIGN KEY (`collection_account_id`) REFERENCES `dbo_finance_collection_accounts` (`id`),
  CONSTRAINT `dbo_finance_balance_collection_accounts_ibfk_2` FOREIGN KEY (`collection_id`) REFERENCES `dbo_administration_collections` (`id`),
  CONSTRAINT `dbo_finance_balance_collection_accounts_ibfk_3` FOREIGN KEY (`collection_invoice_id`) REFERENCES `dbo_administration_collection_invoices` (`id`),
  CONSTRAINT `dbo_finance_balance_collection_accounts_ibfk_4` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_finance_balance_collection_accounts_ibfk_5` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_balance_collection_accounts`
--

LOCK TABLES `dbo_finance_balance_collection_accounts` WRITE;
/*!40000 ALTER TABLE `dbo_finance_balance_collection_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_balance_collection_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_balance_provider_histories`
--

DROP TABLE IF EXISTS `dbo_finance_balance_provider_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_balance_provider_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `credit_before` float(20,2) DEFAULT NULL,
  `credit_after` float(20,2) DEFAULT NULL,
  `debit_before` float(20,2) DEFAULT NULL,
  `debit_after` float(20,2) DEFAULT NULL,
  `operation` varchar(255) DEFAULT NULL,
  `provider_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `exchange_rate_provider` float(20,2) DEFAULT NULL,
  `transaction_id` int DEFAULT NULL,
  `payment_id` int DEFAULT NULL,
  `retention_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `provider_id` (`provider_id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `payment_id` (`payment_id`),
  KEY `retention_id` (`retention_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_finance_balance_provider_histories_ibfk_1` FOREIGN KEY (`provider_id`) REFERENCES `dbo_config_companies` (`id`),
  CONSTRAINT `dbo_finance_balance_provider_histories_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_finance_balance_provider_histories_ibfk_3` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_finance_balance_provider_histories_ibfk_4` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`),
  CONSTRAINT `dbo_finance_balance_provider_histories_ibfk_5` FOREIGN KEY (`payment_id`) REFERENCES `dbo_administration_payment_expenses` (`id`),
  CONSTRAINT `dbo_finance_balance_provider_histories_ibfk_6` FOREIGN KEY (`retention_id`) REFERENCES `dbo_retention_tax_invoices` (`id`),
  CONSTRAINT `dbo_finance_balance_provider_histories_ibfk_7` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_balance_provider_histories`
--

LOCK TABLES `dbo_finance_balance_provider_histories` WRITE;
/*!40000 ALTER TABLE `dbo_finance_balance_provider_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_balance_provider_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_balance_providers`
--

DROP TABLE IF EXISTS `dbo_finance_balance_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_balance_providers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `credit` float(20,2) DEFAULT NULL,
  `debit` float(20,2) DEFAULT NULL,
  `provider_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `exchange_rate_provider` float(20,2) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `provider_id` (`provider_id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  CONSTRAINT `dbo_finance_balance_providers_ibfk_1` FOREIGN KEY (`provider_id`) REFERENCES `dbo_config_companies` (`id`),
  CONSTRAINT `dbo_finance_balance_providers_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_finance_balance_providers_ibfk_3` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_balance_providers`
--

LOCK TABLES `dbo_finance_balance_providers` WRITE;
/*!40000 ALTER TABLE `dbo_finance_balance_providers` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_balance_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_bank_mobile_payments`
--

DROP TABLE IF EXISTS `dbo_finance_bank_mobile_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_bank_mobile_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(4) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_bank_mobile_payments`
--

LOCK TABLES `dbo_finance_bank_mobile_payments` WRITE;
/*!40000 ALTER TABLE `dbo_finance_bank_mobile_payments` DISABLE KEYS */;
INSERT INTO `dbo_finance_bank_mobile_payments` VALUES (1,'BNC (Banco Nacional de Crédito)','0191','2024-10-16 22:53:36','2024-10-16 22:53:36'),(2,'Latin Pagos','0191','2024-10-16 22:53:36','2024-10-16 22:53:36');
/*!40000 ALTER TABLE `dbo_finance_bank_mobile_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_bank_payment_types`
--

DROP TABLE IF EXISTS `dbo_finance_bank_payment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_bank_payment_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `display_name` varchar(255) DEFAULT NULL,
  `payment_type_id` int DEFAULT NULL,
  `bank_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `show` tinyint(1) DEFAULT '1',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `accountancy_acc_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_type_id` (`payment_type_id`),
  KEY `bank_id` (`bank_id`),
  KEY `currency_id` (`currency_id`),
  KEY `dbo_finance_bank_payment_types_accountancy_acc_id_foreign_idx` (`accountancy_acc_id`),
  CONSTRAINT `dbo_finance_bank_payment_types_accountancy_acc_id_foreign_idx` FOREIGN KEY (`accountancy_acc_id`) REFERENCES `dbo_accountancy_accounts` (`id`),
  CONSTRAINT `dbo_finance_bank_payment_types_ibfk_1` FOREIGN KEY (`payment_type_id`) REFERENCES `dbo_finance_payment_types` (`id`),
  CONSTRAINT `dbo_finance_bank_payment_types_ibfk_2` FOREIGN KEY (`bank_id`) REFERENCES `dbo_finance_banks` (`id`),
  CONSTRAINT `dbo_finance_bank_payment_types_ibfk_3` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_bank_payment_types`
--

LOCK TABLES `dbo_finance_bank_payment_types` WRITE;
/*!40000 ALTER TABLE `dbo_finance_bank_payment_types` DISABLE KEYS */;
INSERT INTO `dbo_finance_bank_payment_types` VALUES (1,'Caja / Bs',2,6,2,1,'2024-10-16 22:37:11','2024-10-16 22:37:11',NULL),(2,'Caja / $',3,6,1,1,'2024-10-16 22:37:11','2024-10-16 22:37:11',NULL),(3,'Caja / Saldo',9,6,1,0,'2024-10-16 22:37:11','2024-10-16 22:37:11',NULL),(4,'Caja / N. Credito $',10,6,1,0,'2024-10-16 22:37:11','2024-10-16 22:37:11',NULL),(5,'Caja / N. Credito Bs',10,6,2,0,'2024-10-16 22:37:11','2024-10-16 22:37:11',NULL),(6,'America/Zelle',4,4,1,1,'2024-10-16 22:37:11','2024-10-16 22:37:11',NULL),(7,'BNC/Debito',1,3,2,1,'2024-10-16 22:37:11','2024-10-16 22:37:11',NULL),(8,'Banesco/Debito',1,2,2,1,'2024-10-16 22:37:11','2024-10-16 22:37:11',NULL),(9,'Bancamiga/Debito',1,1,2,1,'2024-10-16 22:37:11','2024-10-16 22:37:11',NULL),(10,'Caja Chica / Bs',2,6,2,0,'2024-10-16 22:37:12','2024-10-16 22:37:12',NULL),(11,'Caja Chica / $',2,6,1,0,'2024-10-16 22:37:12','2024-10-16 22:37:12',NULL);
/*!40000 ALTER TABLE `dbo_finance_bank_payment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_banks`
--

DROP TABLE IF EXISTS `dbo_finance_banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_banks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_banks`
--

LOCK TABLES `dbo_finance_banks` WRITE;
/*!40000 ALTER TABLE `dbo_finance_banks` DISABLE KEYS */;
INSERT INTO `dbo_finance_banks` VALUES (1,'Bancamiga','2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,'Banesco','2024-10-16 22:37:11','2024-10-16 22:37:11'),(3,'Banco Nacional de Credito (BNC)','2024-10-16 22:37:11','2024-10-16 22:37:11'),(4,'Bank of America','2024-10-16 22:37:11','2024-10-16 22:37:11'),(5,'Wells Fargo','2024-10-16 22:37:11','2024-10-16 22:37:11'),(6,'Caja','2024-10-16 22:37:11','2024-10-16 22:37:11'),(7,'Caja Chica','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_finance_banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_bankstatements`
--

DROP TABLE IF EXISTS `dbo_finance_bankstatements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_bankstatements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `balance_sequence` int DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_account_number` varchar(255) DEFAULT NULL,
  `operation_date` datetime DEFAULT NULL,
  `operation_description` varchar(255) DEFAULT NULL,
  `min_date` datetime DEFAULT NULL,
  `max_date` datetime DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `credit` decimal(20,2) DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_bankstatements`
--

LOCK TABLES `dbo_finance_bankstatements` WRITE;
/*!40000 ALTER TABLE `dbo_finance_bankstatements` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_bankstatements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_collection_accounts`
--

DROP TABLE IF EXISTS `dbo_finance_collection_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_collection_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `bank_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `bank_payment_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `balance` decimal(20,2) NOT NULL DEFAULT '0.00',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `bank_id` (`bank_id`),
  KEY `currency_id` (`currency_id`),
  KEY `bank_payment_type_id` (`bank_payment_type_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_finance_collection_accounts_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `dbo_finance_banks` (`id`),
  CONSTRAINT `dbo_finance_collection_accounts_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_finance_collection_accounts_ibfk_3` FOREIGN KEY (`bank_payment_type_id`) REFERENCES `dbo_finance_bank_payment_types` (`id`),
  CONSTRAINT `dbo_finance_collection_accounts_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_collection_accounts`
--

LOCK TABLES `dbo_finance_collection_accounts` WRITE;
/*!40000 ALTER TABLE `dbo_finance_collection_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_collection_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_collection_payment_statuses`
--

DROP TABLE IF EXISTS `dbo_finance_collection_payment_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_collection_payment_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_collection_payment_statuses`
--

LOCK TABLES `dbo_finance_collection_payment_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_finance_collection_payment_statuses` DISABLE KEYS */;
INSERT INTO `dbo_finance_collection_payment_statuses` VALUES (1,'GENERADO','2024-10-16 22:53:35','2024-10-16 22:53:35'),(2,'CONCILIADO','2024-10-16 22:53:35','2024-10-16 22:53:35');
/*!40000 ALTER TABLE `dbo_finance_collection_payment_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_collection_payments`
--

DROP TABLE IF EXISTS `dbo_finance_collection_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_collection_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `collection_id` int NOT NULL,
  `amount` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `user_id` int NOT NULL,
  `currency_id` int NOT NULL,
  `exchange_rate_id` int NOT NULL,
  `bank_payment_type_id` int DEFAULT NULL,
  `payment_status_id` int DEFAULT NULL,
  `payment_date` datetime NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `deposit` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `collection_id` (`collection_id`),
  KEY `user_id` (`user_id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `bank_payment_type_id` (`bank_payment_type_id`),
  KEY `payment_status_id` (`payment_status_id`),
  CONSTRAINT `dbo_finance_collection_payments_ibfk_1` FOREIGN KEY (`collection_id`) REFERENCES `dbo_administration_collections` (`id`),
  CONSTRAINT `dbo_finance_collection_payments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_finance_collection_payments_ibfk_3` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_finance_collection_payments_ibfk_4` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_finance_collection_payments_ibfk_5` FOREIGN KEY (`bank_payment_type_id`) REFERENCES `dbo_finance_bank_payment_types` (`id`),
  CONSTRAINT `dbo_finance_collection_payments_ibfk_6` FOREIGN KEY (`payment_status_id`) REFERENCES `dbo_finance_collection_payment_statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_collection_payments`
--

LOCK TABLES `dbo_finance_collection_payments` WRITE;
/*!40000 ALTER TABLE `dbo_finance_collection_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_collection_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_creditnote_reasons`
--

DROP TABLE IF EXISTS `dbo_finance_creditnote_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_creditnote_reasons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_creditnote_reasons`
--

LOCK TABLES `dbo_finance_creditnote_reasons` WRITE;
/*!40000 ALTER TABLE `dbo_finance_creditnote_reasons` DISABLE KEYS */;
INSERT INTO `dbo_finance_creditnote_reasons` VALUES (1,'PRODUCTO FALTANTE','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'PRODUCTO EN MAL ESTADO','2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'PRODUCTO VENCIDO','2024-10-16 22:37:10','2024-10-16 22:37:10'),(4,'PRODUCTO PROXIMO A VENCER','2024-10-16 22:37:10','2024-10-16 22:37:10'),(5,'PRODUCTO NO SOLICITADO','2024-10-16 22:37:10','2024-10-16 22:37:10'),(6,'PRODUCTO CON DIFERENCIA DE PRECIO','2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_finance_creditnote_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_creditnotes`
--

DROP TABLE IF EXISTS `dbo_finance_creditnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_creditnotes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creditnote_number` int DEFAULT NULL,
  `coupon_number` int DEFAULT NULL,
  `client_id` int NOT NULL,
  `invoice_id` int DEFAULT NULL,
  `creditnote_amount` decimal(20,2) DEFAULT NULL,
  `creditnote_type_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `currency_id` int DEFAULT '1',
  `exchange_rate_id` int DEFAULT NULL,
  `observations` varchar(255) DEFAULT NULL,
  `status_id` int DEFAULT '1',
  `payment_id` int DEFAULT '0',
  `fiscal` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `creditnote_type_id` (`creditnote_type_id`),
  KEY `user_id` (`user_id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `dbo_finance_creditnotes_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_ibfk_3` FOREIGN KEY (`creditnote_type_id`) REFERENCES `dbo_finance_creditnotes_types` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_ibfk_5` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_ibfk_6` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_ibfk_7` FOREIGN KEY (`status_id`) REFERENCES `dbo_finance_creditnotes_statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_creditnotes`
--

LOCK TABLES `dbo_finance_creditnotes` WRITE;
/*!40000 ALTER TABLE `dbo_finance_creditnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_creditnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_creditnotes_histories`
--

DROP TABLE IF EXISTS `dbo_finance_creditnotes_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_creditnotes_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creditnote_id` int DEFAULT NULL,
  `creditnote_status_id` int DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `creditnote_id` (`creditnote_id`),
  KEY `creditnote_status_id` (`creditnote_status_id`),
  CONSTRAINT `dbo_finance_creditnotes_histories_ibfk_1` FOREIGN KEY (`creditnote_id`) REFERENCES `dbo_finance_creditnotes` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_histories_ibfk_2` FOREIGN KEY (`creditnote_status_id`) REFERENCES `dbo_finance_creditnotes_statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_creditnotes_histories`
--

LOCK TABLES `dbo_finance_creditnotes_histories` WRITE;
/*!40000 ALTER TABLE `dbo_finance_creditnotes_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_creditnotes_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_creditnotes_items`
--

DROP TABLE IF EXISTS `dbo_finance_creditnotes_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_creditnotes_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `creditnote_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `inventory_id` int DEFAULT NULL,
  `product_quantity` int DEFAULT NULL,
  `net_amount` decimal(20,2) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `observations` varchar(255) DEFAULT NULL,
  `creditnote_reason_id` int DEFAULT NULL,
  `unit_price_after_discount` decimal(20,2) DEFAULT '0.00',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `creditnote_id` (`creditnote_id`),
  KEY `product_id` (`product_id`),
  KEY `inventory_id` (`inventory_id`),
  KEY `user_id` (`user_id`),
  KEY `creditnote_reason_id` (`creditnote_reason_id`),
  CONSTRAINT `dbo_finance_creditnotes_items_ibfk_1` FOREIGN KEY (`creditnote_id`) REFERENCES `dbo_finance_creditnotes` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_items_ibfk_3` FOREIGN KEY (`inventory_id`) REFERENCES `dbo_storage_inventories` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_items_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_finance_creditnotes_items_ibfk_5` FOREIGN KEY (`creditnote_reason_id`) REFERENCES `dbo_finance_creditnote_reasons` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_creditnotes_items`
--

LOCK TABLES `dbo_finance_creditnotes_items` WRITE;
/*!40000 ALTER TABLE `dbo_finance_creditnotes_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_creditnotes_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_creditnotes_statuses`
--

DROP TABLE IF EXISTS `dbo_finance_creditnotes_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_creditnotes_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_creditnotes_statuses`
--

LOCK TABLES `dbo_finance_creditnotes_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_finance_creditnotes_statuses` DISABLE KEYS */;
INSERT INTO `dbo_finance_creditnotes_statuses` VALUES (1,'GENERADA','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'ANULADA','2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'CAUSADA','2024-10-16 22:37:10','2024-10-16 22:37:10'),(4,'PENDIENTE','2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_finance_creditnotes_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_creditnotes_types`
--

DROP TABLE IF EXISTS `dbo_finance_creditnotes_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_creditnotes_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_creditnotes_types`
--

LOCK TABLES `dbo_finance_creditnotes_types` WRITE;
/*!40000 ALTER TABLE `dbo_finance_creditnotes_types` DISABLE KEYS */;
INSERT INTO `dbo_finance_creditnotes_types` VALUES (1,'DEVOLUCIONES','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'ERRORES (PRECIOS O PAGOS)','2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'ANULACIONES','2024-10-16 22:37:10','2024-10-16 22:37:10'),(4,'RETENCIÓN DE IVA','2024-10-16 22:37:10','2024-10-16 22:37:10'),(5,'DESCUENTO DE IVA','2024-10-16 22:37:10','2024-10-16 22:37:10'),(6,'OTROS','2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_finance_creditnotes_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_debitnote_reasons`
--

DROP TABLE IF EXISTS `dbo_finance_debitnote_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_debitnote_reasons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_debitnote_reasons`
--

LOCK TABLES `dbo_finance_debitnote_reasons` WRITE;
/*!40000 ALTER TABLE `dbo_finance_debitnote_reasons` DISABLE KEYS */;
INSERT INTO `dbo_finance_debitnote_reasons` VALUES (1,'DEVOLUCIONES','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'ERRORES (PRECIOS O PAGOS)','2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'ANULACIONES','2024-10-16 22:37:10','2024-10-16 22:37:10'),(4,'RETENCIÓN DE IVA','2024-10-16 22:37:10','2024-10-16 22:37:10'),(5,'OTROS','2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_finance_debitnote_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_debitnotes`
--

DROP TABLE IF EXISTS `dbo_finance_debitnotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_debitnotes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `debitnote_number` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `debitnote_amount` decimal(20,2) DEFAULT NULL,
  `debitnote_type_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `currency_id` int DEFAULT '1',
  `exchange_rate_id` int DEFAULT NULL,
  `observations` varchar(255) DEFAULT NULL,
  `status_id` int DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `debitnote_type_id` (`debitnote_type_id`),
  KEY `user_id` (`user_id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `dbo_finance_debitnotes_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_ibfk_3` FOREIGN KEY (`debitnote_type_id`) REFERENCES `dbo_finance_debitnotes_types` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_ibfk_5` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_ibfk_6` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_ibfk_7` FOREIGN KEY (`status_id`) REFERENCES `dbo_finance_debitnotes_statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_debitnotes`
--

LOCK TABLES `dbo_finance_debitnotes` WRITE;
/*!40000 ALTER TABLE `dbo_finance_debitnotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_debitnotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_debitnotes_histories`
--

DROP TABLE IF EXISTS `dbo_finance_debitnotes_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_debitnotes_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `debitnote_id` int DEFAULT NULL,
  `debitnote_status_id` int DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `debitnote_id` (`debitnote_id`),
  KEY `debitnote_status_id` (`debitnote_status_id`),
  CONSTRAINT `dbo_finance_debitnotes_histories_ibfk_1` FOREIGN KEY (`debitnote_id`) REFERENCES `dbo_finance_debitnotes` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_histories_ibfk_2` FOREIGN KEY (`debitnote_status_id`) REFERENCES `dbo_finance_debitnotes_statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_debitnotes_histories`
--

LOCK TABLES `dbo_finance_debitnotes_histories` WRITE;
/*!40000 ALTER TABLE `dbo_finance_debitnotes_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_debitnotes_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_debitnotes_items`
--

DROP TABLE IF EXISTS `dbo_finance_debitnotes_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_debitnotes_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `debitnote_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `inventory_id` int DEFAULT NULL,
  `product_quantity` int DEFAULT NULL,
  `net_amount` decimal(20,2) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `observations` varchar(255) DEFAULT NULL,
  `debitnote_reason_id` int DEFAULT NULL,
  `unit_price_after_discount` decimal(20,2) DEFAULT '0.00',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `debitnote_id` (`debitnote_id`),
  KEY `product_id` (`product_id`),
  KEY `inventory_id` (`inventory_id`),
  KEY `user_id` (`user_id`),
  KEY `debitnote_reason_id` (`debitnote_reason_id`),
  CONSTRAINT `dbo_finance_debitnotes_items_ibfk_1` FOREIGN KEY (`debitnote_id`) REFERENCES `dbo_finance_debitnotes` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_items_ibfk_3` FOREIGN KEY (`inventory_id`) REFERENCES `dbo_storage_inventories` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_items_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_finance_debitnotes_items_ibfk_5` FOREIGN KEY (`debitnote_reason_id`) REFERENCES `dbo_finance_debitnote_reasons` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_debitnotes_items`
--

LOCK TABLES `dbo_finance_debitnotes_items` WRITE;
/*!40000 ALTER TABLE `dbo_finance_debitnotes_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_debitnotes_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_debitnotes_statuses`
--

DROP TABLE IF EXISTS `dbo_finance_debitnotes_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_debitnotes_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_debitnotes_statuses`
--

LOCK TABLES `dbo_finance_debitnotes_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_finance_debitnotes_statuses` DISABLE KEYS */;
INSERT INTO `dbo_finance_debitnotes_statuses` VALUES (1,'GENERADA','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'ANULADA','2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'PAGADA','2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_finance_debitnotes_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_debitnotes_types`
--

DROP TABLE IF EXISTS `dbo_finance_debitnotes_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_debitnotes_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_debitnotes_types`
--

LOCK TABLES `dbo_finance_debitnotes_types` WRITE;
/*!40000 ALTER TABLE `dbo_finance_debitnotes_types` DISABLE KEYS */;
INSERT INTO `dbo_finance_debitnotes_types` VALUES (1,'Error en facturación','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'Error IVA','2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'Otros','2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_finance_debitnotes_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_pay_to_clients`
--

DROP TABLE IF EXISTS `dbo_finance_pay_to_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_pay_to_clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `user_id` int NOT NULL,
  `bank_id` int NOT NULL,
  `currency_id` int NOT NULL,
  `exchange_rate_id` int NOT NULL,
  `pay_type_id` int NOT NULL,
  `amount` decimal(20,2) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `company_bank_account_id` int DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `user_id` (`user_id`),
  KEY `bank_id` (`bank_id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `pay_type_id` (`pay_type_id`),
  KEY `dbo_finance_pay_to_clients_company_bank_account_id_foreign_idx` (`company_bank_account_id`),
  CONSTRAINT `dbo_finance_pay_to_clients_company_bank_account_id_foreign_idx` FOREIGN KEY (`company_bank_account_id`) REFERENCES `dbo_administration_my_company_accounts` (`id`),
  CONSTRAINT `dbo_finance_pay_to_clients_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_finance_pay_to_clients_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_finance_pay_to_clients_ibfk_3` FOREIGN KEY (`bank_id`) REFERENCES `dbo_finance_banks` (`id`),
  CONSTRAINT `dbo_finance_pay_to_clients_ibfk_4` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_finance_pay_to_clients_ibfk_5` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_finance_pay_to_clients_ibfk_6` FOREIGN KEY (`pay_type_id`) REFERENCES `dbo_finance_pay_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_pay_to_clients`
--

LOCK TABLES `dbo_finance_pay_to_clients` WRITE;
/*!40000 ALTER TABLE `dbo_finance_pay_to_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_pay_to_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_pay_types`
--

DROP TABLE IF EXISTS `dbo_finance_pay_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_pay_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_pay_types`
--

LOCK TABLES `dbo_finance_pay_types` WRITE;
/*!40000 ALTER TABLE `dbo_finance_pay_types` DISABLE KEYS */;
INSERT INTO `dbo_finance_pay_types` VALUES (1,'Transferencia','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,'Pago Movil','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_finance_pay_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_payment_banks`
--

DROP TABLE IF EXISTS `dbo_finance_payment_banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_payment_banks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(4) NOT NULL,
  `rif` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_payment_banks`
--

LOCK TABLES `dbo_finance_payment_banks` WRITE;
/*!40000 ALTER TABLE `dbo_finance_payment_banks` DISABLE KEYS */;
INSERT INTO `dbo_finance_payment_banks` VALUES (1,'100% BANCO','0156','J085007768','2024-10-16 22:53:37','2024-10-16 22:53:37'),(2,'BANCAMIGA','0172','J316287599','2024-10-16 22:53:37','2024-10-16 22:53:37'),(3,'BANCO ACTIVO','0171','J080066227','2024-10-16 22:53:37','2024-10-16 22:53:37'),(4,'BANCO AGRÍCOLA DE VENEZUELA','0166','G200057955','2024-10-16 22:53:37','2024-10-16 22:53:37'),(5,'BANCO BICENTENARIO','0175','G200091487','2024-10-16 22:53:37','2024-10-16 22:53:37'),(6,'BANCO CARONÍ','0128','J095048551','2024-10-16 22:53:37','2024-10-16 22:53:37'),(7,'BANCO DE COMERCIO EXTERIOR','0115','J000029504','2024-10-16 22:53:37','2024-10-16 22:53:37'),(8,'BANCO DE DESARROLLO ECONÓMICO Y SOCIAL DE VENEZUELA','0137','J000029504','2024-10-16 22:53:37','2024-10-16 22:53:37'),(9,'BANCO DE LA FUERZA ARMADA NACIONAL BOLIVARIANA','0177','G200106573','2024-10-16 22:53:37','2024-10-16 22:53:37'),(10,'BANCO DE LA GENTE EMPRENDEDORA','0146','J301442040','2024-10-16 22:53:37','2024-10-16 22:53:37'),(11,'BANCO DE VENEZUELA','0102','G200099976','2024-10-16 22:53:37','2024-10-16 22:53:37'),(12,'BANCO DEL CARIBE','0114','J000029490','2024-10-16 22:53:37','2024-10-16 22:53:37'),(13,'BANCO DEL TESORO','0163','G200051876','2024-10-16 22:53:37','2024-10-16 22:53:37'),(14,'BANCO EXTERIOR','0115','J000029504','2024-10-16 22:53:37','2024-10-16 22:53:37'),(15,'BANCO INTERNACIONAL DE DESARROLLO','0115','J300619460','2024-10-16 22:53:37','2024-10-16 22:53:37'),(16,'BANCO NACIONAL DE CRÉDITO','0191','J309841327','2024-10-16 22:53:37','2024-10-16 22:53:37'),(17,'BANCO NACIONAL DE VIVIENDA Y HABITAT','0191','J309841327','2024-10-16 22:53:37','2024-10-16 22:53:37'),(18,'BANCO PLAZA','0138','J002970553','2024-10-16 22:53:37','2024-10-16 22:53:37'),(19,'BANCO PROVINCIAL','0108','J000029679','2024-10-16 22:53:37','2024-10-16 22:53:37'),(20,'BANCO SOFITASA','0137','J090283846','2024-10-16 22:53:37','2024-10-16 22:53:37'),(21,'BANCRECER','0168','J316374173','2024-10-16 22:53:37','2024-10-16 22:53:37'),(22,'BANESCO BANCO UNIVERSAL','0134','J070133805','2024-10-16 22:53:37','2024-10-16 22:53:37'),(23,'BANPLUS BANCO UNIVERSAL','0174','J000423032','2024-10-16 22:53:37','2024-10-16 22:53:37'),(24,'BANCO FONDO COMUN','0151','J000723060','2024-10-16 22:53:37','2024-10-16 22:53:37'),(25,'DEL SUR BANCO UNIVERSAL','0157','J000797234','2024-10-16 22:53:37','2024-10-16 22:53:37'),(26,'INSTITUTO MUNICIPAL DE CRÉDITO POPULAR','0104','J000029709','2024-10-16 22:53:37','2024-10-16 22:53:37'),(27,'MERCANTIL','0105','J000029610','2024-10-16 22:53:37','2024-10-16 22:53:37'),(28,'MI BANCO','0169','J315941023','2024-10-16 22:53:37','2024-10-16 22:53:37'),(29,'VENEZOLANO DE CRÉDITO','0104','J000029709','2024-10-16 22:53:37','2024-10-16 22:53:37'),(30,'N58 BANCO DIGITAL','0104','J000029709','2024-10-16 22:53:37','2024-10-16 22:53:37');
/*!40000 ALTER TABLE `dbo_finance_payment_banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_payment_expense_statuses`
--

DROP TABLE IF EXISTS `dbo_finance_payment_expense_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_payment_expense_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_payment_expense_statuses`
--

LOCK TABLES `dbo_finance_payment_expense_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_finance_payment_expense_statuses` DISABLE KEYS */;
INSERT INTO `dbo_finance_payment_expense_statuses` VALUES (1,'GENERADA','2024-10-16 22:37:13','2024-10-16 22:37:13'),(2,'EN CONTABILIDAD','2024-10-16 22:37:13','2024-10-16 22:37:13'),(3,'ANULADA','2024-10-16 22:37:13','2024-10-16 22:37:13');
/*!40000 ALTER TABLE `dbo_finance_payment_expense_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_payment_types`
--

DROP TABLE IF EXISTS `dbo_finance_payment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_payment_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `type_currency_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `type_currency_id` (`type_currency_id`),
  CONSTRAINT `dbo_finance_payment_types_ibfk_1` FOREIGN KEY (`type_currency_id`) REFERENCES `dbo_type_currencies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_payment_types`
--

LOCK TABLES `dbo_finance_payment_types` WRITE;
/*!40000 ALTER TABLE `dbo_finance_payment_types` DISABLE KEYS */;
INSERT INTO `dbo_finance_payment_types` VALUES (1,'T.Débito',1,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'Efectivo Bs',2,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'Efectivo $',2,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(4,'Zelle',1,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(5,'Cheque',1,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(6,'Transf/Dep',1,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(7,'T.Crédito',1,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(8,'Cesta Ticket',1,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(9,'Saldo',1,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(10,'Credito',1,'2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_finance_payment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_payments`
--

DROP TABLE IF EXISTS `dbo_finance_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` decimal(20,2) NOT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `bank_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `payment_type_id` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `deposit` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `bank_id` (`bank_id`),
  KEY `client_id` (`client_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `user_id` (`user_id`),
  KEY `payment_type_id` (`payment_type_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_finance_payments_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `dbo_finance_banks` (`id`),
  CONSTRAINT `dbo_finance_payments_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_finance_payments_ibfk_3` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_finance_payments_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_finance_payments_ibfk_5` FOREIGN KEY (`payment_type_id`) REFERENCES `dbo_finance_payment_types` (`id`),
  CONSTRAINT `dbo_finance_payments_ibfk_6` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_finance_payments_ibfk_7` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_payments`
--

LOCK TABLES `dbo_finance_payments` WRITE;
/*!40000 ALTER TABLE `dbo_finance_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_payments_informals`
--

DROP TABLE IF EXISTS `dbo_finance_payments_informals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_payments_informals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT '0.00',
  `user_id` int DEFAULT NULL,
  `informal_provider_id` varchar(255) DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `accountancy_id` int DEFAULT NULL,
  `bank_account_id` int DEFAULT NULL,
  `payment_type_id` int DEFAULT NULL,
  `status_id` int DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_payments_informals`
--

LOCK TABLES `dbo_finance_payments_informals` WRITE;
/*!40000 ALTER TABLE `dbo_finance_payments_informals` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_payments_informals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_selected_payments`
--

DROP TABLE IF EXISTS `dbo_finance_selected_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_selected_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` decimal(20,2) NOT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `bank_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `payment_type_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `bank_id` (`bank_id`),
  KEY `client_id` (`client_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `user_id` (`user_id`),
  KEY `payment_type_id` (`payment_type_id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_finance_selected_payments_ibfk_1` FOREIGN KEY (`bank_id`) REFERENCES `dbo_finance_banks` (`id`),
  CONSTRAINT `dbo_finance_selected_payments_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_finance_selected_payments_ibfk_3` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_finance_selected_payments_ibfk_4` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_finance_selected_payments_ibfk_5` FOREIGN KEY (`payment_type_id`) REFERENCES `dbo_finance_payment_types` (`id`),
  CONSTRAINT `dbo_finance_selected_payments_ibfk_6` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_selected_payments`
--

LOCK TABLES `dbo_finance_selected_payments` WRITE;
/*!40000 ALTER TABLE `dbo_finance_selected_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_selected_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_standingpayments`
--

DROP TABLE IF EXISTS `dbo_finance_standingpayments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_standingpayments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `provider_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `accountancy_id` int DEFAULT NULL,
  `bank_destination_account_id` int DEFAULT NULL,
  `bank_account_id` int DEFAULT NULL,
  `payment_type_id` int DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `payment_date` datetime NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_standingpayments`
--

LOCK TABLES `dbo_finance_standingpayments` WRITE;
/*!40000 ALTER TABLE `dbo_finance_standingpayments` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_standingpayments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finance_systemstatements`
--

DROP TABLE IF EXISTS `dbo_finance_systemstatements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finance_systemstatements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `balance_sequence` int DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_account_number` varchar(255) DEFAULT NULL,
  `operation_date` datetime DEFAULT NULL,
  `operation_description` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `credit` decimal(20,2) DEFAULT NULL,
  `debit` decimal(20,2) DEFAULT NULL,
  `min_date` datetime NOT NULL,
  `max_date` datetime NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finance_systemstatements`
--

LOCK TABLES `dbo_finance_systemstatements` WRITE;
/*!40000 ALTER TABLE `dbo_finance_systemstatements` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finance_systemstatements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finances_balances`
--

DROP TABLE IF EXISTS `dbo_finances_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finances_balances` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` decimal(20,2) DEFAULT '0.00',
  `client_id` int NOT NULL,
  `currency_id` int NOT NULL DEFAULT '1',
  `exchange_rate_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  CONSTRAINT `dbo_finances_balances_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_finances_balances_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_finances_balances_ibfk_3` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finances_balances`
--

LOCK TABLES `dbo_finances_balances` WRITE;
/*!40000 ALTER TABLE `dbo_finances_balances` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finances_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_finances_balances_histories`
--

DROP TABLE IF EXISTS `dbo_finances_balances_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_finances_balances_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount_before` decimal(20,2) DEFAULT '0.00',
  `amount_after` decimal(20,2) DEFAULT '0.00',
  `operation` enum('+','-') DEFAULT NULL,
  `client_id` int NOT NULL,
  `currency_id` int NOT NULL DEFAULT '1',
  `invoice_id` int DEFAULT NULL,
  `payment_id` int DEFAULT NULL,
  `exchange_rate_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `observation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `currency_id` (`currency_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `payment_id` (`payment_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  CONSTRAINT `dbo_finances_balances_histories_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_finances_balances_histories_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_finances_balances_histories_ibfk_3` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_finances_balances_histories_ibfk_4` FOREIGN KEY (`payment_id`) REFERENCES `dbo_finance_payments` (`id`),
  CONSTRAINT `dbo_finances_balances_histories_ibfk_5` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_finances_balances_histories`
--

LOCK TABLES `dbo_finances_balances_histories` WRITE;
/*!40000 ALTER TABLE `dbo_finances_balances_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_finances_balances_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_navigation_routes`
--

DROP TABLE IF EXISTS `dbo_navigation_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_navigation_routes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_navigation_routes`
--

LOCK TABLES `dbo_navigation_routes` WRITE;
/*!40000 ALTER TABLE `dbo_navigation_routes` DISABLE KEYS */;
INSERT INTO `dbo_navigation_routes` VALUES (1,'PDV',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(2,'Almacén',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(3,'Administración',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(4,'Retenciones',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(5,'Finanzas',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(6,'Contabilidad',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(7,'Configuraciones',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(8,'Buscar',1,'2024-10-16 22:53:35','2024-10-16 22:53:35');
/*!40000 ALTER TABLE `dbo_navigation_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_payment_exchange_rate_amounts`
--

DROP TABLE IF EXISTS `dbo_payment_exchange_rate_amounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_payment_exchange_rate_amounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_id` int NOT NULL,
  `exchange_rate_amount` float DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  CONSTRAINT `dbo_payment_exchange_rate_amounts_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_payment_exchange_rate_amounts`
--

LOCK TABLES `dbo_payment_exchange_rate_amounts` WRITE;
/*!40000 ALTER TABLE `dbo_payment_exchange_rate_amounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_payment_exchange_rate_amounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_bank_payment_types`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_bank_payment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_bank_payment_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cash_register_id` int DEFAULT NULL,
  `bank_payment_type_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `cash_register_id` (`cash_register_id`),
  KEY `bank_payment_type_id` (`bank_payment_type_id`),
  CONSTRAINT `dbo_pos_cash_register_bank_payment_types_ibfk_1` FOREIGN KEY (`cash_register_id`) REFERENCES `dbo_pos_cash_registers` (`id`),
  CONSTRAINT `dbo_pos_cash_register_bank_payment_types_ibfk_2` FOREIGN KEY (`bank_payment_type_id`) REFERENCES `dbo_finance_bank_payment_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_bank_payment_types`
--

LOCK TABLES `dbo_pos_cash_register_bank_payment_types` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_bank_payment_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_bank_payment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_categories`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cash_register_id` int NOT NULL,
  `category_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `cash_register_id` (`cash_register_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `dbo_pos_cash_register_categories_ibfk_1` FOREIGN KEY (`cash_register_id`) REFERENCES `dbo_pos_cash_registers` (`id`),
  CONSTRAINT `dbo_pos_cash_register_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `dbo_storage_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_categories`
--

LOCK TABLES `dbo_pos_cash_register_categories` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_close_amounts`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_close_amounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_close_amounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `total` decimal(20,2) DEFAULT '0.00',
  `total_electronic` decimal(20,2) DEFAULT '0.00',
  `total_cash` decimal(20,2) DEFAULT '0.00',
  `initial_amount` decimal(20,2) DEFAULT '0.00',
  `real_amount` decimal(20,2) DEFAULT '0.00',
  `diff_invoiced_cash` tinyint(1) NOT NULL DEFAULT '0',
  `diff_invoiced_electronic` tinyint(1) NOT NULL DEFAULT '0',
  `currency_id` int DEFAULT '2',
  `cash_register_closes_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`),
  KEY `cash_register_closes_id` (`cash_register_closes_id`),
  CONSTRAINT `dbo_pos_cash_register_close_amounts_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_pos_cash_register_close_amounts_ibfk_2` FOREIGN KEY (`cash_register_closes_id`) REFERENCES `dbo_pos_cash_register_closes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_close_amounts`
--

LOCK TABLES `dbo_pos_cash_register_close_amounts` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_close_amounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_close_amounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_close_payments`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_close_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_close_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_id` int NOT NULL,
  `cash_register_close_id` int NOT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `payment_id` (`payment_id`),
  KEY `cash_register_close_id` (`cash_register_close_id`),
  CONSTRAINT `dbo_pos_cash_register_close_payments_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `dbo_finance_payments` (`id`),
  CONSTRAINT `dbo_pos_cash_register_close_payments_ibfk_2` FOREIGN KEY (`cash_register_close_id`) REFERENCES `dbo_pos_cash_register_closes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_close_payments`
--

LOCK TABLES `dbo_pos_cash_register_close_payments` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_close_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_close_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_close_statuses`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_close_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_close_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_close_statuses`
--

LOCK TABLES `dbo_pos_cash_register_close_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_close_statuses` DISABLE KEYS */;
INSERT INTO `dbo_pos_cash_register_close_statuses` VALUES (1,'ABIERTO','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'VERIFICACIÓN','2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'CERRADO','2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_pos_cash_register_close_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_close_withdraws`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_close_withdraws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_close_withdraws` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cash_register_close_id` int NOT NULL,
  `withdraw_id` int NOT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_register_close_id` (`cash_register_close_id`),
  KEY `withdraw_id` (`withdraw_id`),
  CONSTRAINT `dbo_pos_cash_register_close_withdraws_ibfk_1` FOREIGN KEY (`cash_register_close_id`) REFERENCES `dbo_pos_cash_register_closes` (`id`),
  CONSTRAINT `dbo_pos_cash_register_close_withdraws_ibfk_2` FOREIGN KEY (`withdraw_id`) REFERENCES `dbo_pos_withdraws` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_close_withdraws`
--

LOCK TABLES `dbo_pos_cash_register_close_withdraws` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_close_withdraws` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_close_withdraws` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_closes`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_closes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_closes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `closeDate` datetime DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `admin_user_id` int DEFAULT NULL,
  `status_id` int DEFAULT '1',
  `cash_register_id` int DEFAULT NULL,
  `dbo_pos_daily_closes_id` int DEFAULT NULL,
  `total_product` int DEFAULT '0',
  `total_unit` int DEFAULT '0',
  `total_invoices` int DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cash_register_daily_id` int DEFAULT NULL,
  `printer_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `admin_user_id` (`admin_user_id`),
  KEY `status_id` (`status_id`),
  KEY `cash_register_id` (`cash_register_id`),
  KEY `dbo_pos_daily_closes_id` (`dbo_pos_daily_closes_id`),
  KEY `dbo_pos_cash_register_closes_cash_register_daily_id_foreign_idx` (`cash_register_daily_id`),
  KEY `dbo_pos_cash_register_closes_printer_id_foreign_idx` (`printer_id`),
  CONSTRAINT `dbo_pos_cash_register_closes_cash_register_daily_id_foreign_idx` FOREIGN KEY (`cash_register_daily_id`) REFERENCES `dbo_pos_cash_register_dailies` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_ibfk_2` FOREIGN KEY (`admin_user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `dbo_pos_cash_register_close_statuses` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_ibfk_4` FOREIGN KEY (`cash_register_id`) REFERENCES `dbo_pos_cash_registers` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_ibfk_5` FOREIGN KEY (`dbo_pos_daily_closes_id`) REFERENCES `dbo_pos_daily_closes` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_printer_id_foreign_idx` FOREIGN KEY (`printer_id`) REFERENCES `dbo_printer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_closes`
--

LOCK TABLES `dbo_pos_cash_register_closes` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_closes` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_closes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_closes_all_currencies`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_closes_all_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_closes_all_currencies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cash_register_close_id` int DEFAULT NULL,
  `closeDate` datetime DEFAULT NULL,
  `total_invoices` int DEFAULT '0',
  `total_product` int DEFAULT '0',
  `total_unit` int DEFAULT '0',
  `total` decimal(20,2) DEFAULT '0.00',
  `tax_base` decimal(20,2) DEFAULT '0.00',
  `subtotal` decimal(20,2) DEFAULT '0.00',
  `tax` decimal(20,2) DEFAULT '0.00',
  `retention_tax` decimal(20,2) DEFAULT '0.00',
  `tax_to_pay` decimal(20,2) DEFAULT '0.00',
  `total_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_base_without_discount` decimal(20,2) DEFAULT '0.00',
  `subtotal_without_discount` decimal(20,2) DEFAULT '0.00',
  `tax_without_discount` decimal(20,2) DEFAULT '0.00',
  `discount` decimal(20,2) DEFAULT '0.00',
  `electronicTotal` decimal(20,2) DEFAULT '0.00',
  `cashTotal` decimal(20,2) DEFAULT '0.00',
  `user_id` int DEFAULT NULL,
  `admin_user_id` int DEFAULT NULL,
  `status_id` int DEFAULT '1',
  `cash_register_id` int DEFAULT NULL,
  `dbo_pos_daily_closes_id` int DEFAULT NULL,
  `currency_id` int DEFAULT '2',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `cash_register_close_id` (`cash_register_close_id`),
  KEY `user_id` (`user_id`),
  KEY `admin_user_id` (`admin_user_id`),
  KEY `status_id` (`status_id`),
  KEY `cash_register_id` (`cash_register_id`),
  KEY `dbo_pos_daily_closes_id` (`dbo_pos_daily_closes_id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_pos_cash_register_closes_all_currencies_ibfk_1` FOREIGN KEY (`cash_register_close_id`) REFERENCES `dbo_pos_cash_register_closes` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_all_currencies_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_all_currencies_ibfk_3` FOREIGN KEY (`admin_user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_all_currencies_ibfk_4` FOREIGN KEY (`status_id`) REFERENCES `dbo_pos_cash_register_close_statuses` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_all_currencies_ibfk_5` FOREIGN KEY (`cash_register_id`) REFERENCES `dbo_pos_cash_registers` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_all_currencies_ibfk_6` FOREIGN KEY (`dbo_pos_daily_closes_id`) REFERENCES `dbo_pos_daily_closes` (`id`),
  CONSTRAINT `dbo_pos_cash_register_closes_all_currencies_ibfk_7` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_closes_all_currencies`
--

LOCK TABLES `dbo_pos_cash_register_closes_all_currencies` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_closes_all_currencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_closes_all_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_dailies`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_dailies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_dailies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quantity_cash_register` int DEFAULT '0',
  `total_invoices` int DEFAULT '0',
  `total_items` int DEFAULT '0',
  `total_products` int DEFAULT '0',
  `total_bs` double DEFAULT '0',
  `total_usd` double DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fiscal_sequence` int DEFAULT NULL,
  `printer_id` int DEFAULT NULL,
  `print_z` tinyint(1) DEFAULT '0',
  `all_close` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `dbo_pos_cash_register_dailies_printer_id_foreign_idx` (`printer_id`),
  CONSTRAINT `dbo_pos_cash_register_dailies_printer_id_foreign_idx` FOREIGN KEY (`printer_id`) REFERENCES `dbo_printer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_dailies`
--

LOCK TABLES `dbo_pos_cash_register_dailies` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_dailies` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_dailies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_electronic_ends`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_electronic_ends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_electronic_ends` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount_manual` decimal(20,2) NOT NULL,
  `currency_id` int NOT NULL,
  `dbo_finance_bank_payment_types_id` int NOT NULL,
  `cash_register_closes_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `observation` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`),
  KEY `dbo_finance_bank_payment_types_id` (`dbo_finance_bank_payment_types_id`),
  KEY `cash_register_closes_id` (`cash_register_closes_id`),
  CONSTRAINT `dbo_pos_cash_register_electronic_ends_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_pos_cash_register_electronic_ends_ibfk_2` FOREIGN KEY (`dbo_finance_bank_payment_types_id`) REFERENCES `dbo_finance_bank_payment_types` (`id`),
  CONSTRAINT `dbo_pos_cash_register_electronic_ends_ibfk_3` FOREIGN KEY (`cash_register_closes_id`) REFERENCES `dbo_pos_cash_register_closes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_electronic_ends`
--

LOCK TABLES `dbo_pos_cash_register_electronic_ends` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_electronic_ends` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_electronic_ends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_ends`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_ends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_ends` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` decimal(20,2) NOT NULL,
  `currency_id` int NOT NULL,
  `exchange_rate_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  CONSTRAINT `dbo_pos_cash_register_ends_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_pos_cash_register_ends_ibfk_2` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_ends`
--

LOCK TABLES `dbo_pos_cash_register_ends` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_ends` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_ends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_global_histories`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_global_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_global_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cash_register_global_id` int NOT NULL,
  `old_cash` decimal(20,2) NOT NULL,
  `cash` decimal(20,2) NOT NULL,
  `new_cash` decimal(20,2) NOT NULL,
  `transaction_id` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `refund_id` int DEFAULT NULL,
  `cash_register_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `user_receptor_id` int DEFAULT NULL,
  `operation` enum('+','-') DEFAULT NULL,
  `observation` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `cash_register_global_id` (`cash_register_global_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `refund_id` (`refund_id`),
  KEY `cash_register_id` (`cash_register_id`),
  KEY `user_id` (`user_id`),
  KEY `user_receptor_id` (`user_receptor_id`),
  CONSTRAINT `dbo_pos_cash_register_global_histories_ibfk_1` FOREIGN KEY (`cash_register_global_id`) REFERENCES `dbo_pos_cash_register_globals` (`id`),
  CONSTRAINT `dbo_pos_cash_register_global_histories_ibfk_2` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`),
  CONSTRAINT `dbo_pos_cash_register_global_histories_ibfk_3` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_pos_cash_register_global_histories_ibfk_4` FOREIGN KEY (`refund_id`) REFERENCES `dbo_administration_refunds` (`id`),
  CONSTRAINT `dbo_pos_cash_register_global_histories_ibfk_5` FOREIGN KEY (`cash_register_id`) REFERENCES `dbo_pos_cash_register_closes` (`id`),
  CONSTRAINT `dbo_pos_cash_register_global_histories_ibfk_6` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_pos_cash_register_global_histories_ibfk_7` FOREIGN KEY (`user_receptor_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_global_histories`
--

LOCK TABLES `dbo_pos_cash_register_global_histories` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_global_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_global_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_globals`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_globals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_globals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `currency_id` int NOT NULL,
  `cash` decimal(24,6) DEFAULT '0.000000',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_pos_cash_register_globals_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_globals`
--

LOCK TABLES `dbo_pos_cash_register_globals` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_globals` DISABLE KEYS */;
INSERT INTO `dbo_pos_cash_register_globals` VALUES (1,1,0.000000,'2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,2,0.000000,'2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_pos_cash_register_globals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_initiations`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_initiations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_initiations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `observation` varchar(255) DEFAULT NULL,
  `cash_register_close_id` int NOT NULL,
  `cash_register_start_id` int NOT NULL,
  `cash_register_end_id` int NOT NULL,
  `currency_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `cash_register_close_id` (`cash_register_close_id`),
  KEY `cash_register_start_id` (`cash_register_start_id`),
  KEY `cash_register_end_id` (`cash_register_end_id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_pos_cash_register_initiations_ibfk_1` FOREIGN KEY (`cash_register_close_id`) REFERENCES `dbo_pos_cash_register_closes` (`id`),
  CONSTRAINT `dbo_pos_cash_register_initiations_ibfk_2` FOREIGN KEY (`cash_register_start_id`) REFERENCES `dbo_pos_cash_register_starts` (`id`),
  CONSTRAINT `dbo_pos_cash_register_initiations_ibfk_3` FOREIGN KEY (`cash_register_end_id`) REFERENCES `dbo_pos_cash_register_ends` (`id`),
  CONSTRAINT `dbo_pos_cash_register_initiations_ibfk_4` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_initiations`
--

LOCK TABLES `dbo_pos_cash_register_initiations` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_initiations` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_initiations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_start_details`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_start_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_start_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cash_register_start_id` int NOT NULL,
  `dbo_config_currency_denomination_id` int NOT NULL,
  `quantity` int DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `cash_register_start_id` (`cash_register_start_id`),
  KEY `dbo_config_currency_denomination_id` (`dbo_config_currency_denomination_id`),
  CONSTRAINT `dbo_pos_cash_register_start_details_ibfk_1` FOREIGN KEY (`cash_register_start_id`) REFERENCES `dbo_pos_cash_register_starts` (`id`),
  CONSTRAINT `dbo_pos_cash_register_start_details_ibfk_2` FOREIGN KEY (`dbo_config_currency_denomination_id`) REFERENCES `dbo_config_currency_denominations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_start_details`
--

LOCK TABLES `dbo_pos_cash_register_start_details` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_start_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_start_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_register_starts`
--

DROP TABLE IF EXISTS `dbo_pos_cash_register_starts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_register_starts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` decimal(20,2) NOT NULL,
  `currency_id` int NOT NULL,
  `exchange_rate_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  CONSTRAINT `dbo_pos_cash_register_starts_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_pos_cash_register_starts_ibfk_2` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_register_starts`
--

LOCK TABLES `dbo_pos_cash_register_starts` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_register_starts` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_cash_register_starts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_cash_registers`
--

DROP TABLE IF EXISTS `dbo_pos_cash_registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_cash_registers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `filter_category` tinyint(1) NOT NULL DEFAULT '0',
  `location_id` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `dbo_pos_cash_registers_location_id_foreign_idx` (`location_id`),
  CONSTRAINT `dbo_pos_cash_registers_location_id_foreign_idx` FOREIGN KEY (`location_id`) REFERENCES `dbo_storage_locations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_cash_registers`
--

LOCK TABLES `dbo_pos_cash_registers` WRITE;
/*!40000 ALTER TABLE `dbo_pos_cash_registers` DISABLE KEYS */;
INSERT INTO `dbo_pos_cash_registers` VALUES (1,'Caja 1','0001','2024-10-16 22:37:11','2024-10-16 22:37:11',0,1),(2,'Caja 2','0002','2024-10-16 22:37:11','2024-10-16 22:37:11',0,1);
/*!40000 ALTER TABLE `dbo_pos_cash_registers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_daily_closes`
--

DROP TABLE IF EXISTS `dbo_pos_daily_closes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_daily_closes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `total` decimal(20,2) DEFAULT '0.00',
  `total_electronic` decimal(20,2) DEFAULT '0.00',
  `total_cash` decimal(20,2) DEFAULT '0.00',
  `initial_amount` decimal(20,2) DEFAULT '0.00',
  `real_amount` decimal(20,2) DEFAULT '0.00',
  `diff_invoiced` decimal(20,2) DEFAULT '0.00',
  `user_id` int DEFAULT NULL,
  `total_product` int DEFAULT '0',
  `total_unit` int DEFAULT '0',
  `currency_id` int DEFAULT '2',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_pos_daily_closes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_pos_daily_closes_ibfk_2` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_daily_closes`
--

LOCK TABLES `dbo_pos_daily_closes` WRITE;
/*!40000 ALTER TABLE `dbo_pos_daily_closes` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_daily_closes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_withdraw_types`
--

DROP TABLE IF EXISTS `dbo_pos_withdraw_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_withdraw_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `internal` tinyint(1) NOT NULL DEFAULT '1',
  `currency_id` int DEFAULT '2',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `show` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`),
  CONSTRAINT `dbo_pos_withdraw_types_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_withdraw_types`
--

LOCK TABLES `dbo_pos_withdraw_types` WRITE;
/*!40000 ALTER TABLE `dbo_pos_withdraw_types` DISABLE KEYS */;
INSERT INTO `dbo_pos_withdraw_types` VALUES (1,'Retiro Bs',1,2,'2024-10-16 22:37:11','2024-10-16 22:37:11',1),(2,'Retiro $',1,1,'2024-10-16 22:37:11','2024-10-16 22:37:11',1),(3,'Vuelto Bs Transferencia',0,2,'2024-10-16 22:37:11','2024-10-16 22:37:11',1),(4,'Vuelto Bs Pago Movil',0,2,'2024-10-16 22:37:11','2024-10-16 22:37:11',1),(5,'Vuelto $ en Caja',1,1,'2024-10-16 22:37:11','2024-10-16 22:37:11',1),(6,'Vuelto Bs en Caja',1,2,'2024-10-16 22:37:11','2024-10-16 22:37:11',1),(7,'Vuelto $ Fuera de Caja',0,1,'2024-10-16 22:37:11','2024-10-16 22:37:11',1),(8,'Vuelto Bs Fuera de Caja',0,2,'2024-10-16 22:37:11','2024-10-16 22:37:11',1),(9,'Pago Completo',0,1,'2024-10-16 22:37:11','2024-10-16 22:37:11',1);
/*!40000 ALTER TABLE `dbo_pos_withdraw_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_pos_withdraws`
--

DROP TABLE IF EXISTS `dbo_pos_withdraws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_pos_withdraws` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` decimal(20,2) DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `withdraw_user` int DEFAULT NULL,
  `withdraw_type_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `exchange_rate_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `company_bank_account_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency_id` (`currency_id`),
  KEY `user_id` (`user_id`),
  KEY `withdraw_user` (`withdraw_user`),
  KEY `withdraw_type_id` (`withdraw_type_id`),
  KEY `client_id` (`client_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `dbo_pos_withdraws_company_bank_account_id_foreign_idx` (`company_bank_account_id`),
  CONSTRAINT `dbo_pos_withdraws_company_bank_account_id_foreign_idx` FOREIGN KEY (`company_bank_account_id`) REFERENCES `dbo_administration_my_company_accounts` (`id`),
  CONSTRAINT `dbo_pos_withdraws_ibfk_1` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_pos_withdraws_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_pos_withdraws_ibfk_3` FOREIGN KEY (`withdraw_user`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_pos_withdraws_ibfk_4` FOREIGN KEY (`withdraw_type_id`) REFERENCES `dbo_pos_withdraw_types` (`id`),
  CONSTRAINT `dbo_pos_withdraws_ibfk_5` FOREIGN KEY (`client_id`) REFERENCES `dbo_sales_clients` (`id`),
  CONSTRAINT `dbo_pos_withdraws_ibfk_6` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_pos_withdraws_ibfk_7` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_pos_withdraws`
--

LOCK TABLES `dbo_pos_withdraws` WRITE;
/*!40000 ALTER TABLE `dbo_pos_withdraws` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_pos_withdraws` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_printer`
--

DROP TABLE IF EXISTS `dbo_printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_printer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `port` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `width` float(10,2) DEFAULT '50.00',
  `mac_address` varchar(50) DEFAULT NULL,
  `font_size` int DEFAULT '12',
  `copy_number_fiscal` int DEFAULT '1',
  `copy_number_no_fiscal` int DEFAULT '1',
  `select_window_printer` tinyint(1) DEFAULT '0',
  `preview` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_printer`
--

LOCK TABLES `dbo_printer` WRITE;
/*!40000 ALTER TABLE `dbo_printer` DISABLE KEYS */;
INSERT INTO `dbo_printer` VALUES (1,'COM2','emulador fiscal java','localhost','2024-10-16 22:37:11','2024-10-16 22:37:11',50.00,NULL,12,1,1,0,0),(2,'COM4','Fiscal real','127.0.0.1','2024-10-16 22:37:11','2024-10-16 22:37:11',50.00,NULL,12,1,1,0,0),(3,'COM1','Fiscal real','127.0.0.1','2024-10-16 22:37:11','2024-10-16 22:37:11',50.00,NULL,12,1,1,0,0);
/*!40000 ALTER TABLE `dbo_printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_printer_current`
--

DROP TABLE IF EXISTS `dbo_printer_current`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_printer_current` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_type_id` int DEFAULT NULL,
  `document_id` int DEFAULT NULL,
  `printer_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `cashier_name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_printer_current`
--

LOCK TABLES `dbo_printer_current` WRITE;
/*!40000 ALTER TABLE `dbo_printer_current` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_printer_current` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_printer_document_types`
--

DROP TABLE IF EXISTS `dbo_printer_document_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_printer_document_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_type` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_printer_document_types`
--

LOCK TABLES `dbo_printer_document_types` WRITE;
/*!40000 ALTER TABLE `dbo_printer_document_types` DISABLE KEYS */;
INSERT INTO `dbo_printer_document_types` VALUES (1,'Factura','2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,'Devolucion','2024-10-16 22:37:11','2024-10-16 22:37:11'),(3,'Nota de Entrega','2024-10-16 22:37:11','2024-10-16 22:37:11'),(4,'Nota no Fiscal','2024-10-16 22:37:11','2024-10-16 22:37:11'),(10,'Resumen por fechas','2024-10-16 22:53:34','2024-10-16 22:53:34');
/*!40000 ALTER TABLE `dbo_printer_document_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_printer_history`
--

DROP TABLE IF EXISTS `dbo_printer_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_printer_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_type_id` int DEFAULT NULL,
  `document_id` int DEFAULT NULL,
  `printer_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `cashier_name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_printer_history`
--

LOCK TABLES `dbo_printer_history` WRITE;
/*!40000 ALTER TABLE `dbo_printer_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_printer_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_printer_invoices_items`
--

DROP TABLE IF EXISTS `dbo_printer_invoices_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_printer_invoices_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int DEFAULT NULL,
  `precio` decimal(20,2) DEFAULT NULL,
  `cant` int DEFAULT NULL,
  `tasa` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_printer_invoices_items`
--

LOCK TABLES `dbo_printer_invoices_items` WRITE;
/*!40000 ALTER TABLE `dbo_printer_invoices_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_printer_invoices_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_printer_ledger_pending`
--

DROP TABLE IF EXISTS `dbo_printer_ledger_pending`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_printer_ledger_pending` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_id` int DEFAULT NULL,
  `document_type` int DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_printer_ledger_pending`
--

LOCK TABLES `dbo_printer_ledger_pending` WRITE;
/*!40000 ALTER TABLE `dbo_printer_ledger_pending` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_printer_ledger_pending` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_printer_logs`
--

DROP TABLE IF EXISTS `dbo_printer_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_printer_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` varchar(255) DEFAULT NULL,
  `printer_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `cashier_name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_printer_logs`
--

LOCK TABLES `dbo_printer_logs` WRITE;
/*!40000 ALTER TABLE `dbo_printer_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_printer_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_printer_messages`
--

DROP TABLE IF EXISTS `dbo_printer_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_printer_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `message` varchar(255) DEFAULT NULL,
  `printer_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `cashier_name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_printer_messages`
--

LOCK TABLES `dbo_printer_messages` WRITE;
/*!40000 ALTER TABLE `dbo_printer_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_printer_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_printer_pending`
--

DROP TABLE IF EXISTS `dbo_printer_pending`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_printer_pending` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_type_id` int DEFAULT NULL,
  `document_id` int DEFAULT NULL,
  `printer_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `cashier_name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_printer_pending`
--

LOCK TABLES `dbo_printer_pending` WRITE;
/*!40000 ALTER TABLE `dbo_printer_pending` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_printer_pending` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_refunds_reasons`
--

DROP TABLE IF EXISTS `dbo_refunds_reasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_refunds_reasons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_refunds_reasons`
--

LOCK TABLES `dbo_refunds_reasons` WRITE;
/*!40000 ALTER TABLE `dbo_refunds_reasons` DISABLE KEYS */;
INSERT INTO `dbo_refunds_reasons` VALUES (1,'Mal Estado','2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,'Vencimiento','2024-10-16 22:37:11','2024-10-16 22:37:11');
/*!40000 ALTER TABLE `dbo_refunds_reasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_refunds_statuses`
--

DROP TABLE IF EXISTS `dbo_refunds_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_refunds_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_refunds_statuses`
--

LOCK TABLES `dbo_refunds_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_refunds_statuses` DISABLE KEYS */;
INSERT INTO `dbo_refunds_statuses` VALUES (1,'Pendiente','2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,'Verificado','2024-10-16 22:37:11','2024-10-16 22:37:11'),(3,'Aprobado','2024-10-16 22:37:11','2024-10-16 22:37:11');
/*!40000 ALTER TABLE `dbo_refunds_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_retention_document_types`
--

DROP TABLE IF EXISTS `dbo_retention_document_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_retention_document_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_retention_document_types`
--

LOCK TABLES `dbo_retention_document_types` WRITE;
/*!40000 ALTER TABLE `dbo_retention_document_types` DISABLE KEYS */;
INSERT INTO `dbo_retention_document_types` VALUES (1,'01','FACTURA','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,'02','NOTA DE DEBITO','2024-10-16 22:37:12','2024-10-16 22:37:12'),(3,'03','NOTA DE CREDITO','2024-10-16 22:37:12','2024-10-16 22:37:12'),(4,'04','IMPORTACION','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_retention_document_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_retention_operation_types`
--

DROP TABLE IF EXISTS `dbo_retention_operation_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_retention_operation_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_retention_operation_types`
--

LOCK TABLES `dbo_retention_operation_types` WRITE;
/*!40000 ALTER TABLE `dbo_retention_operation_types` DISABLE KEYS */;
INSERT INTO `dbo_retention_operation_types` VALUES (1,'C','COMPRAS','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,'V','VENTAS','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_retention_operation_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_retention_tax_codes`
--

DROP TABLE IF EXISTS `dbo_retention_tax_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_retention_tax_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `tax_percentage` decimal(10,2) DEFAULT NULL,
  `tax_type_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `tax_type_id` (`tax_type_id`),
  CONSTRAINT `dbo_retention_tax_codes_ibfk_1` FOREIGN KEY (`tax_type_id`) REFERENCES `dbo_retention_tax_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_retention_tax_codes`
--

LOCK TABLES `dbo_retention_tax_codes` WRITE;
/*!40000 ALTER TABLE `dbo_retention_tax_codes` DISABLE KEYS */;
INSERT INTO `dbo_retention_tax_codes` VALUES (1,'1','Sueldos y Salarios',0.00,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(2,'2','Honorarios Profesionales No Mercantiles (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(3,'3','Honorarios Profesionales No Mercantiles (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(4,'4','Honorarios Profesionales No Mercantiles (PJD) hasta 2000 U.T.',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(5,'5','Honorarios Profesionales No Mercantiles (PJND) entre 2000 U.T hasta 3000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(6,'5','Honorarios Profesionales No Mercantiles (PJND) entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(7,'5','Honorarios Profesionales No Mercantiles (PJND) monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(8,'6','Honorarios Profesionales Mancomunados No Mercantiles (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(9,'7','Honorarios Profesionales Mancomunados No Mercantiles (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(10,'8','Honorarios Profesionales Mancomunados No Mercantiles (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(11,'9','Honorarios Profesionales Mancomunados No Mercantiles (PJND)  hasta 2000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(12,'9','Honorarios Profesionales Mancomunados No Mercantiles (PJND)  entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(13,'9','Honorarios Profesionales Mancomunados No Mercantiles (PJND) monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(14,'10','Honorarios Profesionales pagados a Jinetes, Veterinarios, Preparadores o Entrenadores (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(15,'11','Honorarios Profesionales pagados a Jinetes, Veterinarios, Preparadores o Entrenadores (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(16,'12','Honorarios Profesionales pagados por Clínicas, Hospitales, Centros de Salud, Bufetes, Escritorios, Oficinas, Colegios Profesionales u otra Institución Profesionales No Mercantiles a Profesionales sin relación de dependencia (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(17,'13','Honorarios Profesionales pagados por Clínicas, Hospitales, Centros de Salud, Bufetes, Escritorios, Oficinas, Colegios Profesionales u otra Institución Profesionales No Mercantiles a Profesionales sin relación de dependencia (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(18,'14','Comisiones pagadas por la venta de bienes inmuebles (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(19,'15','Comisiones pagadas por la venta de bienes inmuebles (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(20,'16','Comisiones pagadas por la venta de bienes inmuebles (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(21,'17','Comisiones pagadas por la venta de bienes inmuebles (PJND)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(22,'18','Cualquier otra Comisión distintas a Remuneraciones accesorias de los sueldos, salarios y demás remuneraciones similares (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(23,'19','Cualquier otra Comisión distintas a Remuneraciones accesorias de los sueldos, salarios y demás remuneraciones similares (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(24,'20','Cualquier otra Comisión distintas a Remuneraciones accesorias de los sueldos, salarios y demás remuneraciones similares (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(25,'21','Cualquier otra Comisión distintas a Remuneraciones accesorias de los sueldos, salarios y demás remuneraciones similares (PJND)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(26,'22','Intereses de Capitales tomados en préstamo e invertidos en la producción de la renta (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(27,'23','Intereses de Capitales tomados en préstamo e invertidos en la producción de la renta (PJND) hasta 2000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(28,'23','Intereses de Capitales tomados en préstamo e invertidos en la producción de la renta (PJND) entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(29,'23','Intereses de Capitales tomados en préstamo e invertidos en la producción de la renta (PJND) monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(30,'24','Intereses provenientes de préstamos y otros créditos pagaderos a instituciones financieras constituidas en el exterior y no domiciliadas en el país (PJND)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(31,'25','Intereses pagados por las personas jurídicas o comunidades a cualquier otra persona natural, jurídica o comunidad (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(32,'26','Intereses pagados por las personas jurídicas o comunidades a cualquier otra persona natural, jurídica o comunidad (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(33,'27','Intereses pagados por las personas jurídicas o comunidades a cualquier otra persona natural, jurídica o comunidad (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(34,'28','Intereses pagados por las personas jurídicas o comunidades a cualquier otra persona natural, jurídica o comunidad (PJND) hasta 2000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(35,'28','Intereses pagados por las personas jurídicas o comunidades a cualquier otra persona natural, jurídica o comunidad (PJND) entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(36,'28','Intereses pagados por las personas jurídicas o comunidades a cualquier otra persona natural, jurídica o comunidad (PJND) monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(37,'29','Enriquecimientos Netos de las Agencias Internacionales cuando el pagador sea una personas jurídica o comunidad domiciliada en el país (PJND) hasta 2000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(38,'29','Enriquecimientos Netos de las Agencias Internacionales cuando el pagador sea una personas jurídica o comunidad domiciliada en el país (PJND) entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(39,'29','Enriquecimientos Netos de las Agencias Internacionales cuando el pagador sea una personas jurídica o comunidad domiciliada en el país (PJND)  monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(40,'30','Enriquecimientos Netos de Gastos de Transporte conformados por fletes pagados a agencias o empresas de transporte internacional constituidas y domiciliadas en el exterior (PNNR)',0.10,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(41,'31','Enriquecimientos Netos de Gastos de Transporte conformados por fletes pagados a agencias o empresas de transporte internacional constituidas y domiciliadas en el exterior (PJND)',0.10,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(42,'32','Enriquecimientos Netos de Exhibición de Películas, Cine o la Televisión (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(43,'33','Enriquecimientos Netos de Exhibición de Películas, Cine o la Televisión (PJND)  hasta 2000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(44,'33','Enriquecimientos Netos de Exhibición de Películas, Cine o la Televisión (PJND) entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(45,'33','Enriquecimientos Netos de Exhibición de Películas, Cine o la Televisión (PJND) monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(46,'34','Enriquecimientos obtenidos por concepto de regalías y demás participaciones análogas (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(47,'35','Enriquecimientos obtenidos por concepto de regalías y demás participaciones análogas (PJND) hasta 2000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(48,'35','Enriquecimientos obtenidos por concepto de regalías y demás participaciones análogas (PJND) entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(49,'35','Enriquecimientos obtenidos por concepto de regalías y demás participaciones análogas (PJND) monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(50,'36','Enriquecimientos obtenidos por las Remuneraciones, Honorarios y pagos análogos por Asistencia Técnica (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(51,'37','Enriquecimientos obtenidos por las Remuneraciones, Honorarios y pagos análogos por Asistencia Técnica (PJND) hasta 2000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(52,'37','Enriquecimientos obtenidos por las Remuneraciones, Honorarios y pagos análogos por Asistencia Técnica (PJND) entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(53,'37','Enriquecimientos obtenidos por las Remuneraciones, Honorarios y pagos análogos por Asistencia Técnica (PJND) monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(54,'38','Enriquecimientos obtenidos por Servicios Tecnológicos utilizados en el país o cedidos a Terceros (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(55,'39','Enriquecimientos obtenidos por Servicios Tecnológicos utilizados en el país o cedidos a Terceros (PJND) hasta 2000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(56,'39','Enriquecimientos obtenidos por Servicios Tecnológicos utilizados en el país o cedidos a Terceros (PJND) entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(57,'39','Enriquecimientos obtenidos por Servicios Tecnológicos utilizados en el país o cedidos a Terceros (PJND) monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(58,'40','Enriquecimientos Netos derivados de las Primas de Seguros y Reaseguros (PJND)',0.10,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(59,'41','Ganancias Obtenidas por Juegos y Apuestas (PNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(60,'42','Ganancias Obtenidas por Juegos y Apuestas (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(61,'43','Ganancias Obtenidas por Juegos y Apuestas (PJD)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(62,'44','Ganancias Obtenidas por Juegos y Apuestas (PJND)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(63,'45','Ganancias Obtenidas por Premios de Loterías y de Hipódromos (PNR)',0.16,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(64,'46','Ganancias Obtenidas por Premios de Loterías y de Hipódromos (PNNR)',0.16,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(65,'47','Ganancias Obtenidas por Premios de Loterías y de Hipódromos (PJD)',0.16,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(66,'48','Ganancias Obtenidas por Premios de Loterías y de Hipódromos (PJND)',0.16,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(67,'49','Pagos a Propietarios de Animales de Carrera por concepto de Premios (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(68,'50','Pagos a Propietarios de Animales de Carrera por concepto de Premios (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(69,'51','Pagos a Propietarios de Animales de Carrera por concepto de Premios (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(70,'52','Pagos a Propietarios de Animales de Carrera por concepto de Premios (PJND)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(71,'53','Pagos a Empresas Contratistas o Subcontratistas domiciliadas o no en el país, por la ejecución de obras o de la prestación de servicios en base a valuaciones y ordenes de pago (PNR)',0.01,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(72,'54','Pagos a Empresas Contratistas o Subcontratistas domiciliadas o no en el país, por la ejecución de obras o de la prestación de servicios en base a valuaciones y ordenes de pago (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(73,'55','Pagos a Empresas Contratistas o Subcontratistas domiciliadas o no en el país, por la ejecución de obras o de la prestación de servicios en base a valuaciones y ordenes de pago (PJD)',0.02,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(74,'56','Pagos a Empresas Contratistas o Subcontratistas domiciliadas o no en el país, por la ejecución de obras o de la prestación de servicios en base a valuaciones y ordenes de pago (PJND) hasta 2000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(75,'56','Pagos a Empresas Contratistas o Subcontratistas domiciliadas o no en el país, por la ejecución de obras o de la prestación de servicios en base a valuaciones y ordenes de pago (PJND) entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(76,'56','Pagos a Empresas Contratistas o Subcontratistas domiciliadas o no en el país, por la ejecución de obras o de la prestación de servicios en base a valuaciones y ordenes de pago (PJND) monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(77,'57','Pagos de los Administradores de bienes inmuebles a los Arrendadores de los bienes inmuebles situados en el país (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(78,'58','Pagos de los Administradores de bienes inmuebles a los Arrendadores de los bienes inmuebles situados en el país (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(79,'59','Pagos de los Administradores de bienes inmuebles a los Arrendadores de los bienes inmuebles situados en el país (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(80,'60','Pagos de los Administradores de bienes inmuebles a los Arrendadores de los bienes inmuebles situados en el país (PJND) hasta 2000 U.T.',0.15,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(81,'60','Pagos de los Administradores de bienes inmuebles a los Arrendadores de los bienes inmuebles situados en el país (PJND) entre 2000 U.T hasta 3000 U.T.',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(82,'60','Pagos de los Administradores de bienes inmuebles a los Arrendadores de los bienes inmuebles situados en el país (PJND) monto que exceda de 3000 U.T.',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(83,'60','Pagos de los Administradores de bienes inmuebles a los Arrendadores de los bienes inmuebles situados en el país (PJND)',0.22,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(84,'60','Pagos de los Administradores de bienes inmuebles a los Arrendadores de los bienes inmuebles situados en el país (PJND)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(85,'61','Cánones de Arrendamientos de Bienes Muebles situados en el país (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(86,'62','Cánones de Arrendamientos de Bienes Muebles situados en el país (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(87,'63','Cánones de Arrendamientos de Bienes Muebles situados en el país (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(88,'64','Cánones de Arrendamientos de Bienes Muebles situados en el país (PJND)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(89,'65','Pagos de las Empresas Emisoras de Tarjetas de Crédito o Consumo por la Venta de Bienes y servicios, o cualquier otro concepto (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(90,'66','Pagos de las Empresas Emisoras de Tarjetas de Crédito o Consumo por la Venta de Bienes y servicios, o cualquier otro concepto (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(91,'67','Pagos de las Empresas Emisoras de Tarjetas de Crédito o Consumo por la Venta de Bienes y servicios, o cualquier otro concepto (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(92,'68','Pagos de las Empresas Emisoras de Tarjetas de Crédito o Consumo por la Venta de Bienes y servicios, o cualquier otro concepto (PJND)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(93,'69','Pagos de las Empresas Emisoras de Tarjetas de Crédito por la venta de gasolina en las Estaciones de Servicios (PNR)',0.01,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(94,'70','Pagos de las Empresas Emisoras de Tarjetas de Crédito por la venta de gasolina en las Estaciones de Servicios (PJD)',0.01,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(95,'71','Pagos por Gastos de Transporte conformados por Fletes (PNR)',0.01,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(96,'72','Pagos por Gastos de Transporte conformados por Fletes (PJD)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(97,'73','Pagos de las Empresas de Seguro, las Sociedades de Corretaje de Seguros y las Empresas de Reaseguros por las Prestaciones de Servicios que le son propios (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(98,'74','Pagos de las Empresas de Seguro, las Sociedades de Corretaje de Seguros y las Empresas de Reaseguros por las Prestaciones de Servicios que le son propios (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(99,'75','Pagos de las Empresas de Seguro a sus Contratistas por la Reparación de Daños sufridos de sus Asegurados (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(100,'76','Pagos de las Empresas de Seguro a sus Contratistas por la Reparación de Daños sufridos de sus Asegurados (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(101,'77','Pagos de las Empresas de Seguros a Clínicas, Hospitales y/o Centros de Salud por la Atención Medica a sus Asegurados (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(102,'78','Pagos de las Empresas de Seguros a Clínicas, Hospitales y/o Centros de Salud por la Atención Medica a sus Asegurados (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(103,'79','Cantidades que se paguen por adquisición de Fondos de Comercio situados en el país (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(104,'80','Cantidades que se paguen por adquisición de Fondos de Comercio situados en el país (PNNR)',0.34,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(105,'81','Cantidades que se paguen por adquisición de Fondos de Comercio situados en el país (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(106,'82','Cantidades que se paguen por adquisición de Fondos de Comercio situados en el país (PJND)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(107,'83','Pagos por Servicios de Publicidad y Propaganda y la Cesión de la Venta de Espacios para tales fines (PNR)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(108,'84','Pagos por Servicios de Publicidad y Propaganda y la Cesión de la Venta de Espacios para tales fines (PJD)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(109,'85','Pagos por Servicios de Publicidad y Propaganda y la Cesión de la Venta de Espacios para tales fines (PJND)',0.05,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(110,'86','Pagos por Servicios de Publicidad y Propaganda y la Cesión de la Venta de Espacios para tales fines a Emisoras de Radio (PJD)',0.03,2,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(111,'100','I.V.A. 0%',0.00,1,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(112,'150','I.V.A. 75%',0.75,1,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(113,'200','I.V.A. 100%',1.00,1,'2024-10-16 22:37:13','2024-10-16 22:37:13');
/*!40000 ALTER TABLE `dbo_retention_tax_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_retention_tax_histories`
--

DROP TABLE IF EXISTS `dbo_retention_tax_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_retention_tax_histories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `tax_retention_status_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tax_retention_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax_retention_status_id` (`tax_retention_status_id`),
  KEY `dbo_retention_tax_histories_tax_retention_id_foreign_idx` (`tax_retention_id`),
  CONSTRAINT `dbo_retention_tax_histories_ibfk_1` FOREIGN KEY (`tax_retention_status_id`) REFERENCES `dbo_retention_tax_statuses` (`id`),
  CONSTRAINT `dbo_retention_tax_histories_tax_retention_id_foreign_idx` FOREIGN KEY (`tax_retention_id`) REFERENCES `dbo_retention_tax_invoices` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_retention_tax_histories`
--

LOCK TABLES `dbo_retention_tax_histories` WRITE;
/*!40000 ALTER TABLE `dbo_retention_tax_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_retention_tax_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_retention_tax_invoices`
--

DROP TABLE IF EXISTS `dbo_retention_tax_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_retention_tax_invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_id` int DEFAULT NULL,
  `company_rif` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `invoice_control_number` varchar(255) DEFAULT NULL,
  `operation_type_id` int DEFAULT NULL,
  `document_type_id` int DEFAULT NULL,
  `invoice_subtotal_amount` decimal(20,2) DEFAULT NULL,
  `invoice_total_tax_amount` decimal(20,2) DEFAULT NULL,
  `invoice_total_amount` decimal(20,2) DEFAULT NULL,
  `invoice_created_date` datetime DEFAULT NULL,
  `retention_amount` decimal(20,2) DEFAULT NULL,
  `retention_code_id` int DEFAULT NULL,
  `retention_document_number` varchar(255) DEFAULT NULL,
  `tax_type_id` int DEFAULT NULL,
  `retention_percentage_amount` decimal(20,2) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `retention_history_id` int DEFAULT NULL,
  `invoice_total_without_tax` decimal(20,2) DEFAULT NULL,
  `invoice_total_tax_base` decimal(20,2) DEFAULT NULL,
  `provider_id` int DEFAULT NULL,
  `rif` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dbo_retention_tax_invoices_retention_history_id_foreign_idx` (`retention_history_id`),
  KEY `dbo_retention_tax_invoices_provider_id_foreign_idx` (`provider_id`),
  CONSTRAINT `dbo_retention_tax_invoices_provider_id_foreign_idx` FOREIGN KEY (`provider_id`) REFERENCES `dbo_config_companies` (`id`),
  CONSTRAINT `dbo_retention_tax_invoices_retention_history_id_foreign_idx` FOREIGN KEY (`retention_history_id`) REFERENCES `dbo_retention_tax_histories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_retention_tax_invoices`
--

LOCK TABLES `dbo_retention_tax_invoices` WRITE;
/*!40000 ALTER TABLE `dbo_retention_tax_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_retention_tax_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_retention_tax_statuses`
--

DROP TABLE IF EXISTS `dbo_retention_tax_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_retention_tax_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_retention_tax_statuses`
--

LOCK TABLES `dbo_retention_tax_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_retention_tax_statuses` DISABLE KEYS */;
INSERT INTO `dbo_retention_tax_statuses` VALUES (1,'GENERADA','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,'PAGADA','2024-10-16 22:37:12','2024-10-16 22:37:12'),(3,'ANULADA','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_retention_tax_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_retention_tax_types`
--

DROP TABLE IF EXISTS `dbo_retention_tax_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_retention_tax_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_retention_tax_types`
--

LOCK TABLES `dbo_retention_tax_types` WRITE;
/*!40000 ALTER TABLE `dbo_retention_tax_types` DISABLE KEYS */;
INSERT INTO `dbo_retention_tax_types` VALUES (1,'IVA','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,'ISRL','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_retention_tax_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_sales_client_price_types`
--

DROP TABLE IF EXISTS `dbo_sales_client_price_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_sales_client_price_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `percentage` decimal(5,4) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_sales_client_price_types`
--

LOCK TABLES `dbo_sales_client_price_types` WRITE;
/*!40000 ALTER TABLE `dbo_sales_client_price_types` DISABLE KEYS */;
INSERT INTO `dbo_sales_client_price_types` VALUES (1,'Precio 1 0%',0.0000,'2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'Precio 2 30%',0.3000,'2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_sales_client_price_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_sales_clients`
--

DROP TABLE IF EXISTS `dbo_sales_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_sales_clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT '',
  `telephone` varchar(255) DEFAULT NULL,
  `identification_number` varchar(255) DEFAULT '',
  `direction` varchar(255) DEFAULT '',
  `bank_id` int DEFAULT NULL,
  `dispatch_address` varchar(255) DEFAULT '',
  `city` varchar(255) DEFAULT '',
  `state` varchar(255) DEFAULT '',
  `country_id` int DEFAULT NULL,
  `postal_code` varchar(255) DEFAULT '',
  `identification_type_id` int DEFAULT NULL,
  `client_price_type_id` int DEFAULT NULL,
  `tax_withholding_id` int DEFAULT '1',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `discount_type_id` int DEFAULT '1',
  `email` varchar(255) DEFAULT NULL,
  `gender_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  KEY `identification_type_id` (`identification_type_id`),
  KEY `client_price_type_id` (`client_price_type_id`),
  KEY `tax_withholding_id` (`tax_withholding_id`),
  KEY `dbo_sales_clients_discount_type_id_foreign_idx` (`discount_type_id`),
  KEY `dbo_sales_clients_gender_id_foreign_idx` (`gender_id`),
  KEY `dbo_sales_clients_bank_id_foreign_idx` (`bank_id`),
  CONSTRAINT `dbo_sales_clients_bank_id_foreign_idx` FOREIGN KEY (`bank_id`) REFERENCES `dbo_finance_payment_banks` (`id`),
  CONSTRAINT `dbo_sales_clients_discount_type_id_foreign_idx` FOREIGN KEY (`discount_type_id`) REFERENCES `dbo_discount_types` (`id`),
  CONSTRAINT `dbo_sales_clients_gender_id_foreign_idx` FOREIGN KEY (`gender_id`) REFERENCES `dbo_config_genders` (`id`),
  CONSTRAINT `dbo_sales_clients_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `dbo_config_countries` (`id`),
  CONSTRAINT `dbo_sales_clients_ibfk_2` FOREIGN KEY (`identification_type_id`) REFERENCES `dbo_config_identifications_types` (`id`),
  CONSTRAINT `dbo_sales_clients_ibfk_3` FOREIGN KEY (`client_price_type_id`) REFERENCES `dbo_sales_client_price_types` (`id`),
  CONSTRAINT `dbo_sales_clients_ibfk_4` FOREIGN KEY (`tax_withholding_id`) REFERENCES `dbo_config_tax_withholdings` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_sales_clients`
--

LOCK TABLES `dbo_sales_clients` WRITE;
/*!40000 ALTER TABLE `dbo_sales_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_sales_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_settings_routes`
--

DROP TABLE IF EXISTS `dbo_settings_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_settings_routes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `navigation_route_id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `navigation_route_id` (`navigation_route_id`),
  CONSTRAINT `dbo_settings_routes_ibfk_1` FOREIGN KEY (`navigation_route_id`) REFERENCES `dbo_navigation_routes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_settings_routes`
--

LOCK TABLES `dbo_settings_routes` WRITE;
/*!40000 ALTER TABLE `dbo_settings_routes` DISABLE KEYS */;
INSERT INTO `dbo_settings_routes` VALUES (1,1,'Facturación',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(2,1,'Ventas',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(3,1,'Presupuestos',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(4,1,'Devoluciones',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(5,1,'Retiros y Vueltos',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(6,1,'Cierres - Cierres',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(7,1,'Cierres - Diarios',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(8,2,'Inventario - Inventario',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(9,2,'Inventario - Fallas',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(10,2,'Inventario - Nota de Entrega',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(11,2,'Inventario - Transferencias',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(12,2,'Inventario - Movimientos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(13,2,'Productos - Productos',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(14,2,'Productos - Categorías',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(15,2,'Productos - Sub Categorías',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(16,2,'Productos - Tipo de Precio de Producto',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(17,2,'Productos - Fabricante',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(18,2,'Productos - Presentación',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(19,2,'Productos - Movimiento Producto',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(20,2,'Cargas Masivas',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(21,3,'Comparas',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(22,3,'Gastos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(23,3,'Bienes',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(24,3,'Servicios',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(25,3,'Ventas',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(26,3,'Precios',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(27,3,'Clientes',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(28,3,'Histórico',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(29,3,'Bitácora - Vendedores',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(30,3,'Vendedores',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(31,3,'Totales Cierres',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(32,3,'Proveedores',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(33,3,'Créditos',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(34,3,'Productos - Productos Vendidos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(35,3,'Productos - Productos Comprados',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(36,4,'Retenciones IVA',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(37,4,'Retenciones ISLR',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(38,5,'Pagos Recibidos',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(39,5,'Pagos Emitidos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(40,5,'Pagos Clientes',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(41,5,'Pagos Anticipados',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(42,5,'Pagos Genéricos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(43,5,'Nota de Crédito',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(44,5,'Devoluciones',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(45,5,'Nota de Débito',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(46,5,'Historial de Caja',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(47,5,'Conciliación Bancaria',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(48,6,'Cuentas',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(49,6,'Bancos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(50,6,'Operaciones',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(51,6,'Compras Detalles',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(52,6,'Ventas Resumen',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(53,6,'Ventas Detalles',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(54,6,'Ventas Categorías',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(55,6,'Ventas Costos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(56,7,'Perfil',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(57,7,'Producto - Productos',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(58,7,'Producto - Categorías',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(59,7,'Producto - Sub Categorías',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(60,7,'Producto - Tipo de Precio de Productos',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(61,7,'Producto - Fabricante',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(62,7,'Producto - Presentación',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(63,7,'Producto - Movimiento Producto',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(64,7,'Finanzas - Monedas',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(65,7,'Finanzas - Denominaciones',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(66,7,'Finanzas - Tasa de Cambio',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(67,7,'Finanzas - Bancos',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(68,7,'Finanzas - Impuestos',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(69,7,'Finanzas - Tipo de Pago',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(70,7,'Finanzas - Tipo de Pago de Banco',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(71,7,'Finanzas - Tipo de Nota de Crédito',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(72,7,'Finanzas - Tipo de Nota de Débito',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(73,7,'Finanzas - Dias de Crédito',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(74,7,'Administración - Tipos de Precio de Clientes',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(75,7,'Administración - Compañía',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(76,7,'Administración - Cuentas Bancarias',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(77,7,'Administración - Correo',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(78,7,'Usuario',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(79,7,'Almacén - Almacenes',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(80,7,'Almacén - Tipos de Entradas',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(81,7,'Caja - Cajas',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(82,7,'Caja - Caja Chica',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(83,7,'Impresoras',1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(84,7,'Sistemas',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(85,2,'Productos - Ingredientes Activos',1,'2024-10-16 22:53:36','2024-10-16 22:53:36'),(86,2,'Productos - Departamentos',1,'2024-10-16 22:53:36','2024-10-16 22:53:36'),(87,7,'Caja - Pago Móvil',1,'2024-10-16 22:53:36','2024-10-16 22:53:36'),(88,6,'Reporte Art. 177',1,'2024-10-16 22:53:37','2024-10-16 22:53:37');
/*!40000 ALTER TABLE `dbo_settings_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_active_ingredients`
--

DROP TABLE IF EXISTS `dbo_storage_active_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_active_ingredients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_active_ingredients`
--

LOCK TABLES `dbo_storage_active_ingredients` WRITE;
/*!40000 ALTER TABLE `dbo_storage_active_ingredients` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_active_ingredients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_brands`
--

DROP TABLE IF EXISTS `dbo_storage_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_brands` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_brands`
--

LOCK TABLES `dbo_storage_brands` WRITE;
/*!40000 ALTER TABLE `dbo_storage_brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_categories`
--

DROP TABLE IF EXISTS `dbo_storage_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_categories`
--

LOCK TABLES `dbo_storage_categories` WRITE;
/*!40000 ALTER TABLE `dbo_storage_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_code_bar_products`
--

DROP TABLE IF EXISTS `dbo_storage_code_bar_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_code_bar_products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code_bar` varchar(255) NOT NULL,
  `product_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_bar` (`code_bar`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `dbo_storage_code_bar_products_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_code_bar_products`
--

LOCK TABLES `dbo_storage_code_bar_products` WRITE;
/*!40000 ALTER TABLE `dbo_storage_code_bar_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_code_bar_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_inventories`
--

DROP TABLE IF EXISTS `dbo_storage_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_inventories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `reserve` int NOT NULL DEFAULT '0',
  `lot` varchar(255) DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `expirateDate` datetime DEFAULT NULL,
  `status_id` int NOT NULL DEFAULT '1',
  `location_id` int DEFAULT '1',
  `observation` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `weight_quantity` float(20,6) DEFAULT '0.000000',
  `weight_reserve` float(20,6) DEFAULT '0.000000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_index_product` (`product_id`,`status_id`,`location_id`),
  KEY `status_id` (`status_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `dbo_storage_inventories_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_storage_inventories_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `dbo_storage_products_conditions` (`id`),
  CONSTRAINT `dbo_storage_inventories_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `dbo_storage_locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_inventories`
--

LOCK TABLES `dbo_storage_inventories` WRITE;
/*!40000 ALTER TABLE `dbo_storage_inventories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_inventories` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 */ /*!50003 TRIGGER `quantity_inventory_update` BEFORE UPDATE ON `dbo_storage_inventories` FOR EACH ROW BEGIN
          IF
            NEW.quantity < 0 THEN
              SIGNAL SQLSTATE '45000' 
              SET MESSAGE_TEXT = 'cantidad no puede ser menor a 0';
            
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 */ /*!50003 TRIGGER `reserve_inventory_update` BEFORE UPDATE ON `dbo_storage_inventories` FOR EACH ROW BEGIN
          IF
            NEW.reserve < 0 THEN
              SIGNAL SQLSTATE '45000' 
              SET MESSAGE_TEXT = 'reserva no puede ser menor a 0';
            
          END IF;
        END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `dbo_storage_inventory_entry_types`
--

DROP TABLE IF EXISTS `dbo_storage_inventory_entry_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_inventory_entry_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_inventory_entry_types`
--

LOCK TABLES `dbo_storage_inventory_entry_types` WRITE;
/*!40000 ALTER TABLE `dbo_storage_inventory_entry_types` DISABLE KEYS */;
INSERT INTO `dbo_storage_inventory_entry_types` VALUES (1,'Nota de Entrega','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'Compra','2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'Nota de Salida','2024-10-16 22:37:10','2024-10-16 22:37:10'),(4,'Venta 1','2024-10-16 22:37:10','2024-10-16 22:37:10'),(5,'Ajustes','2024-10-16 22:37:10','2024-10-16 22:37:10'),(6,'Venta 2','2024-10-16 22:37:10','2024-10-16 22:37:10'),(7,'Ajuste Automático','2024-10-16 22:37:10','2024-10-16 22:37:10'),(8,'Transferencia','2024-10-16 22:37:10','2024-10-16 22:37:10'),(9,'Condición','2024-10-16 22:37:10','2024-10-16 22:37:10'),(10,'Anulación','2024-10-16 22:37:10','2024-10-16 22:37:10'),(11,'Ajuste Manual','2024-10-16 22:37:10','2024-10-16 22:37:10'),(12,'Ajuste Manual','2024-10-16 22:37:12','2024-10-16 22:37:12'),(13,'Ajuste Manual','2024-10-16 22:37:13','2024-10-16 22:37:13'),(14,'Gastos','2024-10-16 22:37:13','2024-10-16 22:37:13'),(15,'Bienes','2024-10-16 22:37:13','2024-10-16 22:37:13'),(16,'Servicios','2024-10-16 22:37:13','2024-10-16 22:37:13'),(17,'Notas de Crédito','2024-10-16 22:37:13','2024-10-16 22:37:13'),(18,'Notas de Débito','2024-10-16 22:37:13','2024-10-16 22:37:13'),(19,'Devolución','2024-10-16 22:37:13','2024-10-16 22:37:13'),(20,'Consignación','2024-10-16 22:53:36','2024-10-16 22:53:36');
/*!40000 ALTER TABLE `dbo_storage_inventory_entry_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_inventory_history`
--

DROP TABLE IF EXISTS `dbo_storage_inventory_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_inventory_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quantity` int NOT NULL,
  `product_id` int NOT NULL,
  `transaction_id` int DEFAULT NULL,
  `transaction_item_id` int DEFAULT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `location_id` int NOT NULL,
  `entry_type_id` int NOT NULL,
  `operation` enum('+','-') NOT NULL,
  `inventory_id` int NOT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `weight_quantity` float(20,6) DEFAULT '0.000000',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `transaction_item_id` (`transaction_item_id`),
  KEY `location_id` (`location_id`),
  KEY `entry_type_id` (`entry_type_id`),
  KEY `inventory_id` (`inventory_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `currency_id` (`currency_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_storage_inventory_history_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_storage_inventory_history_ibfk_2` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`),
  CONSTRAINT `dbo_storage_inventory_history_ibfk_3` FOREIGN KEY (`transaction_item_id`) REFERENCES `dbo_storage_transaction_items` (`id`),
  CONSTRAINT `dbo_storage_inventory_history_ibfk_4` FOREIGN KEY (`location_id`) REFERENCES `dbo_storage_locations` (`id`),
  CONSTRAINT `dbo_storage_inventory_history_ibfk_5` FOREIGN KEY (`entry_type_id`) REFERENCES `dbo_storage_inventory_entry_types` (`id`),
  CONSTRAINT `dbo_storage_inventory_history_ibfk_6` FOREIGN KEY (`inventory_id`) REFERENCES `dbo_storage_inventories` (`id`),
  CONSTRAINT `dbo_storage_inventory_history_ibfk_7` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_storage_inventory_history_ibfk_8` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_storage_inventory_history_ibfk_9` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_inventory_history`
--

LOCK TABLES `dbo_storage_inventory_history` WRITE;
/*!40000 ALTER TABLE `dbo_storage_inventory_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_inventory_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_locations`
--

DROP TABLE IF EXISTS `dbo_storage_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_locations`
--

LOCK TABLES `dbo_storage_locations` WRITE;
/*!40000 ALTER TABLE `dbo_storage_locations` DISABLE KEYS */;
INSERT INTO `dbo_storage_locations` VALUES (1,'Almacen Principal','2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_storage_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_operation_items`
--

DROP TABLE IF EXISTS `dbo_storage_operation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_operation_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `storage_operation_id` int NOT NULL,
  `transaction_item_id` int NOT NULL,
  `observation` varchar(255) DEFAULT NULL,
  `user_id` int NOT NULL,
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `storage_operation_id` (`storage_operation_id`),
  KEY `transaction_item_id` (`transaction_item_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_storage_operation_items_ibfk_1` FOREIGN KEY (`storage_operation_id`) REFERENCES `dbo_storage_operations` (`id`),
  CONSTRAINT `dbo_storage_operation_items_ibfk_2` FOREIGN KEY (`transaction_item_id`) REFERENCES `dbo_storage_transaction_items` (`id`),
  CONSTRAINT `dbo_storage_operation_items_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_operation_items`
--

LOCK TABLES `dbo_storage_operation_items` WRITE;
/*!40000 ALTER TABLE `dbo_storage_operation_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_operation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_operations`
--

DROP TABLE IF EXISTS `dbo_storage_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_operations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `custom_code` varchar(255) DEFAULT NULL,
  `user_id` int NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `transaction_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `dbo_storage_operations_transaction_id_foreign_idx` (`transaction_id`),
  CONSTRAINT `dbo_storage_operations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_storage_operations_transaction_id_foreign_idx` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transaction_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_operations`
--

LOCK TABLES `dbo_storage_operations` WRITE;
/*!40000 ALTER TABLE `dbo_storage_operations` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_product_active_ingredients`
--

DROP TABLE IF EXISTS `dbo_storage_product_active_ingredients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_product_active_ingredients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `active_ingredient_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_storage_product_active_ingredients` (`product_id`,`active_ingredient_id`),
  KEY `active_ingredient_id` (`active_ingredient_id`),
  CONSTRAINT `dbo_storage_product_active_ingredients_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_storage_product_active_ingredients_ibfk_2` FOREIGN KEY (`active_ingredient_id`) REFERENCES `dbo_storage_active_ingredients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_product_active_ingredients`
--

LOCK TABLES `dbo_storage_product_active_ingredients` WRITE;
/*!40000 ALTER TABLE `dbo_storage_product_active_ingredients` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_product_active_ingredients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_product_lots`
--

DROP TABLE IF EXISTS `dbo_storage_product_lots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_product_lots` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inventory_id` int NOT NULL,
  `product_id` int NOT NULL,
  `transaction_id` int NOT NULL,
  `quantity` int NOT NULL,
  `lot` varchar(255) NOT NULL,
  `expire_date` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `inventory_id` (`inventory_id`),
  KEY `product_id` (`product_id`),
  KEY `transaction_id` (`transaction_id`),
  CONSTRAINT `dbo_storage_product_lots_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `dbo_storage_inventories` (`id`),
  CONSTRAINT `dbo_storage_product_lots_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_storage_product_lots_ibfk_3` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_product_lots`
--

LOCK TABLES `dbo_storage_product_lots` WRITE;
/*!40000 ALTER TABLE `dbo_storage_product_lots` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_product_lots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_product_subcategories`
--

DROP TABLE IF EXISTS `dbo_storage_product_subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_product_subcategories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subcategory_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fiscal_category` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `subcategory_id` (`subcategory_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `dbo_storage_product_subcategories_ibfk_1` FOREIGN KEY (`subcategory_id`) REFERENCES `dbo_storage_subcategories` (`id`),
  CONSTRAINT `dbo_storage_product_subcategories_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_product_subcategories`
--

LOCK TABLES `dbo_storage_product_subcategories` WRITE;
/*!40000 ALTER TABLE `dbo_storage_product_subcategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_product_subcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_products`
--

DROP TABLE IF EXISTS `dbo_storage_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code_bar` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `observation` varchar(255) DEFAULT '',
  `packing_unit` int NOT NULL,
  `imported` tinyint(1) NOT NULL DEFAULT '1',
  `tax_id` int NOT NULL,
  `manufacturer_id` int DEFAULT NULL,
  `shop_id` int NOT NULL DEFAULT '1',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `presentation_id` int DEFAULT NULL,
  `brand_id` int DEFAULT NULL,
  `product_weight_unit_id` int DEFAULT NULL,
  `code_editable` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax_id` (`tax_id`),
  KEY `dbo_storage_products_presentation_id_foreign_idx` (`presentation_id`),
  KEY `dbo_storage_products_brand_id_foreign_idx` (`brand_id`),
  KEY `manufacturer_id` (`manufacturer_id`),
  KEY `dbo_storage_products_product_weight_unit_id_foreign_idx` (`product_weight_unit_id`),
  KEY `dbo_storage_products_shop_id_foreign_idx` (`shop_id`),
  CONSTRAINT `dbo_storage_products_brand_id_foreign_idx` FOREIGN KEY (`brand_id`) REFERENCES `dbo_storage_brands` (`id`),
  CONSTRAINT `dbo_storage_products_ibfk_1` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_storage_products_ibfk_2` FOREIGN KEY (`manufacturer_id`) REFERENCES `dbo_config_companies` (`id`),
  CONSTRAINT `dbo_storage_products_ibfk_3` FOREIGN KEY (`manufacturer_id`) REFERENCES `dbo_config_companies` (`id`),
  CONSTRAINT `dbo_storage_products_presentation_id_foreign_idx` FOREIGN KEY (`presentation_id`) REFERENCES `dbo_system_product_presentations` (`id`),
  CONSTRAINT `dbo_storage_products_product_weight_unit_id_foreign_idx` FOREIGN KEY (`product_weight_unit_id`) REFERENCES `dbo_administration_product_weight_units` (`id`),
  CONSTRAINT `dbo_storage_products_shop_id_foreign_idx` FOREIGN KEY (`shop_id`) REFERENCES `dbo_storage_shops` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_products`
--

LOCK TABLES `dbo_storage_products` WRITE;
/*!40000 ALTER TABLE `dbo_storage_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_products_conditions`
--

DROP TABLE IF EXISTS `dbo_storage_products_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_products_conditions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_products_conditions`
--

LOCK TABLES `dbo_storage_products_conditions` WRITE;
/*!40000 ALTER TABLE `dbo_storage_products_conditions` DISABLE KEYS */;
INSERT INTO `dbo_storage_products_conditions` VALUES (1,'VENDIBLE','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'NO VENDIBLE','2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'GASTOS','2024-10-16 22:37:13','2024-10-16 22:37:13'),(4,'BIENES','2024-10-16 22:37:13','2024-10-16 22:37:13'),(5,'SERVICIOS','2024-10-16 22:37:13','2024-10-16 22:37:13');
/*!40000 ALTER TABLE `dbo_storage_products_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_shops`
--

DROP TABLE IF EXISTS `dbo_storage_shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_shops` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_shops`
--

LOCK TABLES `dbo_storage_shops` WRITE;
/*!40000 ALTER TABLE `dbo_storage_shops` DISABLE KEYS */;
INSERT INTO `dbo_storage_shops` VALUES (1,'TIENDA','2024-10-16 22:53:36','2024-10-16 22:53:36');
/*!40000 ALTER TABLE `dbo_storage_shops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_subcategories`
--

DROP TABLE IF EXISTS `dbo_storage_subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_subcategories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `dbo_storage_subcategories_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `dbo_storage_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_subcategories`
--

LOCK TABLES `dbo_storage_subcategories` WRITE;
/*!40000 ALTER TABLE `dbo_storage_subcategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_subcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_transaction_items`
--

DROP TABLE IF EXISTS `dbo_storage_transaction_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_transaction_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quantity` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `transaction_id` int NOT NULL,
  `lot` varchar(255) DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `expirateDate` datetime DEFAULT NULL,
  `cost` decimal(24,6) DEFAULT NULL,
  `total_cost` decimal(24,6) DEFAULT NULL,
  `tax` decimal(20,2) DEFAULT '0.00',
  `observation` varchar(255) DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `entry_type_id` int DEFAULT NULL,
  `operation` enum('+','-') DEFAULT NULL,
  `inventory_id` int DEFAULT NULL,
  `tax_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `product_price_type_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `products_conditions_id` int NOT NULL DEFAULT '1',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `before_quantity` int DEFAULT NULL,
  `after_quantity` int DEFAULT NULL,
  `cost_id` int DEFAULT NULL,
  `price_bs` decimal(24,6) DEFAULT NULL,
  `price_usd` decimal(24,6) DEFAULT NULL,
  `discount` float(5,2) DEFAULT '0.00',
  `weight_quantity` float(20,6) DEFAULT '0.000000',
  `before_weight_quantity` float(20,6) DEFAULT '0.000000',
  `after_weight_quantity` float(20,6) DEFAULT '0.000000',
  `profit_percentage` decimal(20,4) DEFAULT '0.0000',
  `operation_item_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `location_id` (`location_id`),
  KEY `entry_type_id` (`entry_type_id`),
  KEY `inventory_id` (`inventory_id`),
  KEY `tax_id` (`tax_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `currency_id` (`currency_id`),
  KEY `product_price_type_id` (`product_price_type_id`),
  KEY `user_id` (`user_id`),
  KEY `products_conditions_id` (`products_conditions_id`),
  KEY `dbo_storage_transaction_items_cost_id_foreign_idx` (`cost_id`),
  KEY `dbo_storage_transaction_items_operation_item_id_foreign_idx` (`operation_item_id`),
  CONSTRAINT `dbo_storage_transaction_items_cost_id_foreign_idx` FOREIGN KEY (`cost_id`) REFERENCES `dbo_administration_product_costs` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_10` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_11` FOREIGN KEY (`products_conditions_id`) REFERENCES `dbo_storage_products_conditions` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_2` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `dbo_storage_locations` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_4` FOREIGN KEY (`entry_type_id`) REFERENCES `dbo_storage_inventory_entry_types` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_5` FOREIGN KEY (`inventory_id`) REFERENCES `dbo_storage_inventories` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_6` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_7` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_8` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_ibfk_9` FOREIGN KEY (`product_price_type_id`) REFERENCES `dbo_administration_product_price_types` (`id`),
  CONSTRAINT `dbo_storage_transaction_items_operation_item_id_foreign_idx` FOREIGN KEY (`operation_item_id`) REFERENCES `dbo_storage_operation_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_transaction_items`
--

LOCK TABLES `dbo_storage_transaction_items` WRITE;
/*!40000 ALTER TABLE `dbo_storage_transaction_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_transaction_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_transaction_lots`
--

DROP TABLE IF EXISTS `dbo_storage_transaction_lots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_transaction_lots` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_item_id` int NOT NULL,
  `lot_id` int NOT NULL,
  `quantity` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `transaction_item_id` (`transaction_item_id`),
  KEY `lot_id` (`lot_id`),
  CONSTRAINT `dbo_storage_transaction_lots_ibfk_1` FOREIGN KEY (`transaction_item_id`) REFERENCES `dbo_storage_transaction_items` (`id`),
  CONSTRAINT `dbo_storage_transaction_lots_ibfk_2` FOREIGN KEY (`lot_id`) REFERENCES `dbo_storage_product_lots` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_transaction_lots`
--

LOCK TABLES `dbo_storage_transaction_lots` WRITE;
/*!40000 ALTER TABLE `dbo_storage_transaction_lots` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_transaction_lots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_transaction_pay_statuses`
--

DROP TABLE IF EXISTS `dbo_storage_transaction_pay_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_transaction_pay_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_transaction_pay_statuses`
--

LOCK TABLES `dbo_storage_transaction_pay_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_storage_transaction_pay_statuses` DISABLE KEYS */;
INSERT INTO `dbo_storage_transaction_pay_statuses` VALUES (1,'PENDIENTE','2024-10-16 22:37:13','2024-10-16 22:37:13'),(2,'PAGADA','2024-10-16 22:37:13','2024-10-16 22:37:13');
/*!40000 ALTER TABLE `dbo_storage_transaction_pay_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_transaction_statuses`
--

DROP TABLE IF EXISTS `dbo_storage_transaction_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_transaction_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_transaction_statuses`
--

LOCK TABLES `dbo_storage_transaction_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_storage_transaction_statuses` DISABLE KEYS */;
INSERT INTO `dbo_storage_transaction_statuses` VALUES (1,'GENERADA','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'APROBADA','2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_storage_transaction_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_transaction_summary_validates`
--

DROP TABLE IF EXISTS `dbo_storage_transaction_summary_validates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_transaction_summary_validates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_id` int NOT NULL,
  `subtotal_exent` float(20,2) DEFAULT '0.00',
  `tax_base` float(20,2) DEFAULT '0.00',
  `subtotal` float(20,2) DEFAULT '0.00',
  `total` float(20,2) DEFAULT '0.00',
  `products` int DEFAULT NULL,
  `items` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `acc_id` int DEFAULT NULL,
  `subtotal_initial` float(24,6) DEFAULT NULL,
  `subtotal_exent_initial` float(24,6) DEFAULT NULL,
  `total_discount` float(24,6) DEFAULT '0.000000',
  `tax_base_initial` float(24,6) DEFAULT NULL,
  `total_initial` float(24,6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `dbo_storage_transaction_summary_validates_acc_id_foreign_idx` (`acc_id`),
  CONSTRAINT `dbo_storage_transaction_summary_validates_acc_id_foreign_idx` FOREIGN KEY (`acc_id`) REFERENCES `dbo_accountancy_accounts` (`id`),
  CONSTRAINT `dbo_storage_transaction_summary_validates_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `dbo_storage_transactions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_transaction_summary_validates`
--

LOCK TABLES `dbo_storage_transaction_summary_validates` WRITE;
/*!40000 ALTER TABLE `dbo_storage_transaction_summary_validates` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_transaction_summary_validates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_storage_transactions`
--

DROP TABLE IF EXISTS `dbo_storage_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_storage_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `number` varchar(255) DEFAULT NULL,
  `control_number` varchar(255) DEFAULT NULL,
  `entry_type_id` int DEFAULT NULL,
  `operation` enum('+','-') DEFAULT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `status_id` int DEFAULT NULL,
  `currency_id` int DEFAULT '1',
  `quantity_verification` int NOT NULL DEFAULT '0',
  `products_verification` int NOT NULL DEFAULT '0',
  `total_quantity` int NOT NULL DEFAULT '0',
  `total_product` int NOT NULL DEFAULT '0',
  `tax_id` int DEFAULT NULL,
  `subtotal` decimal(24,6) DEFAULT NULL,
  `subtotal_without_tax` decimal(24,6) DEFAULT NULL,
  `tax_base` decimal(24,6) DEFAULT NULL,
  `tax_amount` decimal(24,6) DEFAULT NULL,
  `total` decimal(20,2) DEFAULT '0.00',
  `tax_retention` decimal(24,6) DEFAULT NULL,
  `tax_to_pay` decimal(24,6) DEFAULT NULL,
  `exchange_rate_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `invoice_id` int DEFAULT NULL,
  `exchange_rate_provider` float(24,6) DEFAULT NULL,
  `creditday_id` int DEFAULT NULL,
  `expire_date_transaction` datetime DEFAULT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `status_pay_id` int DEFAULT NULL,
  `total_pay` float(20,2) DEFAULT NULL,
  `pay_complete_day` datetime DEFAULT NULL,
  `summary_validate_id` int DEFAULT NULL,
  `converted` tinyint(1) DEFAULT '0',
  `order_number` varchar(255) DEFAULT NULL,
  `discount` float(5,2) DEFAULT '0.00',
  `total_discount` float(24,6) DEFAULT '0.000000',
  `creditnote_po_id` int DEFAULT NULL,
  `debitnote_po_id` int DEFAULT NULL,
  `credit_note_number` varchar(255) DEFAULT NULL,
  `debit_note_number` varchar(255) DEFAULT NULL,
  `refund_id` int DEFAULT NULL,
  `reception_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_type_id` (`entry_type_id`),
  KEY `company_id` (`company_id`),
  KEY `status_id` (`status_id`),
  KEY `currency_id` (`currency_id`),
  KEY `tax_id` (`tax_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `user_id` (`user_id`),
  KEY `dbo_storage_transactions_invoice_id_foreign_idx` (`invoice_id`),
  KEY `dbo_storage_transactions_creditday_id_foreign_idx` (`creditday_id`),
  KEY `dbo_storage_transactions_status_pay_id_foreign_idx` (`status_pay_id`),
  KEY `dbo_storage_transactions_summary_validate_id_foreign_idx` (`summary_validate_id`),
  KEY `dbo_storage_transactions_creditnote_po_id_foreign_idx` (`creditnote_po_id`),
  KEY `dbo_storage_transactions_debitnote_po_id_foreign_idx` (`debitnote_po_id`),
  KEY `dbo_storage_transactions_refund_id_foreign_idx` (`refund_id`),
  CONSTRAINT `dbo_storage_transactions_creditday_id_foreign_idx` FOREIGN KEY (`creditday_id`) REFERENCES `dbo_administration_creditdays` (`id`),
  CONSTRAINT `dbo_storage_transactions_creditnote_po_id_foreign_idx` FOREIGN KEY (`creditnote_po_id`) REFERENCES `dbo_storage_transactions` (`id`),
  CONSTRAINT `dbo_storage_transactions_debitnote_po_id_foreign_idx` FOREIGN KEY (`debitnote_po_id`) REFERENCES `dbo_storage_transactions` (`id`),
  CONSTRAINT `dbo_storage_transactions_ibfk_1` FOREIGN KEY (`entry_type_id`) REFERENCES `dbo_storage_inventory_entry_types` (`id`),
  CONSTRAINT `dbo_storage_transactions_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `dbo_config_companies` (`id`),
  CONSTRAINT `dbo_storage_transactions_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `dbo_storage_transaction_statuses` (`id`),
  CONSTRAINT `dbo_storage_transactions_ibfk_4` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `dbo_storage_transactions_ibfk_5` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `dbo_storage_transactions_ibfk_6` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `dbo_storage_transactions_ibfk_7` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_storage_transactions_invoice_id_foreign_idx` FOREIGN KEY (`invoice_id`) REFERENCES `dbo_administration_invoices` (`id`),
  CONSTRAINT `dbo_storage_transactions_refund_id_foreign_idx` FOREIGN KEY (`refund_id`) REFERENCES `dbo_administration_refunds` (`id`),
  CONSTRAINT `dbo_storage_transactions_status_pay_id_foreign_idx` FOREIGN KEY (`status_pay_id`) REFERENCES `dbo_storage_transaction_pay_statuses` (`id`),
  CONSTRAINT `dbo_storage_transactions_summary_validate_id_foreign_idx` FOREIGN KEY (`summary_validate_id`) REFERENCES `dbo_storage_transaction_summary_validates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_storage_transactions`
--

LOCK TABLES `dbo_storage_transactions` WRITE;
/*!40000 ALTER TABLE `dbo_storage_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_storage_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_supplier_characteristics`
--

DROP TABLE IF EXISTS `dbo_supplier_characteristics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_supplier_characteristics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_supplier_characteristics`
--

LOCK TABLES `dbo_supplier_characteristics` WRITE;
/*!40000 ALTER TABLE `dbo_supplier_characteristics` DISABLE KEYS */;
INSERT INTO `dbo_supplier_characteristics` VALUES (1,'TIPO','2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,'TIPO PRODUCTO','2024-10-16 22:37:11','2024-10-16 22:37:11');
/*!40000 ALTER TABLE `dbo_supplier_characteristics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_supplier_characteristics_values`
--

DROP TABLE IF EXISTS `dbo_supplier_characteristics_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_supplier_characteristics_values` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `characteristic_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `characteristic_id` (`characteristic_id`),
  CONSTRAINT `dbo_supplier_characteristics_values_ibfk_1` FOREIGN KEY (`characteristic_id`) REFERENCES `dbo_supplier_characteristics` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_supplier_characteristics_values`
--

LOCK TABLES `dbo_supplier_characteristics_values` WRITE;
/*!40000 ALTER TABLE `dbo_supplier_characteristics_values` DISABLE KEYS */;
INSERT INTO `dbo_supplier_characteristics_values` VALUES (1,'DETAL',1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,'MAYOR',1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(3,'GENERICO',2,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(4,'USA',2,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(5,'LIBANO',2,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(6,'ESPAÑOL',2,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(7,'NACIONAL',2,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(8,'ITALIANA',2,'2024-10-16 22:37:11','2024-10-16 22:37:11');
/*!40000 ALTER TABLE `dbo_supplier_characteristics_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_supplier_product_characteristics`
--

DROP TABLE IF EXISTS `dbo_supplier_product_characteristics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_supplier_product_characteristics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `characteristics_value_id` int DEFAULT NULL,
  `company_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `characteristics_value_id` (`characteristics_value_id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `dbo_supplier_product_characteristics_ibfk_1` FOREIGN KEY (`characteristics_value_id`) REFERENCES `dbo_supplier_characteristics_values` (`id`),
  CONSTRAINT `dbo_supplier_product_characteristics_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `dbo_config_companies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_supplier_product_characteristics`
--

LOCK TABLES `dbo_supplier_product_characteristics` WRITE;
/*!40000 ALTER TABLE `dbo_supplier_product_characteristics` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_supplier_product_characteristics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_system_customedconfigs`
--

DROP TABLE IF EXISTS `dbo_system_customedconfigs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_system_customedconfigs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customed_parameter` varchar(255) NOT NULL,
  `active` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_system_customedconfigs`
--

LOCK TABLES `dbo_system_customedconfigs` WRITE;
/*!40000 ALTER TABLE `dbo_system_customedconfigs` DISABLE KEYS */;
INSERT INTO `dbo_system_customedconfigs` VALUES (1,'Verificación al realizar descuento',0,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(2,'Verificación al reimprimir factura',0,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(3,'Quitar IVA a la nota de entrega',0,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(4,'Descuento a Items Incluyendo el IVA (Descuento \"Plano\")',0,'2024-10-16 22:37:13','2024-10-16 22:37:13'),(5,'Mostrar IGTF en Nota Entrega (ticketera)',0,'2024-10-16 22:37:14','2024-10-16 22:37:14'),(6,'Mostrar IGTF con total Nota Entrega (ticketera)',0,'2024-10-16 22:37:14','2024-10-16 22:37:14'),(7,'Mostrar Vendedor Nota Entrega (ticketera)',0,'2024-10-16 22:37:14','2024-10-16 22:37:14'),(8,'Mostrar Campo de tipo de pago Divisa en Nota Entrega (ticketera)',0,'2024-10-16 22:37:14','2024-10-16 22:37:14'),(9,'Mostrar Campo de tipo de pago Debito en Nota Entrega (ticketera)',0,'2024-10-16 22:37:14','2024-10-16 22:37:14'),(10,'Mostrar Campo Referencia en la Nota Entrega (ticketera)',0,'2024-10-16 22:37:14','2024-10-16 22:37:14'),(11,'Inventario Cajero Flexible (adaptable en factura)',0,'2024-10-16 22:37:14','2024-10-16 22:37:14'),(12,'Inventario cajero flexible (Adaptable en factura)',0,'2024-10-16 22:37:14','2024-10-16 22:37:14'),(13,'Imprimir notas de entrega en la impresora fiscal (comandera)',0,'2024-10-16 22:53:34','2024-10-16 22:53:34'),(14,'Agregar igtf a las notas de entrega',0,'2024-10-16 22:53:34','2024-10-16 22:53:34'),(15,'Ver facturas de otras cajas que estén pendiente',0,'2024-10-16 22:53:34','2024-10-16 22:53:34'),(16,'Cambiar vendedor en facturas, (Luego de un cambio solo lo podrán hacer el administrador o supervisor)',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(17,'Activar Autorización para Eliminar Producto de Pedidos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(18,'Activar Autorización para Eliminar Pagos de Pedidos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(19,'Activar Autorización para Cancelar Pedidos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(20,'Habilitar uso de códigos personalizados para los productos',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(21,'Crear facturas no fiscales (NF)',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(22,'Mostrar dialog para cambiar entre facturas fiscales y no fiscales',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(23,'Activar autorización extensa por roles',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(24,'Ocultar previsualización del IGTF en Ventas',0,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(25,'Activar indexación de tasa de cambio a facturas a crédito',0,'2024-10-16 22:53:36','2024-10-16 22:53:36');
/*!40000 ALTER TABLE `dbo_system_customedconfigs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_system_notification_types`
--

DROP TABLE IF EXISTS `dbo_system_notification_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_system_notification_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_system_notification_types`
--

LOCK TABLES `dbo_system_notification_types` WRITE;
/*!40000 ALTER TABLE `dbo_system_notification_types` DISABLE KEYS */;
INSERT INTO `dbo_system_notification_types` VALUES (1,'GENÉRICA','2024-10-16 22:53:34','2024-10-16 22:53:34'),(2,'FALLA','2024-10-16 22:53:34','2024-10-16 22:53:34'),(3,'CIERRE DE CAJA','2024-10-16 22:53:34','2024-10-16 22:53:34');
/*!40000 ALTER TABLE `dbo_system_notification_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_system_notification_user_statuses`
--

DROP TABLE IF EXISTS `dbo_system_notification_user_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_system_notification_user_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `notification_id` int NOT NULL,
  `user_id` int NOT NULL,
  `read` tinyint(1) DEFAULT '0',
  `delete` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `notification_id` (`notification_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `dbo_system_notification_user_statuses_ibfk_1` FOREIGN KEY (`notification_id`) REFERENCES `dbo_system_notifications` (`id`),
  CONSTRAINT `dbo_system_notification_user_statuses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_system_notification_user_statuses`
--

LOCK TABLES `dbo_system_notification_user_statuses` WRITE;
/*!40000 ALTER TABLE `dbo_system_notification_user_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_system_notification_user_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_system_notifications`
--

DROP TABLE IF EXISTS `dbo_system_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_system_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `notification_type_id` int NOT NULL,
  `text` varchar(255) NOT NULL,
  `user_id` int NOT NULL,
  `shortage_id` int DEFAULT NULL,
  `cash_register_close_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `notification_type_id` (`notification_type_id`),
  KEY `user_id` (`user_id`),
  KEY `shortage_id` (`shortage_id`),
  KEY `cash_register_close_id` (`cash_register_close_id`),
  CONSTRAINT `dbo_system_notifications_ibfk_1` FOREIGN KEY (`notification_type_id`) REFERENCES `dbo_system_notification_types` (`id`),
  CONSTRAINT `dbo_system_notifications_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_system_notifications_ibfk_3` FOREIGN KEY (`shortage_id`) REFERENCES `dbo_administration_product_shortages` (`id`),
  CONSTRAINT `dbo_system_notifications_ibfk_4` FOREIGN KEY (`cash_register_close_id`) REFERENCES `dbo_pos_cash_register_closes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_system_notifications`
--

LOCK TABLES `dbo_system_notifications` WRITE;
/*!40000 ALTER TABLE `dbo_system_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `dbo_system_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_system_product_presentations`
--

DROP TABLE IF EXISTS `dbo_system_product_presentations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_system_product_presentations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_system_product_presentations`
--

LOCK TABLES `dbo_system_product_presentations` WRITE;
/*!40000 ALTER TABLE `dbo_system_product_presentations` DISABLE KEYS */;
INSERT INTO `dbo_system_product_presentations` VALUES (1,'BLISTER','2024-10-16 22:37:12','2024-10-16 22:37:12'),(2,'BOLSA','2024-10-16 22:37:12','2024-10-16 22:37:12'),(3,'BOTELLA','2024-10-16 22:37:12','2024-10-16 22:37:12'),(4,'CAJA','2024-10-16 22:37:12','2024-10-16 22:37:12'),(5,'CMS','2024-10-16 22:37:12','2024-10-16 22:37:12'),(6,'FRASCO','2024-10-16 22:37:12','2024-10-16 22:37:12'),(7,'GALON','2024-10-16 22:37:12','2024-10-16 22:37:12'),(8,'INHALADOR','2024-10-16 22:37:12','2024-10-16 22:37:12'),(9,'KG','2024-10-16 22:37:12','2024-10-16 22:37:12'),(10,'LATA','2024-10-16 22:37:12','2024-10-16 22:37:12'),(11,'LITRO','2024-10-16 22:37:12','2024-10-16 22:37:12'),(12,'ML','2024-10-16 22:37:12','2024-10-16 22:37:12'),(13,'PAQUETE','2024-10-16 22:37:12','2024-10-16 22:37:12'),(14,'PAR','2024-10-16 22:37:12','2024-10-16 22:37:12'),(15,'PORCION','2024-10-16 22:37:12','2024-10-16 22:37:12'),(16,'PZA','2024-10-16 22:37:12','2024-10-16 22:37:12'),(17,'SOBRE','2024-10-16 22:37:12','2024-10-16 22:37:12'),(18,'SOLUCION','2024-10-16 22:37:12','2024-10-16 22:37:12'),(19,'UNIDAD','2024-10-16 22:37:12','2024-10-16 22:37:12'),(20,'VIDON','2024-10-16 22:37:12','2024-10-16 22:37:12');
/*!40000 ALTER TABLE `dbo_system_product_presentations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_system_rols`
--

DROP TABLE IF EXISTS `dbo_system_rols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_system_rols` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_system_rols`
--

LOCK TABLES `dbo_system_rols` WRITE;
/*!40000 ALTER TABLE `dbo_system_rols` DISABLE KEYS */;
INSERT INTO `dbo_system_rols` VALUES (1,'CAJERO','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'SUPERVISOR','2024-10-16 22:37:10','2024-10-16 22:37:10'),(3,'ADMINISTRADOR','2024-10-16 22:37:10','2024-10-16 22:37:10'),(4,'ADMINISTRADOR DE INVENTARIO','2024-10-16 22:37:10','2024-10-16 22:37:10'),(5,'VENDEDOR','2024-10-16 22:37:10','2024-10-16 22:37:10'),(6,'ADMINISTRADOR DE SISTEMAS','2024-10-16 22:53:35','2024-10-16 22:53:35'),(7,'PDV: CREAR CIERRES / CERRAR CIERRES','2024-10-16 22:53:35','2024-10-16 22:53:35'),(8,'PDV: DESCUENTOS','2024-10-16 22:53:35','2024-10-16 22:53:35'),(9,'PDV: APROBAR DEVOLUCIONES','2024-10-16 22:53:35','2024-10-16 22:53:35'),(10,'PDV: REIMPRIMIR FACTURAS / NOTAS','2024-10-16 22:53:35','2024-10-16 22:53:35'),(11,'ALMACÉN: EDITAR INVENTARIO','2024-10-16 22:53:35','2024-10-16 22:53:35'),(14,'ADMINISTRACIÓN: EDITAR PRECIOS','2024-10-16 22:53:35','2024-10-16 22:53:35'),(15,'CONFIGURACIÓN: ASIGNAR ROLES','2024-10-16 22:53:35','2024-10-16 22:53:35'),(16,'CONFIGURACIÓN: CREAR TASA DE CAMBIO','2024-10-16 22:53:35','2024-10-16 22:53:35'),(17,'CONFIGURACIÓN: CREAR USUARIOS','2024-10-16 22:53:35','2024-10-16 22:53:35');
/*!40000 ALTER TABLE `dbo_system_rols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_system_user_roles`
--

DROP TABLE IF EXISTS `dbo_system_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_system_user_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `dbo_system_user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dbo_system_users` (`id`),
  CONSTRAINT `dbo_system_user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `dbo_system_rols` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_system_user_roles`
--

LOCK TABLES `dbo_system_user_roles` WRITE;
/*!40000 ALTER TABLE `dbo_system_user_roles` DISABLE KEYS */;
INSERT INTO `dbo_system_user_roles` VALUES (1,1,3,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(2,2,2,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(3,3,1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(4,4,4,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(5,5,3,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(6,6,5,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(7,7,3,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(8,7,1,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(9,7,2,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(10,7,3,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(11,7,4,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(12,7,5,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(13,7,6,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(14,7,7,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(15,7,8,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(16,7,9,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(17,7,10,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(18,7,11,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(19,7,14,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(20,7,15,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(21,7,16,'2024-10-16 22:53:35','2024-10-16 22:53:35'),(22,7,17,'2024-10-16 22:53:35','2024-10-16 22:53:35');
/*!40000 ALTER TABLE `dbo_system_user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_system_users`
--

DROP TABLE IF EXISTS `dbo_system_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_system_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `rol_id` int DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `rol_id` (`rol_id`),
  CONSTRAINT `dbo_system_users_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `dbo_system_rols` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_system_users`
--

LOCK TABLES `dbo_system_users` WRITE;
/*!40000 ALTER TABLE `dbo_system_users` DISABLE KEYS */;
INSERT INTO `dbo_system_users` VALUES (1,'administrador','1a8565a9dc72048ba03b4156be3e569f22771f23','0001','ADMINISTRADOR','ADMINISTRADOR',3,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(2,'supervisor','1a8565a9dc72048ba03b4156be3e569f22771f23','0002','SUPERVISOR','SUPERVISOR',2,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(3,'cajero','1a8565a9dc72048ba03b4156be3e569f22771f23','0003','CAJERO','CAJERO',1,'2024-10-16 22:37:11','2024-10-16 22:37:11'),(4,'almacen','1a8565a9dc72048ba03b4156be3e569f22771f23','0004','ADMINISTRADOR','ALMACEN',4,'2024-10-16 22:53:34','2024-10-16 22:53:34'),(5,'strix','cb4f036bac11f04a00a4cce15f762e033fc9a068','0005','STRIX','TECHNOLOGY',3,'2024-10-16 22:53:34','2024-10-16 22:53:34'),(6,'vendedor','1a8565a9dc72048ba03b4156be3e569f22771f23','0006','VENDEDOR','VENDEDOR',5,'2024-10-16 22:53:34','2024-10-16 22:53:34'),(7,'adminsis','3a8a7fdcd76724e986e28b502660aecaaace7906','0007','ADMINISTRADOR DE SISTEMAS',' ',3,'2024-10-16 22:53:35','2024-10-16 22:53:35');
/*!40000 ALTER TABLE `dbo_system_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dbo_type_currencies`
--

DROP TABLE IF EXISTS `dbo_type_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `dbo_type_currencies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dbo_type_currencies`
--

LOCK TABLES `dbo_type_currencies` WRITE;
/*!40000 ALTER TABLE `dbo_type_currencies` DISABLE KEYS */;
INSERT INTO `dbo_type_currencies` VALUES (1,'ELECTRONICO','2024-10-16 22:37:10','2024-10-16 22:37:10'),(2,'EFECTIVO','2024-10-16 22:37:10','2024-10-16 22:37:10');
/*!40000 ALTER TABLE `dbo_type_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preview_update_massives`
--

DROP TABLE IF EXISTS `preview_update_massives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `preview_update_massives` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount_raw` decimal(20,2) DEFAULT NULL,
  `new_amount_raw` decimal(20,2) DEFAULT NULL,
  `amount_exchange_rate_old` decimal(20,2) DEFAULT NULL,
  `amount_exchange_rate_new` decimal(20,2) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `new_amount` varchar(255) DEFAULT NULL,
  `tax_id` int DEFAULT NULL,
  `exchange_rate_id` int DEFAULT NULL,
  `old_exchange_rate_id` int DEFAULT NULL,
  `currency_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `abbreviation` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `code_bar` varchar(255) DEFAULT NULL,
  `percentage_new` decimal(5,4) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cost` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax_id` (`tax_id`),
  KEY `exchange_rate_id` (`exchange_rate_id`),
  KEY `old_exchange_rate_id` (`old_exchange_rate_id`),
  KEY `currency_id` (`currency_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `preview_update_massives_ibfk_1` FOREIGN KEY (`tax_id`) REFERENCES `dbo_config_taxes` (`id`),
  CONSTRAINT `preview_update_massives_ibfk_2` FOREIGN KEY (`exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `preview_update_massives_ibfk_3` FOREIGN KEY (`old_exchange_rate_id`) REFERENCES `dbo_config_exchange_rates` (`id`),
  CONSTRAINT `preview_update_massives_ibfk_4` FOREIGN KEY (`currency_id`) REFERENCES `dbo_config_currencies` (`id`),
  CONSTRAINT `preview_update_massives_ibfk_5` FOREIGN KEY (`product_id`) REFERENCES `dbo_storage_products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preview_update_massives`
--

LOCK TABLES `preview_update_massives` WRITE;
/*!40000 ALTER TABLE `preview_update_massives` DISABLE KEYS */;
/*!40000 ALTER TABLE `preview_update_massives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `printer_status_data`
--

DROP TABLE IF EXISTS `printer_status_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8 */;
CREATE TABLE `printer_status_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `status_code` varchar(255) DEFAULT NULL,
  `cashregister_user_number` varchar(255) DEFAULT NULL,
  `total_daily_invoices` varchar(255) DEFAULT NULL,
  `last_invoice_number` varchar(255) DEFAULT NULL,
  `daily_invoice_quantity` varchar(255) DEFAULT NULL,
  `last_debitnote_number` varchar(255) DEFAULT NULL,
  `daily_debitnote_quantity` varchar(255) DEFAULT NULL,
  `last_creditnote_number` varchar(255) DEFAULT NULL,
  `daily_creditnote_quantity` varchar(255) DEFAULT NULL,
  `last_nonfiscal_document_number` varchar(255) DEFAULT NULL,
  `daily_nonfiscal_documents_quantity` varchar(255) DEFAULT NULL,
  `daily_fiscal_memory_reports` varchar(255) DEFAULT NULL,
  `daily_closes_counter` varchar(255) DEFAULT NULL,
  `registered_enterprise_fiscal_document_number` varchar(255) DEFAULT NULL,
  `printer_register_number` varchar(255) DEFAULT NULL,
  `printer_current_time` varchar(255) DEFAULT NULL,
  `printer_current_date` varchar(255) DEFAULT NULL,
  `update_date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `printer_status_data`
--

LOCK TABLES `printer_status_data` WRITE;
/*!40000 ALTER TABLE `printer_status_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `printer_status_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_accountancy_accounts`
--

DROP TABLE IF EXISTS `view_accountancy_accounts`;
/*!50001 DROP VIEW IF EXISTS `view_accountancy_accounts`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_accountancy_accounts` AS SELECT 
 1 AS `id`,
 1 AS `code`,
 1 AS `description`,
 1 AS `company_type_id`,
 1 AS `company_type`,
 1 AS `company_type_short`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_accountancy_operations`
--

DROP TABLE IF EXISTS `view_accountancy_operations`;
/*!50001 DROP VIEW IF EXISTS `view_accountancy_operations`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_accountancy_operations` AS SELECT 
 1 AS `code`,
 1 AS `description`,
 1 AS `debit`,
 1 AS `credit`,
 1 AS `operation_number`,
 1 AS `operation_type_name`,
 1 AS `invoice_number`,
 1 AS `saleorder_number`,
 1 AS `customer_name`,
 1 AS `provider_name`,
 1 AS `user_name`,
 1 AS `receipt_number`,
 1 AS `createdAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_bank_payment_types`
--

DROP TABLE IF EXISTS `view_bank_payment_types`;
/*!50001 DROP VIEW IF EXISTS `view_bank_payment_types`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_bank_payment_types` AS SELECT 
 1 AS `id`,
 1 AS `display_name`,
 1 AS `payment_type_id`,
 1 AS `bank_id`,
 1 AS `currency_id`,
 1 AS `bank_name`,
 1 AS `currency_name`,
 1 AS `abbreviation`,
 1 AS `payment_name`,
 1 AS `show`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_bank_payment_types_invoice`
--

DROP TABLE IF EXISTS `view_bank_payment_types_invoice`;
/*!50001 DROP VIEW IF EXISTS `view_bank_payment_types_invoice`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_bank_payment_types_invoice` AS SELECT 
 1 AS `id`,
 1 AS `display_name`,
 1 AS `payment_type_id`,
 1 AS `bank_id`,
 1 AS `currency_id`,
 1 AS `bank_name`,
 1 AS `currency_name`,
 1 AS `abbreviation`,
 1 AS `payment_name`,
 1 AS `show`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_banks`
--

DROP TABLE IF EXISTS `view_banks`;
/*!50001 DROP VIEW IF EXISTS `view_banks`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_banks` AS SELECT 
 1 AS `id`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_cash_register_closes`
--

DROP TABLE IF EXISTS `view_cash_register_closes`;
/*!50001 DROP VIEW IF EXISTS `view_cash_register_closes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_cash_register_closes` AS SELECT 
 1 AS `id`,
 1 AS `closeDate`,
 1 AS `status_id`,
 1 AS `cash_register_id`,
 1 AS `total_unit`,
 1 AS `total_product`,
 1 AS `total_invoices`,
 1 AS `status`,
 1 AS `name`,
 1 AS `code`,
 1 AS `user_id`,
 1 AS `user_name`,
 1 AS `admin_name`,
 1 AS `createdAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_cash_registers`
--

DROP TABLE IF EXISTS `view_cash_registers`;
/*!50001 DROP VIEW IF EXISTS `view_cash_registers`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_cash_registers` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `code`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_categories`
--

DROP TABLE IF EXISTS `view_categories`;
/*!50001 DROP VIEW IF EXISTS `view_categories`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_categories` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `createdAtFormat`,
 1 AS `createdAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_changes_grid`
--

DROP TABLE IF EXISTS `view_changes_grid`;
/*!50001 DROP VIEW IF EXISTS `view_changes_grid`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_changes_grid` AS SELECT 
 1 AS `id`,
 1 AS `amount`,
 1 AS `observation`,
 1 AS `amount_formated`,
 1 AS `id_name`,
 1 AS `createdAt_h`,
 1 AS `createdAt`,
 1 AS `invoice_number`,
 1 AS `saleorder_number`,
 1 AS `exchange_rate`,
 1 AS `exchange_rate_formated`,
 1 AS `withdraw_type`,
 1 AS `user_name`,
 1 AS `withdrawUser`,
 1 AS `cash_register_close_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_clients`
--

DROP TABLE IF EXISTS `view_clients`;
/*!50001 DROP VIEW IF EXISTS `view_clients`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_clients` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `last_name`,
 1 AS `telephone`,
 1 AS `identification_number`,
 1 AS `direction`,
 1 AS `tax_withholding_id`,
 1 AS `city`,
 1 AS `state`,
 1 AS `email`,
 1 AS `discount_text`,
 1 AS `discount`,
 1 AS `discount_type_id`,
 1 AS `country_name`,
 1 AS `percentage`,
 1 AS `observation`,
 1 AS `postal_code`,
 1 AS `identification_type_id`,
 1 AS `identification_type`,
 1 AS `gender_id`,
 1 AS `gender_name`,
 1 AS `id_number`,
 1 AS `balance`,
 1 AS `createdAt`,
 1 AS `updatedAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_companies`
--

DROP TABLE IF EXISTS `view_companies`;
/*!50001 DROP VIEW IF EXISTS `view_companies`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_companies` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `identification_number`,
 1 AS `address`,
 1 AS `telephone_1`,
 1 AS `telephone_2`,
 1 AS `identification_type_id`,
 1 AS `tax_withholding_id`,
 1 AS `withholding_name`,
 1 AS `identification_type`,
 1 AS `id_number`,
 1 AS `createdAt`,
 1 AS `updatedAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_company_accounts`
--

DROP TABLE IF EXISTS `view_company_accounts`;
/*!50001 DROP VIEW IF EXISTS `view_company_accounts`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_company_accounts` AS SELECT 
 1 AS `id`,
 1 AS `company_id`,
 1 AS `currency_id`,
 1 AS `company_name`,
 1 AS `bank_name`,
 1 AS `number_account`,
 1 AS `currency_name`,
 1 AS `user_name`,
 1 AS `createdAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_creditdays`
--

DROP TABLE IF EXISTS `view_creditdays`;
/*!50001 DROP VIEW IF EXISTS `view_creditdays`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_creditdays` AS SELECT 
 1 AS `id`,
 1 AS `days`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_creditnote_types`
--

DROP TABLE IF EXISTS `view_creditnote_types`;
/*!50001 DROP VIEW IF EXISTS `view_creditnote_types`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_creditnote_types` AS SELECT 
 1 AS `id`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_creditnotes`
--

DROP TABLE IF EXISTS `view_creditnotes`;
/*!50001 DROP VIEW IF EXISTS `view_creditnotes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_creditnotes` AS SELECT 
 1 AS `id`,
 1 AS `coupon_number`,
 1 AS `creditnote_number`,
 1 AS `observations`,
 1 AS `status`,
 1 AS `client`,
 1 AS `amount`,
 1 AS `user`,
 1 AS `created_at`,
 1 AS `type`,
 1 AS `saleorder_number`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_currencies`
--

DROP TABLE IF EXISTS `view_currencies`;
/*!50001 DROP VIEW IF EXISTS `view_currencies`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_currencies` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `abbreviation`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_currency_denominations`
--

DROP TABLE IF EXISTS `view_currency_denominations`;
/*!50001 DROP VIEW IF EXISTS `view_currency_denominations`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_currency_denominations` AS SELECT 
 1 AS `id`,
 1 AS `currency_id`,
 1 AS `value`,
 1 AS `active`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_debitnote_types`
--

DROP TABLE IF EXISTS `view_debitnote_types`;
/*!50001 DROP VIEW IF EXISTS `view_debitnote_types`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_debitnote_types` AS SELECT 
 1 AS `id`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_debitnotes`
--

DROP TABLE IF EXISTS `view_debitnotes`;
/*!50001 DROP VIEW IF EXISTS `view_debitnotes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_debitnotes` AS SELECT 
 1 AS `id`,
 1 AS `debitnote_number`,
 1 AS `observations`,
 1 AS `status`,
 1 AS `client`,
 1 AS `amount`,
 1 AS `user`,
 1 AS `created_at`,
 1 AS `type`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_exchange_rate`
--

DROP TABLE IF EXISTS `view_exchange_rate`;
/*!50001 DROP VIEW IF EXISTS `view_exchange_rate`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_exchange_rate` AS SELECT 
 1 AS `id`,
 1 AS `exchange_rate`,
 1 AS `rate_formated`,
 1 AS `currency_id`,
 1 AS `name`,
 1 AS `abbreviation`,
 1 AS `createdAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_history_sold_purchase_products`
--

DROP TABLE IF EXISTS `view_history_sold_purchase_products`;
/*!50001 DROP VIEW IF EXISTS `view_history_sold_purchase_products`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_history_sold_purchase_products` AS SELECT 
 1 AS `id`,
 1 AS `product_id`,
 1 AS `code_bar`,
 1 AS `code`,
 1 AS `description`,
 1 AS `entry_types_name`,
 1 AS `unity_sold`,
 1 AS `unity_purchase`,
 1 AS `operation_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_inventories`
--

DROP TABLE IF EXISTS `view_inventories`;
/*!50001 DROP VIEW IF EXISTS `view_inventories`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_inventories` AS SELECT 
 1 AS `id`,
 1 AS `code_bar`,
 1 AS `code`,
 1 AS `description`,
 1 AS `quantity`,
 1 AS `reserve`,
 1 AS `cost_bs`,
 1 AS `cost_usd`,
 1 AS `price_bs`,
 1 AS `price_usd`,
 1 AS `lot`,
 1 AS `serial`,
 1 AS `expirateDate`,
 1 AS `brand_name`,
 1 AS `presentation_name`,
 1 AS `condition_name`,
 1 AS `category`,
 1 AS `subcategory`,
 1 AS `warehouse`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_invoices`
--

DROP TABLE IF EXISTS `view_invoices`;
/*!50001 DROP VIEW IF EXISTS `view_invoices`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_invoices` AS SELECT 
 1 AS `id`,
 1 AS `invoice_number`,
 1 AS `saleorder_number`,
 1 AS `seller_id`,
 1 AS `seller_name`,
 1 AS `total_product`,
 1 AS `total_unit`,
 1 AS `total`,
 1 AS `total_igtf`,
 1 AS `total_formated`,
 1 AS `total_igtf_formated`,
 1 AS `subtotal_formated`,
 1 AS `subtotal`,
 1 AS `discount`,
 1 AS `discount_formated`,
 1 AS `credit`,
 1 AS `fiscal`,
 1 AS `reprinted`,
 1 AS `reprintedDate`,
 1 AS `tax_to_pay`,
 1 AS `retention_tax`,
 1 AS `total_formated_usd`,
 1 AS `total_unformated_usd`,
 1 AS `createdAt`,
 1 AS `cash_register_close_id`,
 1 AS `finance_status_id`,
 1 AS `createdAt_formated`,
 1 AS `name`,
 1 AS `identification_number`,
 1 AS `id_name`,
 1 AS `username`,
 1 AS `status`,
 1 AS `finance_status`,
 1 AS `exchange_rate`,
 1 AS `exchange_rate_formated`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_locations`
--

DROP TABLE IF EXISTS `view_locations`;
/*!50001 DROP VIEW IF EXISTS `view_locations`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_locations` AS SELECT 
 1 AS `id`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_manage_prices`
--

DROP TABLE IF EXISTS `view_manage_prices`;
/*!50001 DROP VIEW IF EXISTS `view_manage_prices`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_manage_prices` AS SELECT 
 1 AS `id`,
 1 AS `code`,
 1 AS `description`,
 1 AS `code_bar`,
 1 AS `amount_bs`,
 1 AS `amount_formated_bs`,
 1 AS `updateAt_bs`,
 1 AS `updateAt_bs_formated`,
 1 AS `amount_usd`,
 1 AS `amount_formated_usd`,
 1 AS `cost_bs`,
 1 AS `cost_usd`,
 1 AS `updateAt_usd`,
 1 AS `updatedAt_ord`,
 1 AS `user_name`,
 1 AS `updateAt_usd_formated`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_my_company_accounts`
--

DROP TABLE IF EXISTS `view_my_company_accounts`;
/*!50001 DROP VIEW IF EXISTS `view_my_company_accounts`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_my_company_accounts` AS SELECT 
 1 AS `id`,
 1 AS `currency_id`,
 1 AS `bank_name`,
 1 AS `number_account`,
 1 AS `currency_name`,
 1 AS `user_name`,
 1 AS `createdAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_pay_to_clients`
--

DROP TABLE IF EXISTS `view_pay_to_clients`;
/*!50001 DROP VIEW IF EXISTS `view_pay_to_clients`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_pay_to_clients` AS SELECT 
 1 AS `invoice_number`,
 1 AS `saleorder_number`,
 1 AS `reference`,
 1 AS `client_name`,
 1 AS `bank_name`,
 1 AS `payment_type_name`,
 1 AS `exchange_rate`,
 1 AS `amount_usd`,
 1 AS `amount_bs`,
 1 AS `createdAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_payment_expenses`
--

DROP TABLE IF EXISTS `view_payment_expenses`;
/*!50001 DROP VIEW IF EXISTS `view_payment_expenses`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_payment_expenses` AS SELECT 
 1 AS `id`,
 1 AS `control_number`,
 1 AS `invoice_number`,
 1 AS `origin_bank`,
 1 AS `origin_bank_number`,
 1 AS `destination_bank`,
 1 AS `destination_bank_number`,
 1 AS `amount`,
 1 AS `currency`,
 1 AS `provider`,
 1 AS `status`,
 1 AS `reference`,
 1 AS `user_name`,
 1 AS `payment_date`,
 1 AS `createdAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_payment_types`
--

DROP TABLE IF EXISTS `view_payment_types`;
/*!50001 DROP VIEW IF EXISTS `view_payment_types`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_payment_types` AS SELECT 
 1 AS `id`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_payments`
--

DROP TABLE IF EXISTS `view_payments`;
/*!50001 DROP VIEW IF EXISTS `view_payments`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_payments` AS SELECT 
 1 AS `id`,
 1 AS `amount`,
 1 AS `ref`,
 1 AS `payment_type_id`,
 1 AS `bank_id`,
 1 AS `currency_id`,
 1 AS `invoice_id`,
 1 AS `bank_name`,
 1 AS `currency_name`,
 1 AS `abbreviation`,
 1 AS `payment_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_payments_grid`
--

DROP TABLE IF EXISTS `view_payments_grid`;
/*!50001 DROP VIEW IF EXISTS `view_payments_grid`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_payments_grid` AS SELECT 
 1 AS `id`,
 1 AS `amount`,
 1 AS `cash_register_close_id`,
 1 AS `amount_formated`,
 1 AS `id_name`,
 1 AS `createdAt_h`,
 1 AS `createdAt`,
 1 AS `invoice_number`,
 1 AS `saleorder_number`,
 1 AS `ref`,
 1 AS `total_formated`,
 1 AS `total_formated_$`,
 1 AS `exchange_rate`,
 1 AS `exchange_rate_formated`,
 1 AS `user_name`,
 1 AS `deposit`,
 1 AS `finance_status_id`,
 1 AS `bank_name`,
 1 AS `currency_name`,
 1 AS `type_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_preview_update_massives`
--

DROP TABLE IF EXISTS `view_preview_update_massives`;
/*!50001 DROP VIEW IF EXISTS `view_preview_update_massives`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_preview_update_massives` AS SELECT 
 1 AS `id`,
 1 AS `amount_raw`,
 1 AS `new_amount_raw`,
 1 AS `amount`,
 1 AS `new_amount`,
 1 AS `tax_id`,
 1 AS `exchange_rate_id`,
 1 AS `old_exchange_rate_id`,
 1 AS `currency_id`,
 1 AS `product_id`,
 1 AS `abbreviation`,
 1 AS `description`,
 1 AS `amount_currency`,
 1 AS `new_amount_currency`,
 1 AS `code`,
 1 AS `code_bar`,
 1 AS `percentage_new`,
 1 AS `percentage`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_price_types_client`
--

DROP TABLE IF EXISTS `view_price_types_client`;
/*!50001 DROP VIEW IF EXISTS `view_price_types_client`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_price_types_client` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `percen`,
 1 AS `percentage`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_price_types_product`
--

DROP TABLE IF EXISTS `view_price_types_product`;
/*!50001 DROP VIEW IF EXISTS `view_price_types_product`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_price_types_product` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `percentage`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_product_categories`
--

DROP TABLE IF EXISTS `view_product_categories`;
/*!50001 DROP VIEW IF EXISTS `view_product_categories`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_product_categories` AS SELECT 
 1 AS `id`,
 1 AS `product`,
 1 AS `category`,
 1 AS `subcategory`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_product_price_bs`
--

DROP TABLE IF EXISTS `view_product_price_bs`;
/*!50001 DROP VIEW IF EXISTS `view_product_price_bs`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_product_price_bs` AS SELECT 
 1 AS `id`,
 1 AS `amount`,
 1 AS `amount_formated`,
 1 AS `product_id`,
 1 AS `user_id`,
 1 AS `name`,
 1 AS `last_name`,
 1 AS `updatedAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_product_price_usd`
--

DROP TABLE IF EXISTS `view_product_price_usd`;
/*!50001 DROP VIEW IF EXISTS `view_product_price_usd`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_product_price_usd` AS SELECT 
 1 AS `id`,
 1 AS `amount`,
 1 AS `amount_formated`,
 1 AS `product_id`,
 1 AS `user_id`,
 1 AS `name`,
 1 AS `last_name`,
 1 AS `updatedAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_products_solds`
--

DROP TABLE IF EXISTS `view_products_solds`;
/*!50001 DROP VIEW IF EXISTS `view_products_solds`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_products_solds` AS SELECT 
 1 AS `product_id`,
 1 AS `code_bar`,
 1 AS `code`,
 1 AS `description`,
 1 AS `quantity`,
 1 AS `date_sould`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_purchases`
--

DROP TABLE IF EXISTS `view_purchases`;
/*!50001 DROP VIEW IF EXISTS `view_purchases`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_purchases` AS SELECT 
 1 AS `id`,
 1 AS `number`,
 1 AS `control_number`,
 1 AS `company_id`,
 1 AS `status_id`,
 1 AS `name_company`,
 1 AS `status`,
 1 AS `entry_types_name`,
 1 AS `observation`,
 1 AS `total_quantity`,
 1 AS `total_product`,
 1 AS `subtotal`,
 1 AS `tax`,
 1 AS `total`,
 1 AS `invoice_number`,
 1 AS `currency`,
 1 AS `user`,
 1 AS `exchange_rate`,
 1 AS `exchange_rate_provider`,
 1 AS `credit_days`,
 1 AS `expire_date_transaction`,
 1 AS `transaction_date`,
 1 AS `createdAt`,
 1 AS `status_pay_name`,
 1 AS `total_pending`,
 1 AS `pay_complete_day`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_refunds_index`
--

DROP TABLE IF EXISTS `view_refunds_index`;
/*!50001 DROP VIEW IF EXISTS `view_refunds_index`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_refunds_index` AS SELECT 
 1 AS `id`,
 1 AS `invoice_id`,
 1 AS `refunds_status_id`,
 1 AS `total_product`,
 1 AS `total_quantity`,
 1 AS `subtotal`,
 1 AS `tax_amount`,
 1 AS `total`,
 1 AS `invoice_number`,
 1 AS `saleorder_number`,
 1 AS `client`,
 1 AS `refunds_status`,
 1 AS `creditnote_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_selected_payments_grid`
--

DROP TABLE IF EXISTS `view_selected_payments_grid`;
/*!50001 DROP VIEW IF EXISTS `view_selected_payments_grid`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_selected_payments_grid` AS SELECT 
 1 AS `id`,
 1 AS `amount`,
 1 AS `amount_formated`,
 1 AS `id_name`,
 1 AS `createdAt_h`,
 1 AS `createdAt`,
 1 AS `ref`,
 1 AS `abbreviation`,
 1 AS `exchange_rate`,
 1 AS `exchange_rate_formated`,
 1 AS `user_name`,
 1 AS `bank_name`,
 1 AS `currency_name`,
 1 AS `bank_payment_type`,
 1 AS `type_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_subcategories`
--

DROP TABLE IF EXISTS `view_subcategories`;
/*!50001 DROP VIEW IF EXISTS `view_subcategories`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_subcategories` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `category`,
 1 AS `createdAt`,
 1 AS `updatedAt`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_taxes`
--

DROP TABLE IF EXISTS `view_taxes`;
/*!50001 DROP VIEW IF EXISTS `view_taxes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_taxes` AS SELECT 
 1 AS `id`,
 1 AS `percentage`,
 1 AS `observation`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_total_cash_bs`
--

DROP TABLE IF EXISTS `view_total_cash_bs`;
/*!50001 DROP VIEW IF EXISTS `view_total_cash_bs`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_total_cash_bs` AS SELECT 
 1 AS `cash_register_close_id`,
 1 AS `total_bs`,
 1 AS `total_invoices_bs`,
 1 AS `subtotal_bs`,
 1 AS `electronicTotal_bs`,
 1 AS `cashTotal_bs`,
 1 AS `tax_bs`,
 1 AS `tax_to_pay_bs`,
 1 AS `retention_tax_bs`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_total_cash_bs_footer`
--

DROP TABLE IF EXISTS `view_total_cash_bs_footer`;
/*!50001 DROP VIEW IF EXISTS `view_total_cash_bs_footer`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_total_cash_bs_footer` AS SELECT 
 1 AS `cash_register_close_id`,
 1 AS `total_bs`,
 1 AS `total_invoices_bs`,
 1 AS `subtotal_bs`,
 1 AS `electronicTotal_bs`,
 1 AS `cashTotal_bs`,
 1 AS `tax_bs`,
 1 AS `tax_to_pay_bs`,
 1 AS `retention_tax_bs`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_total_cash_usd`
--

DROP TABLE IF EXISTS `view_total_cash_usd`;
/*!50001 DROP VIEW IF EXISTS `view_total_cash_usd`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_total_cash_usd` AS SELECT 
 1 AS `cash_register_close_id`,
 1 AS `total_usd`,
 1 AS `total_invoices_usd`,
 1 AS `subtotal_usd`,
 1 AS `electronicTotal_usd`,
 1 AS `cashTotal_usd`,
 1 AS `tax_usd`,
 1 AS `tax_to_pay_usd`,
 1 AS `retention_tax_usd`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_total_cash_usd_footer`
--

DROP TABLE IF EXISTS `view_total_cash_usd_footer`;
/*!50001 DROP VIEW IF EXISTS `view_total_cash_usd_footer`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_total_cash_usd_footer` AS SELECT 
 1 AS `cash_register_close_id`,
 1 AS `total_usd`,
 1 AS `total_invoices_usd`,
 1 AS `subtotal_usd`,
 1 AS `electronicTotal_usd`,
 1 AS `cashTotal_usd`,
 1 AS `tax_usd`,
 1 AS `tax_to_pay_usd`,
 1 AS `retention_tax_usd`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_totals_cash`
--

DROP TABLE IF EXISTS `view_totals_cash`;
/*!50001 DROP VIEW IF EXISTS `view_totals_cash`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_totals_cash` AS SELECT 
 1 AS `CRC_id`,
 1 AS `closeDate`,
 1 AS `createdAt`,
 1 AS `user_id`,
 1 AS `name`,
 1 AS `total_bs`,
 1 AS `total_invoices_bs`,
 1 AS `subtotal_bs`,
 1 AS `tax_bs`,
 1 AS `tax_to_pay_bs`,
 1 AS `retention_tax_bs`,
 1 AS `electronicTotal_bs`,
 1 AS `cashTotal_bs`,
 1 AS `total_usd`,
 1 AS `total_invoices_usd`,
 1 AS `subtotal_usd`,
 1 AS `tax_usd`,
 1 AS `tax_to_pay_usd`,
 1 AS `retention_tax_usd`,
 1 AS `electronicTotal_usd`,
 1 AS `cashTotal_usd`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_totals_cash_footer`
--

DROP TABLE IF EXISTS `view_totals_cash_footer`;
/*!50001 DROP VIEW IF EXISTS `view_totals_cash_footer`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_totals_cash_footer` AS SELECT 
 1 AS `CRC_id`,
 1 AS `closeDate`,
 1 AS `createdAt`,
 1 AS `user_id`,
 1 AS `name`,
 1 AS `total_bs`,
 1 AS `total_invoices_bs`,
 1 AS `subtotal_bs`,
 1 AS `tax_bs`,
 1 AS `tax_to_pay_bs`,
 1 AS `retention_tax_bs`,
 1 AS `electronicTotal_bs`,
 1 AS `cashTotal_bs`,
 1 AS `total_usd`,
 1 AS `total_invoices_usd`,
 1 AS `subtotal_usd`,
 1 AS `tax_usd`,
 1 AS `tax_to_pay_usd`,
 1 AS `retention_tax_usd`,
 1 AS `electronicTotal_usd`,
 1 AS `cashTotal_usd`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_transactions`
--

DROP TABLE IF EXISTS `view_transactions`;
/*!50001 DROP VIEW IF EXISTS `view_transactions`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_transactions` AS SELECT 
 1 AS `document_type`,
 1 AS `id`,
 1 AS `number`,
 1 AS `credit_note_number`,
 1 AS `debit_note_number`,
 1 AS `control_number`,
 1 AS `company_id`,
 1 AS `status_id`,
 1 AS `user`,
 1 AS `exchange_rate_provider`,
 1 AS `name_company`,
 1 AS `status`,
 1 AS `entry_types_name`,
 1 AS `createdAt`,
 1 AS `credit_days`,
 1 AS `updatedAt`,
 1 AS `observation`,
 1 AS `total_quantity`,
 1 AS `total_product`,
 1 AS `subtotal`,
 1 AS `tax`,
 1 AS `total`,
 1 AS `invoice_number`,
 1 AS `currency`,
 1 AS `expire_date_transaction`,
 1 AS `transaction_date`,
 1 AS `exchange_rate`,
 1 AS `created_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_types_currencies`
--

DROP TABLE IF EXISTS `view_types_currencies`;
/*!50001 DROP VIEW IF EXISTS `view_types_currencies`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_types_currencies` AS SELECT 
 1 AS `id`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_users`
--

DROP TABLE IF EXISTS `view_users`;
/*!50001 DROP VIEW IF EXISTS `view_users`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_users` AS SELECT 
 1 AS `id`,
 1 AS `username`,
 1 AS `password`,
 1 AS `name`,
 1 AS `last_name`,
 1 AS `rol_id`,
 1 AS `rol`,
 1 AS `createdAt`,
 1 AS `updatedAt`,
 1 AS `user_roles`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_users_types`
--

DROP TABLE IF EXISTS `view_users_types`;
/*!50001 DROP VIEW IF EXISTS `view_users_types`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8 */;
/*!50001 CREATE VIEW `view_users_types` AS SELECT 
 1 AS `id`,
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'clean_pos'
--

--
-- Final view structure for view `view_accountancy_accounts`
--

/*!50001 DROP VIEW IF EXISTS `view_accountancy_accounts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_accountancy_accounts` AS select `dac`.`id` AS `id`,concat(left(`dac`.`code`,1),if((`dac`.`code` > 10),concat('-',substr(`dac`.`code`,2,1)),''),if((`dac`.`code` > 100),concat('-',substr(`dac`.`code`,3,2)),''),if((`dac`.`code` > 10000),concat('-',right(`dac`.`code`,3)),'')) AS `code`,`dac`.`description` AS `description`,`dac`.`company_type_id` AS `company_type_id`,`dact`.`description` AS `company_type`,`dact`.`short` AS `company_type_short` from (`dbo_accountancy_accounts` `dac` join `dbo_accountancy_company_types` `dact` on((`dac`.`company_type_id` = `dact`.`id`))) order by `dac`.`code` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_accountancy_operations`
--

/*!50001 DROP VIEW IF EXISTS `view_accountancy_operations`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_accountancy_operations` AS select `vaa`.`code` AS `code`,`vaa`.`description` AS `description`,`dao`.`debit` AS `debit`,`dao`.`credit` AS `credit`,`dao`.`operation_number` AS `operation_number`,`daot`.`name` AS `operation_type_name`,if(`dai`.`id`,`dai`.`invoice_number`,`dst`.`invoice_number`) AS `invoice_number`,if(`dai`.`id`,`dai`.`saleorder_number`,`dst`.`control_number`) AS `saleorder_number`,concat(`dcit_client`.`name`,'-',`dsc`.`identification_number`,' ',`dsc`.`name`,' ',`dsc`.`last_name`) AS `customer_name`,concat(`dcit_company`.`name`,'-',`dcc`.`identification_number`,' ',`dcc`.`name`) AS `provider_name`,concat(`su`.`name`,' ',`su`.`last_name`) AS `user_name`,`dao`.`correlative_number` AS `receipt_number`,date_format(`dao`.`createdAt`,'%d/%m/%Y %r') AS `createdAt` from (((((((((`dbo_accountancy_operations` `dao` join `dbo_system_users` `su` on((`dao`.`user_id` = `su`.`id`))) join `view_accountancy_accounts` `vaa` on((`dao`.`accountancy_id` = `vaa`.`id`))) left join `dbo_administration_invoices` `dai` on((`dao`.`invoice_id` = `dai`.`id`))) left join `dbo_sales_clients` `dsc` on((`dai`.`client_id` = `dsc`.`id`))) left join `dbo_config_identifications_types` `dcit_client` on((`dsc`.`identification_type_id` = `dcit_client`.`id`))) left join `dbo_storage_transactions` `dst` on((`dao`.`transaction_id` = `dst`.`id`))) left join `dbo_config_companies` `dcc` on((`dst`.`company_id` = `dcc`.`id`))) left join `dbo_config_identifications_types` `dcit_company` on((`dcc`.`identification_type_id` = `dcit_company`.`id`))) left join `dbo_accountancy_operation_types` `daot` on((`dao`.`operation_type_id` = `daot`.`id`))) order by `dao`.`id` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_bank_payment_types`
--

/*!50001 DROP VIEW IF EXISTS `view_bank_payment_types`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_bank_payment_types` AS select `dbo_finance_bank_payment_types`.`id` AS `id`,`dbo_finance_bank_payment_types`.`display_name` AS `display_name`,`dbo_finance_bank_payment_types`.`payment_type_id` AS `payment_type_id`,`dbo_finance_bank_payment_types`.`bank_id` AS `bank_id`,`dbo_finance_bank_payment_types`.`currency_id` AS `currency_id`,`dbo_finance_banks`.`name` AS `bank_name`,`dbo_config_currencies`.`name` AS `currency_name`,`dbo_config_currencies`.`abbreviation` AS `abbreviation`,`dbo_finance_payment_types`.`name` AS `payment_name`,`dbo_finance_bank_payment_types`.`show` AS `show` from (((`dbo_finance_bank_payment_types` join `dbo_finance_banks` on((`dbo_finance_bank_payment_types`.`bank_id` = `dbo_finance_banks`.`id`))) join `dbo_finance_payment_types` on((`dbo_finance_bank_payment_types`.`payment_type_id` = `dbo_finance_payment_types`.`id`))) join `dbo_config_currencies` on((`dbo_finance_bank_payment_types`.`currency_id` = `dbo_config_currencies`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_bank_payment_types_invoice`
--

/*!50001 DROP VIEW IF EXISTS `view_bank_payment_types_invoice`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_bank_payment_types_invoice` AS select `dbo_finance_bank_payment_types`.`id` AS `id`,`dbo_finance_bank_payment_types`.`display_name` AS `display_name`,`dbo_finance_bank_payment_types`.`payment_type_id` AS `payment_type_id`,`dbo_finance_bank_payment_types`.`bank_id` AS `bank_id`,`dbo_finance_bank_payment_types`.`currency_id` AS `currency_id`,`dbo_finance_banks`.`name` AS `bank_name`,`dbo_config_currencies`.`name` AS `currency_name`,`dbo_config_currencies`.`abbreviation` AS `abbreviation`,`dbo_finance_payment_types`.`name` AS `payment_name`,`dbo_finance_bank_payment_types`.`show` AS `show` from (((`dbo_finance_bank_payment_types` join `dbo_finance_banks` on((`dbo_finance_bank_payment_types`.`bank_id` = `dbo_finance_banks`.`id`))) join `dbo_finance_payment_types` on((`dbo_finance_bank_payment_types`.`payment_type_id` = `dbo_finance_payment_types`.`id`))) join `dbo_config_currencies` on((`dbo_finance_bank_payment_types`.`currency_id` = `dbo_config_currencies`.`id`))) where (`dbo_finance_bank_payment_types`.`show` = true) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_banks`
--

/*!50001 DROP VIEW IF EXISTS `view_banks`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_banks` AS select `dbo_finance_banks`.`id` AS `id`,`dbo_finance_banks`.`name` AS `name` from `dbo_finance_banks` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_cash_register_closes`
--

/*!50001 DROP VIEW IF EXISTS `view_cash_register_closes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_cash_register_closes` AS select `CRC`.`id` AS `id`,date_format(`CRC`.`closeDate`,'%d-%m-%Y %r') AS `closeDate`,`CRC`.`status_id` AS `status_id`,`CRC`.`cash_register_id` AS `cash_register_id`,`CRC`.`total_unit` AS `total_unit`,`CRC`.`total_product` AS `total_product`,`CRC`.`total_invoices` AS `total_invoices`,`dbo_pos_cash_register_close_statuses`.`name` AS `status`,`dbo_pos_cash_registers`.`name` AS `name`,`dbo_pos_cash_registers`.`code` AS `code`,`CRC`.`user_id` AS `user_id`,`US`.`name` AS `user_name`,`AD`.`name` AS `admin_name`,date_format(`CRC`.`createdAt`,'%d-%m-%Y %r') AS `createdAt` from ((((`dbo_pos_cash_register_closes` `CRC` join `dbo_pos_cash_register_close_statuses` on((`CRC`.`status_id` = `dbo_pos_cash_register_close_statuses`.`id`))) join `dbo_pos_cash_registers` on((`CRC`.`cash_register_id` = `dbo_pos_cash_registers`.`id`))) join `dbo_system_users` `US` on((`CRC`.`user_id` = `US`.`id`))) left join `dbo_system_users` `AD` on((`CRC`.`admin_user_id` = `AD`.`id`))) order by `CRC`.`createdAt` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_cash_registers`
--

/*!50001 DROP VIEW IF EXISTS `view_cash_registers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_cash_registers` AS select `dbo_pos_cash_registers`.`id` AS `id`,`dbo_pos_cash_registers`.`name` AS `name`,`dbo_pos_cash_registers`.`code` AS `code` from `dbo_pos_cash_registers` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_categories`
--

/*!50001 DROP VIEW IF EXISTS `view_categories`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_categories` AS select `dbo_storage_categories`.`id` AS `id`,`dbo_storage_categories`.`name` AS `name`,date_format(`dbo_storage_categories`.`createdAt`,'%d-%m-%Y') AS `createdAtFormat`,`dbo_storage_categories`.`createdAt` AS `createdAt` from `dbo_storage_categories` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_changes_grid`
--

/*!50001 DROP VIEW IF EXISTS `view_changes_grid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_changes_grid` AS select `W`.`id` AS `id`,`W`.`amount` AS `amount`,`W`.`observation` AS `observation`,concat(convert(format(`W`.`amount`,2,'de_DE') using utf8mb3),`IC`.`abbreviation`) AS `amount_formated`,concat(`dbo_config_identifications_types`.`name`,'-',`dbo_sales_clients`.`identification_number`,' ',`dbo_sales_clients`.`name`,' ') AS `id_name`,date_format(`W`.`createdAt`,'%r') AS `createdAt_h`,date_format(`W`.`createdAt`,'%d-%m-%Y %r') AS `createdAt`,`Invoice`.`invoice_number` AS `invoice_number`,`Invoice`.`saleorder_number` AS `saleorder_number`,`dbo_config_exchange_rates`.`exchange_rate` AS `exchange_rate`,format(`dbo_config_exchange_rates`.`exchange_rate`,2,'de_DE') AS `exchange_rate_formated`,`dbo_pos_withdraw_types`.`name` AS `withdraw_type`,`user`.`username` AS `user_name`,ifnull(concat(`idenTypeClientBene`.`name`,'-',`clientBeneficiary`.`identification_number`,' ',`clientBeneficiary`.`name`),`withdrawUser`.`name`) AS `withdrawUser`,`dbo_pos_cash_register_close_withdraws`.`cash_register_close_id` AS `cash_register_close_id` from (((((((((((`dbo_pos_withdraws` `W` join `dbo_pos_withdraw_types` on((`W`.`withdraw_type_id` = `dbo_pos_withdraw_types`.`id`))) join `dbo_pos_cash_register_close_withdraws` on((`dbo_pos_cash_register_close_withdraws`.`withdraw_id` = `W`.`id`))) join `dbo_system_users` `user` on((`W`.`user_id` = `user`.`id`))) join `dbo_config_exchange_rates` on((`W`.`exchange_rate_id` = `dbo_config_exchange_rates`.`id`))) join `dbo_config_currencies` `IC` on((`W`.`currency_id` = `IC`.`id`))) left join `dbo_system_users` `withdrawUser` on((`W`.`withdraw_user` = `withdrawUser`.`id`))) left join `dbo_sales_clients` `clientBeneficiary` on((`W`.`client_id` = `clientBeneficiary`.`id`))) left join `dbo_config_identifications_types` `idenTypeClientBene` on((`idenTypeClientBene`.`id` = `clientBeneficiary`.`identification_type_id`))) left join `dbo_administration_invoices` `Invoice` on((`W`.`invoice_id` = `Invoice`.`id`))) left join `dbo_sales_clients` on((`Invoice`.`client_id` = `dbo_sales_clients`.`id`))) left join `dbo_config_identifications_types` on((`dbo_sales_clients`.`identification_type_id` = `dbo_config_identifications_types`.`id`))) order by `W`.`id` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_clients`
--

/*!50001 DROP VIEW IF EXISTS `view_clients`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_clients` AS select `dbo_sales_clients`.`id` AS `id`,`dbo_sales_clients`.`name` AS `name`,`dbo_sales_clients`.`last_name` AS `last_name`,`dbo_sales_clients`.`telephone` AS `telephone`,`dbo_sales_clients`.`identification_number` AS `identification_number`,`dbo_sales_clients`.`direction` AS `direction`,`dbo_sales_clients`.`tax_withholding_id` AS `tax_withholding_id`,`dbo_sales_clients`.`city` AS `city`,`dbo_sales_clients`.`state` AS `state`,`dbo_sales_clients`.`email` AS `email`,`ddt`.`observation` AS `discount_text`,`ddt`.`percentage` AS `discount`,`ddt`.`id` AS `discount_type_id`,ifnull(`dbo_config_countries`.`name`,'') AS `country_name`,`retention`.`percentage` AS `percentage`,`retention`.`observation` AS `observation`,`dbo_sales_clients`.`postal_code` AS `postal_code`,`dbo_sales_clients`.`identification_type_id` AS `identification_type_id`,`dbo_config_identifications_types`.`name` AS `identification_type`,`dbo_sales_clients`.`gender_id` AS `gender_id`,`dcg`.`name` AS `gender_name`,concat(`dbo_config_identifications_types`.`name`,'-',`dbo_sales_clients`.`identification_number`) AS `id_number`,concat(convert(format(`dbo_finances_balances`.`amount`,2) using utf8mb3),`cb`.`abbreviation`) AS `balance`,`dbo_sales_clients`.`createdAt` AS `createdAt`,`dbo_sales_clients`.`updatedAt` AS `updatedAt` from (((((((`dbo_sales_clients` join `dbo_config_identifications_types` on((`dbo_sales_clients`.`identification_type_id` = `dbo_config_identifications_types`.`id`))) join `dbo_finances_balances` on((`dbo_finances_balances`.`client_id` = `dbo_sales_clients`.`id`))) join `dbo_config_currencies` `cb` on((`cb`.`id` = `dbo_finances_balances`.`currency_id`))) join `dbo_config_tax_withholdings` `retention` on((`retention`.`id` = `dbo_sales_clients`.`tax_withholding_id`))) left join `dbo_config_countries` on((`dbo_config_countries`.`id` = `dbo_sales_clients`.`country_id`))) left join `dbo_discount_types` `ddt` on((`ddt`.`id` = `dbo_sales_clients`.`discount_type_id`))) left join `dbo_config_genders` `dcg` on((`dcg`.`id` = `dbo_sales_clients`.`gender_id`))) where (`dbo_finances_balances`.`currency_id` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_companies`
--

/*!50001 DROP VIEW IF EXISTS `view_companies`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_companies` AS select `dbo_config_companies`.`id` AS `id`,`dbo_config_companies`.`name` AS `name`,`dbo_config_companies`.`identification_number` AS `identification_number`,`dbo_config_companies`.`address` AS `address`,`dbo_config_companies`.`telephone_1` AS `telephone_1`,`dbo_config_companies`.`telephone_2` AS `telephone_2`,`dbo_config_companies`.`identification_type_id` AS `identification_type_id`,`dbo_config_companies`.`tax_withholding_id` AS `tax_withholding_id`,`dbo_config_tax_withholdings`.`observation` AS `withholding_name`,`dbo_config_identifications_types`.`name` AS `identification_type`,concat(`dbo_config_identifications_types`.`name`,'-',`dbo_config_companies`.`identification_number`) AS `id_number`,`dbo_config_companies`.`createdAt` AS `createdAt`,`dbo_config_companies`.`updatedAt` AS `updatedAt` from ((`dbo_config_companies` join `dbo_config_identifications_types` on((`dbo_config_companies`.`identification_type_id` = `dbo_config_identifications_types`.`id`))) join `dbo_config_tax_withholdings` on((`dbo_config_companies`.`tax_withholding_id` = `dbo_config_tax_withholdings`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_company_accounts`
--

/*!50001 DROP VIEW IF EXISTS `view_company_accounts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_company_accounts` AS select `daca`.`id` AS `id`,`dccomp`.`id` AS `company_id`,`dccurr`.`id` AS `currency_id`,`dccomp`.`name` AS `company_name`,`dfb`.`name` AS `bank_name`,concat(left(`daca`.`number_account`,4),'-',substr(`daca`.`number_account`,5,4),'-',substr(`daca`.`number_account`,9,2),'-',right(`daca`.`number_account`,10)) AS `number_account`,`dccurr`.`name` AS `currency_name`,concat(`dsu`.`name`,' ',`dsu`.`last_name`) AS `user_name`,date_format(`daca`.`createdAt`,'%d-%m-%Y') AS `createdAt` from ((((`dbo_administration_company_accounts` `daca` join `dbo_config_companies` `dccomp` on((`daca`.`company_id` = `dccomp`.`id`))) join `dbo_finance_banks` `dfb` on((`daca`.`bank_id` = `dfb`.`id`))) join `dbo_config_currencies` `dccurr` on((`daca`.`currency_id` = `dccurr`.`id`))) join `dbo_system_users` `dsu` on((`daca`.`user_id` = `dsu`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_creditdays`
--

/*!50001 DROP VIEW IF EXISTS `view_creditdays`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_creditdays` AS select `dbo_administration_creditdays`.`id` AS `id`,`dbo_administration_creditdays`.`days` AS `days`,`dbo_administration_creditdays`.`name` AS `name` from `dbo_administration_creditdays` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_creditnote_types`
--

/*!50001 DROP VIEW IF EXISTS `view_creditnote_types`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_creditnote_types` AS select `dbo_finance_creditnotes_types`.`id` AS `id`,`dbo_finance_creditnotes_types`.`name` AS `name` from `dbo_finance_creditnotes_types` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_creditnotes`
--

/*!50001 DROP VIEW IF EXISTS `view_creditnotes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_creditnotes` AS select `dbo_finance_creditnotes`.`id` AS `id`,`dbo_finance_creditnotes`.`coupon_number` AS `coupon_number`,`dbo_finance_creditnotes`.`creditnote_number` AS `creditnote_number`,`dbo_finance_creditnotes`.`observations` AS `observations`,`dbo_finance_creditnotes_statuses`.`name` AS `status`,concat(ifnull(`dbo_sales_clients`.`name`,''),' ',ifnull(`dbo_sales_clients`.`last_name`,'')) AS `client`,concat(convert(format(`dbo_finance_creditnotes`.`creditnote_amount`,2) using utf8mb3),`dbo_config_currencies`.`abbreviation`) AS `amount`,concat(ifnull(`dbo_system_users`.`name`,''),' ',ifnull(`dbo_system_users`.`last_name`,'')) AS `user`,date_format(`dbo_finance_creditnotes`.`createdAt`,'%H:%i:%s %d/%m/%Y') AS `created_at`,`dbo_finance_creditnotes_types`.`name` AS `type`,`dbo_administration_invoices`.`saleorder_number` AS `saleorder_number` from ((((((`dbo_finance_creditnotes` join `dbo_sales_clients` on((`dbo_sales_clients`.`id` = `dbo_finance_creditnotes`.`client_id`))) join `dbo_finance_creditnotes_statuses` on((`dbo_finance_creditnotes_statuses`.`id` = `dbo_finance_creditnotes`.`status_id`))) join `dbo_config_currencies` on((`dbo_config_currencies`.`id` = `dbo_finance_creditnotes`.`currency_id`))) join `dbo_system_users` on((`dbo_system_users`.`id` = `dbo_finance_creditnotes`.`user_id`))) join `dbo_finance_creditnotes_types` on((`dbo_finance_creditnotes_types`.`id` = `dbo_finance_creditnotes`.`creditnote_type_id`))) left join `dbo_administration_invoices` on((`dbo_finance_creditnotes`.`invoice_id` = `dbo_administration_invoices`.`id`))) order by `dbo_finance_creditnotes`.`id` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_currencies`
--

/*!50001 DROP VIEW IF EXISTS `view_currencies`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_currencies` AS select `dbo_config_currencies`.`id` AS `id`,`dbo_config_currencies`.`name` AS `name`,`dbo_config_currencies`.`abbreviation` AS `abbreviation` from `dbo_config_currencies` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_currency_denominations`
--

/*!50001 DROP VIEW IF EXISTS `view_currency_denominations`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_currency_denominations` AS select `dccd`.`id` AS `id`,`dccd`.`currency_id` AS `currency_id`,format(`dccd`.`value`,2,'de_DE') AS `value`,if((`dccd`.`active` = 0),'Inactivo','Activo') AS `active` from `dbo_config_currency_denominations` `dccd` order by `dccd`.`value` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_debitnote_types`
--

/*!50001 DROP VIEW IF EXISTS `view_debitnote_types`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_debitnote_types` AS select `dbo_finance_debitnotes_types`.`id` AS `id`,`dbo_finance_debitnotes_types`.`name` AS `name` from `dbo_finance_debitnotes_types` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_debitnotes`
--

/*!50001 DROP VIEW IF EXISTS `view_debitnotes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_debitnotes` AS select `dbo_finance_debitnotes`.`id` AS `id`,`dbo_finance_debitnotes`.`debitnote_number` AS `debitnote_number`,`dbo_finance_debitnotes`.`observations` AS `observations`,`dbo_finance_debitnotes_statuses`.`name` AS `status`,concat(ifnull(`dbo_sales_clients`.`name`,''),' ',ifnull(`dbo_sales_clients`.`last_name`,'')) AS `client`,concat(convert(format(`dbo_finance_debitnotes`.`debitnote_amount`,2) using utf8mb3),`dbo_config_currencies`.`abbreviation`) AS `amount`,concat(ifnull(`dbo_system_users`.`name`,''),' ',ifnull(`dbo_system_users`.`last_name`,'')) AS `user`,date_format(`dbo_finance_debitnotes`.`createdAt`,'%H:%i:%s %d/%m/%Y') AS `created_at`,`dbo_finance_debitnotes_types`.`name` AS `type` from (((((`dbo_finance_debitnotes` join `dbo_sales_clients` on((`dbo_sales_clients`.`id` = `dbo_finance_debitnotes`.`client_id`))) join `dbo_finance_debitnotes_statuses` on((`dbo_finance_debitnotes_statuses`.`id` = `dbo_finance_debitnotes`.`status_id`))) join `dbo_config_currencies` on((`dbo_config_currencies`.`id` = `dbo_finance_debitnotes`.`currency_id`))) join `dbo_system_users` on((`dbo_system_users`.`id` = `dbo_finance_debitnotes`.`user_id`))) join `dbo_finance_debitnotes_types` on((`dbo_finance_debitnotes_types`.`id` = `dbo_finance_debitnotes`.`debitnote_type_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_exchange_rate`
--

/*!50001 DROP VIEW IF EXISTS `view_exchange_rate`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_exchange_rate` AS select `dbo_config_exchange_rates`.`id` AS `id`,`dbo_config_exchange_rates`.`exchange_rate` AS `exchange_rate`,format(`dbo_config_exchange_rates`.`exchange_rate`,2,'de_DE') AS `rate_formated`,`dbo_config_exchange_rates`.`currency_id` AS `currency_id`,`dbo_config_currencies`.`name` AS `name`,`dbo_config_currencies`.`abbreviation` AS `abbreviation`,date_format(`dbo_config_exchange_rates`.`createdAt`,'%d-%m-%Y %r') AS `createdAt` from (`dbo_config_exchange_rates` join `dbo_config_currencies` on((`dbo_config_exchange_rates`.`currency_id` = `dbo_config_currencies`.`id`))) order by `dbo_config_exchange_rates`.`createdAt` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_history_sold_purchase_products`
--

/*!50001 DROP VIEW IF EXISTS `view_history_sold_purchase_products`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_history_sold_purchase_products` AS select `dbo_storage_inventory_history`.`id` AS `id`,`dbo_storage_products`.`id` AS `product_id`,`dbo_storage_products`.`code_bar` AS `code_bar`,`dbo_storage_products`.`code` AS `code`,`dbo_storage_products`.`description` AS `description`,`dbo_storage_inventory_entry_types`.`name` AS `entry_types_name`,(case when (`dbo_storage_inventory_history`.`operation` = '-') then `dbo_storage_inventory_history`.`quantity` else 0 end) AS `unity_sold`,(case when (`dbo_storage_inventory_history`.`operation` = '+') then `dbo_storage_inventory_history`.`quantity` else 0 end) AS `unity_purchase`,date_format(`dbo_storage_inventory_history`.`createdAt`,'%Y-%m-%d %r') AS `operation_date` from ((`dbo_storage_inventory_history` left join `dbo_storage_products` on((`dbo_storage_inventory_history`.`product_id` = `dbo_storage_products`.`id`))) join `dbo_storage_inventory_entry_types` on((`dbo_storage_inventory_entry_types`.`id` = `dbo_storage_inventory_history`.`entry_type_id`))) order by `dbo_storage_inventory_history`.`createdAt` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_inventories`
--

/*!50001 DROP VIEW IF EXISTS `view_inventories`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_inventories` AS select `dbo_storage_inventories`.`id` AS `id`,`dbo_storage_products`.`code_bar` AS `code_bar`,`dbo_storage_products`.`code` AS `code`,`dbo_storage_products`.`description` AS `description`,`dbo_storage_inventories`.`quantity` AS `quantity`,`dbo_storage_inventories`.`reserve` AS `reserve`,format(`dbo_administration_product_costs`.`cost_bs`,2,'de_DE') AS `cost_bs`,format(`dbo_administration_product_costs`.`cost_usd`,2,'de_DE') AS `cost_usd`,format(`dbo_administration_products_price_amounts_bs`.`amount`,2,'de_DE') AS `price_bs`,format(`dbo_administration_products_price_amounts_usd`.`amount`,2,'de_DE') AS `price_usd`,`dbo_storage_inventories`.`lot` AS `lot`,`dbo_storage_inventories`.`serial` AS `serial`,date_format(`dbo_storage_inventories`.`expirateDate`,'%d-%m-%Y') AS `expirateDate`,`dbo_storage_brands`.`name` AS `brand_name`,`dbo_system_product_presentations`.`name` AS `presentation_name`,`dbo_storage_products_conditions`.`name` AS `condition_name`,`view_product_categories`.`category` AS `category`,`view_product_categories`.`subcategory` AS `subcategory`,`dbo_storage_locations`.`name` AS `warehouse` from (((((((((`dbo_storage_inventories` join `dbo_storage_products` on((`dbo_storage_inventories`.`product_id` = `dbo_storage_products`.`id`))) join `dbo_storage_products_conditions` on((`dbo_storage_inventories`.`status_id` = `dbo_storage_products_conditions`.`id`))) join `dbo_storage_locations` on((`dbo_storage_inventories`.`location_id` = `dbo_storage_locations`.`id`))) left join `dbo_administration_product_costs` on(((`dbo_storage_products`.`id` = `dbo_administration_product_costs`.`product_id`) and (`dbo_administration_product_costs`.`active` = true)))) join `dbo_administration_products_price_amounts` `dbo_administration_products_price_amounts_bs` on(((`dbo_administration_products_price_amounts_bs`.`currency_id` = 2) and (`dbo_administration_products_price_amounts_bs`.`product_id` = `dbo_storage_products`.`id`)))) join `dbo_administration_products_price_amounts` `dbo_administration_products_price_amounts_usd` on(((`dbo_administration_products_price_amounts_usd`.`currency_id` = 1) and (`dbo_administration_products_price_amounts_usd`.`product_id` = `dbo_storage_products`.`id`)))) left join `view_product_categories` on((`dbo_storage_products`.`id` = `view_product_categories`.`id`))) left join `dbo_storage_brands` on((`dbo_storage_products`.`brand_id` = `dbo_storage_brands`.`id`))) left join `dbo_system_product_presentations` on((`dbo_storage_products`.`presentation_id` = `dbo_system_product_presentations`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_invoices`
--

/*!50001 DROP VIEW IF EXISTS `view_invoices`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_invoices` AS select `dbo_administration_invoices`.`id` AS `id`,`dbo_administration_invoices`.`invoice_number` AS `invoice_number`,`dbo_administration_invoices`.`saleorder_number` AS `saleorder_number`,`seller`.`id` AS `seller_id`,concat(ifnull(`seller`.`name`,''),' ',ifnull(`seller`.`last_name`,'')) AS `seller_name`,`dbo_administration_invoices`.`total_product` AS `total_product`,`dbo_administration_invoices`.`total_unit` AS `total_unit`,`dbo_administration_invoices`.`real_total` AS `total`,`dbo_administration_invoices`.`real_total_add_igtf` AS `total_igtf`,format(`dbo_administration_invoices`.`real_total`,2,'de_DE') AS `total_formated`,format(`dbo_administration_invoices`.`real_total_add_igtf`,2,'de_DE') AS `total_igtf_formated`,format(`dbo_administration_invoices`.`subtotal`,2,'de_DE') AS `subtotal_formated`,`dbo_administration_invoices`.`subtotal` AS `subtotal`,`dbo_administration_invoices`.`discount` AS `discount`,format(`dbo_administration_invoices`.`discount`,2,'de_DE') AS `discount_formated`,if((`dbo_administration_invoices`.`parnet_type` = 1),'Socio',if((`dbo_administration_invoices`.`credit` = 0),'Contado','Crédito')) AS `credit`,if((`dbo_administration_invoices`.`fiscal` = 0),'No Fiscal','Fiscal') AS `fiscal`,if((`dbo_administration_invoices`.`printed` = 0),'No','Si') AS `reprinted`,`dbo_administration_invoices`.`reprintedDate` AS `reprintedDate`,format(`dbo_administration_invoices`.`tax_to_pay`,2,'de_DE') AS `tax_to_pay`,format(`dbo_administration_invoices`.`retention_tax`,2,'de_DE') AS `retention_tax`,format(`AIAC`.`real_total`,2,'de_DE') AS `total_formated_usd`,`AIAC`.`real_total` AS `total_unformated_usd`,`dbo_administration_invoices`.`createdAt` AS `createdAt`,`dbo_administration_invoices`.`cash_register_close_id` AS `cash_register_close_id`,`dbo_administration_invoices`.`finance_status_id` AS `finance_status_id`,date_format(`dbo_administration_invoices`.`createdAt`,'%d-%m-%Y %r') AS `createdAt_formated`,`dbo_sales_clients`.`name` AS `name`,`dbo_sales_clients`.`identification_number` AS `identification_number`,concat(`dbo_config_identifications_types`.`name`,'-',`dbo_sales_clients`.`identification_number`,' ',`dbo_sales_clients`.`name`,' ') AS `id_name`,`dbo_system_users`.`username` AS `username`,`dbo_administration_invoice_statuses`.`name` AS `status`,`dbo_administration_invoice_finance_statuses`.`name` AS `finance_status`,`dbo_config_exchange_rates`.`exchange_rate` AS `exchange_rate`,format(`dbo_config_exchange_rates`.`exchange_rate`,2,'de_DE') AS `exchange_rate_formated` from (((((((((`dbo_administration_invoices` left join `dbo_config_taxes` on((`dbo_administration_invoices`.`tax_id` = `dbo_config_taxes`.`id`))) left join `dbo_sales_clients` on((`dbo_administration_invoices`.`client_id` = `dbo_sales_clients`.`id`))) left join `dbo_system_users` on((`dbo_administration_invoices`.`user_id` = `dbo_system_users`.`id`))) left join `dbo_config_identifications_types` on((`dbo_sales_clients`.`identification_type_id` = `dbo_config_identifications_types`.`id`))) left join `dbo_administration_invoice_statuses` on((`dbo_administration_invoices`.`status_id` = `dbo_administration_invoice_statuses`.`id`))) left join `dbo_administration_invoice_finance_statuses` on((`dbo_administration_invoices`.`finance_status_id` = `dbo_administration_invoice_finance_statuses`.`id`))) left join `dbo_config_exchange_rates` on((`dbo_administration_invoices`.`exchange_rate_id` = `dbo_config_exchange_rates`.`id`))) left join `dbo_administration_invoices_all_currencies` `AIAC` on(((`dbo_administration_invoices`.`id` = `AIAC`.`invoice_id`) and (`AIAC`.`currency_id` = 1)))) left join `dbo_system_users` `seller` on((`seller`.`id` = `dbo_administration_invoices`.`seller_id`))) order by `dbo_administration_invoices`.`createdAt` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_locations`
--

/*!50001 DROP VIEW IF EXISTS `view_locations`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_locations` AS select `dbo_storage_locations`.`id` AS `id`,`dbo_storage_locations`.`name` AS `name` from `dbo_storage_locations` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_manage_prices`
--

/*!50001 DROP VIEW IF EXISTS `view_manage_prices`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_manage_prices` AS select `dbo_storage_products`.`id` AS `id`,`dbo_storage_products`.`code` AS `code`,`dbo_storage_products`.`description` AS `description`,`dbo_storage_products`.`code_bar` AS `code_bar`,`view_product_price_bs`.`amount` AS `amount_bs`,format(`view_product_price_bs`.`amount`,2,'de_DE') AS `amount_formated_bs`,`view_product_price_bs`.`updatedAt` AS `updateAt_bs`,date_format(`view_product_price_bs`.`updatedAt`,'%d-%m-%Y %r') AS `updateAt_bs_formated`,`view_product_price_usd`.`amount` AS `amount_usd`,format(`view_product_price_usd`.`amount`,2,'de_DE') AS `amount_formated_usd`,format(`dbo_administration_product_costs`.`cost_bs`,2,'de_DE') AS `cost_bs`,format(`dbo_administration_product_costs`.`cost_usd`,2,'de_DE') AS `cost_usd`,`view_product_price_usd`.`updatedAt` AS `updateAt_usd`,if((`view_product_price_usd`.`updatedAt` > `view_product_price_bs`.`updatedAt`),`view_product_price_usd`.`updatedAt`,`view_product_price_bs`.`updatedAt`) AS `updatedAt_ord`,if((`view_product_price_usd`.`updatedAt` > `view_product_price_bs`.`updatedAt`),`view_product_price_usd`.`name`,`view_product_price_bs`.`name`) AS `user_name`,date_format(`view_product_price_usd`.`updatedAt`,'%d-%m-%Y %r') AS `updateAt_usd_formated` from (((`dbo_storage_products` join `view_product_price_bs` on((`dbo_storage_products`.`id` = `view_product_price_bs`.`product_id`))) join `view_product_price_usd` on((`dbo_storage_products`.`id` = `view_product_price_usd`.`product_id`))) left join `dbo_administration_product_costs` on(((`dbo_storage_products`.`id` = `dbo_administration_product_costs`.`product_id`) and (`dbo_administration_product_costs`.`active` = 1)))) order by `dbo_storage_products`.`description` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_my_company_accounts`
--

/*!50001 DROP VIEW IF EXISTS `view_my_company_accounts`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_my_company_accounts` AS select `damca`.`id` AS `id`,`dcc`.`id` AS `currency_id`,`dfb`.`name` AS `bank_name`,concat(left(`damca`.`number_account`,4),'-',substr(`damca`.`number_account`,5,4),'-',substr(`damca`.`number_account`,9,2),'-',right(`damca`.`number_account`,10)) AS `number_account`,`dcc`.`name` AS `currency_name`,`dsu`.`username` AS `user_name`,date_format(`damca`.`createdAt`,'%d-%m-%Y') AS `createdAt` from (((`dbo_administration_my_company_accounts` `damca` join `dbo_finance_banks` `dfb` on((`damca`.`bank_id` = `dfb`.`id`))) join `dbo_config_currencies` `dcc` on((`damca`.`currency_id` = `dcc`.`id`))) join `dbo_system_users` `dsu` on((`damca`.`user_id` = `dsu`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_pay_to_clients`
--

/*!50001 DROP VIEW IF EXISTS `view_pay_to_clients`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_pay_to_clients` AS select `dai`.`invoice_number` AS `invoice_number`,`dai`.`saleorder_number` AS `saleorder_number`,`dfptc`.`reference` AS `reference`,concat(`dcit`.`name`,`dsc`.`identification_number`,' ',`dsc`.`name`,' ',`dsc`.`last_name`) AS `client_name`,`dfb`.`name` AS `bank_name`,`dfpt`.`name` AS `payment_type_name`,format(`dcer`.`exchange_rate`,2,'de_DE') AS `exchange_rate`,format((`dfptc`.`amount` / `dcer`.`exchange_rate`),2,'de_DE') AS `amount_usd`,format(`dfptc`.`amount`,2,'de_DE') AS `amount_bs`,date_format(`dfptc`.`createdAt`,'%d-%m-%Y') AS `createdAt` from (((((((`dbo_finance_pay_to_clients` `dfptc` join `dbo_administration_invoices` `dai` on((`dfptc`.`invoice_id` = `dai`.`id`))) join `dbo_sales_clients` `dsc` on((`dai`.`client_id` = `dsc`.`id`))) join `dbo_config_identifications_types` `dcit` on((`dsc`.`identification_type_id` = `dcit`.`id`))) join `dbo_system_users` `dsu` on((`dfptc`.`user_id` = `dsu`.`id`))) join `dbo_finance_banks` `dfb` on((`dfptc`.`bank_id` = `dfb`.`id`))) join `dbo_config_exchange_rates` `dcer` on((`dfptc`.`exchange_rate_id` = `dcer`.`id`))) join `dbo_finance_pay_types` `dfpt` on((`dfptc`.`pay_type_id` = `dfpt`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_payment_expenses`
--

/*!50001 DROP VIEW IF EXISTS `view_payment_expenses`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_payment_expenses` AS select `dape`.`id` AS `id`,`dst`.`control_number` AS `control_number`,`dst`.`invoice_number` AS `invoice_number`,if(`dape`.`company_acc_id`,`dfbo`.`name`,'Caja Chica') AS `origin_bank`,concat('****',right(`damca`.`number_account`,4)) AS `origin_bank_number`,`dfbd`.`name` AS `destination_bank`,concat('****',right(`daca`.`number_account`,4)) AS `destination_bank_number`,format(`dape`.`amount`,2,'de_DE') AS `amount`,`dcc2`.`name` AS `currency`,`dcc`.`name` AS `provider`,`dfpes`.`name` AS `status`,`dape`.`reference` AS `reference`,concat(`dsu`.`name`,' ',`dsu`.`last_name`) AS `user_name`,date_format(`dape`.`payment_date`,'%d-%m-%Y') AS `payment_date`,date_format(`dape`.`createdAt`,'%d-%m-%Y %r') AS `createdAt` from (((((((((`dbo_administration_payment_expenses` `dape` join `dbo_config_companies` `dcc` on((`dape`.`provider_id` = `dcc`.`id`))) join `dbo_config_currencies` `dcc2` on((`dcc2`.`id` = `dape`.`currency_id`))) join `dbo_system_users` `dsu` on((`dape`.`user_id` = `dsu`.`id`))) join `dbo_storage_transactions` `dst` on((`dst`.`id` = `dape`.`transaction_id`))) join `dbo_finance_payment_expense_statuses` `dfpes` on((`dfpes`.`id` = `dape`.`status_id`))) left join `dbo_administration_my_company_accounts` `damca` on((`dape`.`company_acc_id` = `damca`.`id`))) left join `dbo_finance_banks` `dfbo` on((`damca`.`bank_id` = `dfbo`.`id`))) left join `dbo_administration_company_accounts` `daca` on((`dape`.`company_acc_id` = `daca`.`id`))) left join `dbo_finance_banks` `dfbd` on((`daca`.`bank_id` = `dfbd`.`id`))) order by date_format(`dape`.`createdAt`,'%d-%m-%Y %r') desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_payment_types`
--

/*!50001 DROP VIEW IF EXISTS `view_payment_types`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_payment_types` AS select `dbo_finance_payment_types`.`id` AS `id`,`dbo_finance_payment_types`.`name` AS `name` from `dbo_finance_payment_types` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_payments`
--

/*!50001 DROP VIEW IF EXISTS `view_payments`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_payments` AS select `dbo_finance_payments`.`id` AS `id`,`dbo_finance_payments`.`amount` AS `amount`,`dbo_finance_payments`.`ref` AS `ref`,`dbo_finance_payments`.`payment_type_id` AS `payment_type_id`,`dbo_finance_payments`.`bank_id` AS `bank_id`,`dbo_finance_payments`.`currency_id` AS `currency_id`,`dbo_finance_payments`.`invoice_id` AS `invoice_id`,`dbo_finance_banks`.`name` AS `bank_name`,`dbo_config_currencies`.`name` AS `currency_name`,`dbo_config_currencies`.`abbreviation` AS `abbreviation`,`dbo_finance_payment_types`.`name` AS `payment_name` from (((`dbo_finance_payments` join `dbo_finance_banks` on((`dbo_finance_payments`.`bank_id` = `dbo_finance_banks`.`id`))) join `dbo_finance_payment_types` on((`dbo_finance_payments`.`payment_type_id` = `dbo_finance_payment_types`.`id`))) join `dbo_config_currencies` on((`dbo_finance_payments`.`currency_id` = `dbo_config_currencies`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_payments_grid`
--

/*!50001 DROP VIEW IF EXISTS `view_payments_grid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_payments_grid` AS select `P`.`id` AS `id`,`P`.`amount` AS `amount`,`CRCP`.`cash_register_close_id` AS `cash_register_close_id`,concat(convert(format(`P`.`amount`,2,'de_DE') using utf8mb3),`dbo_config_currencies`.`abbreviation`) AS `amount_formated`,concat(`dbo_config_identifications_types`.`name`,'-',`dbo_sales_clients`.`identification_number`,' ',`dbo_sales_clients`.`name`,' ') AS `id_name`,date_format(`P`.`createdAt`,'%r') AS `createdAt_h`,date_format(`P`.`createdAt`,'%d-%m-%Y %r') AS `createdAt`,`dbo_administration_invoices`.`invoice_number` AS `invoice_number`,`dbo_administration_invoices`.`saleorder_number` AS `saleorder_number`,`P`.`ref` AS `ref`,concat(convert(format(`dbo_administration_invoices`.`total`,2,'de_DE') using utf8mb3),`IC`.`abbreviation`) AS `total_formated`,concat(format((`dbo_administration_invoices`.`total` / `ER`.`exchange_rate`),2,'de_DE'),'$') AS `total_formated_$`,format(`ER`.`exchange_rate`,2,'de_DE') AS `exchange_rate`,format(`ER`.`exchange_rate`,2,'de_DE') AS `exchange_rate_formated`,`dbo_system_users`.`name` AS `user_name`,if((`P`.`deposit` = true),'ABONO','PAGO') AS `deposit`,`dbo_administration_invoices`.`finance_status_id` AS `finance_status_id`,`dfb`.`name` AS `bank_name`,`dbo_config_currencies`.`name` AS `currency_name`,`dbo_finance_payment_types`.`name` AS `type_name` from ((((((((((`dbo_finance_payments` `P` join `dbo_sales_clients` on((`P`.`client_id` = `dbo_sales_clients`.`id`))) join `dbo_config_identifications_types` on((`dbo_sales_clients`.`identification_type_id` = `dbo_config_identifications_types`.`id`))) join `dbo_config_currencies` on((`P`.`currency_id` = `dbo_config_currencies`.`id`))) join `dbo_finance_payment_types` on((`P`.`payment_type_id` = `dbo_finance_payment_types`.`id`))) join `dbo_administration_invoices` on((`P`.`invoice_id` = `dbo_administration_invoices`.`id`))) join `dbo_config_currencies` `IC` on((`dbo_administration_invoices`.`currency_id` = `IC`.`id`))) join `dbo_config_exchange_rates` `ER` on((`ER`.`id` = `P`.`exchange_rate_id`))) join `dbo_system_users` on((`P`.`user_id` = `dbo_system_users`.`id`))) join `dbo_pos_cash_register_close_payments` `CRCP` on((`P`.`id` = `CRCP`.`payment_id`))) join `dbo_finance_banks` `dfb` on((`dfb`.`id` = `P`.`bank_id`))) order by `P`.`createdAt` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_preview_update_massives`
--

/*!50001 DROP VIEW IF EXISTS `view_preview_update_massives`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_preview_update_massives` AS select `preview_update_massives`.`id` AS `id`,`preview_update_massives`.`amount_raw` AS `amount_raw`,`preview_update_massives`.`new_amount_raw` AS `new_amount_raw`,`preview_update_massives`.`amount` AS `amount`,`preview_update_massives`.`new_amount` AS `new_amount`,`preview_update_massives`.`tax_id` AS `tax_id`,`preview_update_massives`.`exchange_rate_id` AS `exchange_rate_id`,`preview_update_massives`.`old_exchange_rate_id` AS `old_exchange_rate_id`,`preview_update_massives`.`currency_id` AS `currency_id`,`preview_update_massives`.`product_id` AS `product_id`,`preview_update_massives`.`abbreviation` AS `abbreviation`,`preview_update_massives`.`description` AS `description`,concat(`preview_update_massives`.`amount`,`preview_update_massives`.`abbreviation`) AS `amount_currency`,concat(`preview_update_massives`.`new_amount`,`preview_update_massives`.`abbreviation`) AS `new_amount_currency`,`preview_update_massives`.`code` AS `code`,`preview_update_massives`.`code_bar` AS `code_bar`,`preview_update_massives`.`percentage_new` AS `percentage_new`,concat(format((`preview_update_massives`.`percentage_new` * 100),2,'de_DE'),' %') AS `percentage` from `preview_update_massives` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_price_types_client`
--

/*!50001 DROP VIEW IF EXISTS `view_price_types_client`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_price_types_client` AS select `dbo_sales_client_price_types`.`id` AS `id`,`dbo_sales_client_price_types`.`name` AS `name`,`dbo_sales_client_price_types`.`percentage` AS `percen`,concat(round((`dbo_sales_client_price_types`.`percentage` * 100),2),'%') AS `percentage` from `dbo_sales_client_price_types` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_price_types_product`
--

/*!50001 DROP VIEW IF EXISTS `view_price_types_product`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_price_types_product` AS select `dbo_administration_product_price_types`.`id` AS `id`,`dbo_administration_product_price_types`.`name` AS `name`,format((`dbo_administration_product_price_types`.`percentage` * 100),2,'de_DE') AS `percentage` from `dbo_administration_product_price_types` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_product_categories`
--

/*!50001 DROP VIEW IF EXISTS `view_product_categories`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_product_categories` AS select `dsp`.`id` AS `id`,`dsp`.`description` AS `product`,group_concat(`dsc`.`name` order by `dsc`.`name` ASC separator ', ') AS `category`,group_concat(`dss`.`name` order by `dsc`.`name` ASC separator ', ') AS `subcategory` from (((`dbo_storage_product_subcategories` `dsps` join `dbo_storage_products` `dsp` on((`dsps`.`product_id` = `dsp`.`id`))) join `dbo_storage_subcategories` `dss` on((`dsps`.`subcategory_id` = `dss`.`id`))) join `dbo_storage_categories` `dsc` on((`dss`.`category_id` = `dsc`.`id`))) group by `dsps`.`product_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_product_price_bs`
--

/*!50001 DROP VIEW IF EXISTS `view_product_price_bs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_product_price_bs` AS select `PA`.`id` AS `id`,`PA`.`amount` AS `amount`,format(`PA`.`amount`,2,'de_DE') AS `amount_formated`,`PA`.`product_id` AS `product_id`,`PA`.`user_id` AS `user_id`,`dbo_system_users`.`name` AS `name`,`dbo_system_users`.`last_name` AS `last_name`,`PA`.`updatedAt` AS `updatedAt` from (`dbo_administration_products_price_amounts` `PA` join `dbo_system_users` on((`dbo_system_users`.`id` = `PA`.`user_id`))) where (`PA`.`currency_id` = 2) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_product_price_usd`
--

/*!50001 DROP VIEW IF EXISTS `view_product_price_usd`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_product_price_usd` AS select `PA`.`id` AS `id`,`PA`.`amount` AS `amount`,format(`PA`.`amount`,2,'de_DE') AS `amount_formated`,`PA`.`product_id` AS `product_id`,`PA`.`user_id` AS `user_id`,`dbo_system_users`.`name` AS `name`,`dbo_system_users`.`last_name` AS `last_name`,`PA`.`updatedAt` AS `updatedAt` from (`dbo_administration_products_price_amounts` `PA` join `dbo_system_users` on((`dbo_system_users`.`id` = `PA`.`user_id`))) where (`PA`.`currency_id` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_products_solds`
--

/*!50001 DROP VIEW IF EXISTS `view_products_solds`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_products_solds` AS select `dbo_storage_products`.`id` AS `product_id`,`dbo_storage_products`.`code_bar` AS `code_bar`,`dbo_storage_products`.`code` AS `code`,`dbo_storage_products`.`description` AS `description`,`dbo_administration_invoices_items`.`quantity` AS `quantity`,`dbo_administration_invoices_items`.`createdAt` AS `date_sould` from ((`dbo_administration_invoices_items` join `dbo_storage_products` on((`dbo_storage_products`.`id` = `dbo_administration_invoices_items`.`product_id`))) join `dbo_administration_invoices` on((`dbo_administration_invoices_items`.`invoice_id` = `dbo_administration_invoices`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_purchases`
--

/*!50001 DROP VIEW IF EXISTS `view_purchases`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_purchases` AS select `dst`.`id` AS `id`,`dst`.`number` AS `number`,`dst`.`control_number` AS `control_number`,`dst`.`company_id` AS `company_id`,`dst`.`status_id` AS `status_id`,`dccomp`.`name` AS `name_company`,`dsts`.`name` AS `status`,`dsiet`.`name` AS `entry_types_name`,`dct`.`observation` AS `observation`,`dst`.`total_quantity` AS `total_quantity`,`dst`.`total_product` AS `total_product`,format(`dst`.`subtotal`,2,'de_DE') AS `subtotal`,format(`dst`.`tax_amount`,2,'de_DE') AS `tax`,format(`dst`.`total`,2,'de_DE') AS `total`,`dst`.`invoice_number` AS `invoice_number`,`dcc`.`name` AS `currency`,concat(`dsu`.`name`,' ',`dsu`.`last_name`) AS `user`,format(`dcer`.`exchange_rate`,2,'de_DE') AS `exchange_rate`,format(`dst`.`exchange_rate_provider`,2,'de_DE') AS `exchange_rate_provider`,`dac`.`name` AS `credit_days`,date_format(`dst`.`expire_date_transaction`,'%d/%m/%Y') AS `expire_date_transaction`,date_format(`dst`.`transaction_date`,'%d/%m/%Y') AS `transaction_date`,date_format(`dst`.`createdAt`,'%d/%m/%Y %H:%i:%s') AS `createdAt`,`dstps`.`name` AS `status_pay_name`,format(`dst`.`total_pay`,2,'de_DE') AS `total_pending`,date_format(`dst`.`pay_complete_day`,'%d/%m/%Y %H:%i:%s') AS `pay_complete_day` from (((((((((`dbo_storage_transactions` `dst` join `dbo_storage_transaction_statuses` `dsts` on((`dst`.`status_id` = `dsts`.`id`))) join `dbo_storage_inventory_entry_types` `dsiet` on((`dst`.`entry_type_id` = `dsiet`.`id`))) join `dbo_config_currencies` `dcc` on((`dcc`.`id` = `dst`.`currency_id`))) join `dbo_config_exchange_rates` `dcer` on((`dcer`.`id` = `dst`.`exchange_rate_id`))) join `dbo_system_users` `dsu` on((`dst`.`user_id` = `dsu`.`id`))) left join `dbo_config_taxes` `dct` on((`dst`.`tax_id` = `dct`.`id`))) left join `dbo_config_companies` `dccomp` on((`dst`.`company_id` = `dccomp`.`id`))) left join `dbo_administration_creditdays` `dac` on((`dac`.`id` = `dst`.`creditday_id`))) left join `dbo_storage_transaction_pay_statuses` `dstps` on((`dstps`.`id` = `dst`.`status_pay_id`))) order by `dst`.`id` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_refunds_index`
--

/*!50001 DROP VIEW IF EXISTS `view_refunds_index`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_refunds_index` AS select `dbo_administration_refunds`.`id` AS `id`,`dbo_administration_refunds`.`invoice_id` AS `invoice_id`,`dbo_administration_refunds`.`refunds_status_id` AS `refunds_status_id`,format(`dbo_administration_refunds`.`total_product`,0) AS `total_product`,format(`dbo_administration_refunds`.`total_quantity`,0) AS `total_quantity`,format(`dbo_administration_refunds`.`subtotal`,2) AS `subtotal`,format(`dbo_administration_refunds`.`tax_amount`,2) AS `tax_amount`,format(`dbo_administration_refunds`.`total`,2) AS `total`,`dbo_administration_invoices`.`invoice_number` AS `invoice_number`,`dbo_administration_invoices`.`saleorder_number` AS `saleorder_number`,concat(`dbo_sales_clients`.`name`,' ',`dbo_sales_clients`.`last_name`) AS `client`,`dbo_refunds_statuses`.`name` AS `refunds_status`,`dbo_finance_creditnotes`.`id` AS `creditnote_id` from ((((`dbo_administration_refunds` join `dbo_administration_invoices` on((`dbo_administration_invoices`.`id` = `dbo_administration_refunds`.`invoice_id`))) join `dbo_sales_clients` on((`dbo_sales_clients`.`id` = `dbo_administration_refunds`.`client_id`))) join `dbo_refunds_statuses` on((`dbo_refunds_statuses`.`id` = `dbo_administration_refunds`.`refunds_status_id`))) left join `dbo_finance_creditnotes` on(((`dbo_finance_creditnotes`.`creditnote_type_id` = '1') and (`dbo_finance_creditnotes`.`invoice_id` = `dbo_administration_refunds`.`invoice_id`)))) order by `dbo_administration_refunds`.`id` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_selected_payments_grid`
--

/*!50001 DROP VIEW IF EXISTS `view_selected_payments_grid`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_selected_payments_grid` AS select `P`.`id` AS `id`,`P`.`amount` AS `amount`,format(`P`.`amount`,2,'de_DE') AS `amount_formated`,concat(`dbo_config_identifications_types`.`name`,'-',`dbo_sales_clients`.`identification_number`,' ',`dbo_sales_clients`.`name`,' ') AS `id_name`,date_format(`P`.`createdAt`,'%r') AS `createdAt_h`,date_format(`P`.`createdAt`,'%d-%m-%Y %r') AS `createdAt`,`P`.`ref` AS `ref`,`dbo_config_currencies`.`abbreviation` AS `abbreviation`,format(`ER`.`exchange_rate`,2,'de_DE') AS `exchange_rate`,format(`ER`.`exchange_rate`,2,'de_DE') AS `exchange_rate_formated`,`dbo_system_users`.`name` AS `user_name`,`dfb`.`name` AS `bank_name`,`dbo_config_currencies`.`name` AS `currency_name`,`dfbpt`.`display_name` AS `bank_payment_type`,`dbo_finance_payment_types`.`name` AS `type_name` from ((((((((`dbo_finance_selected_payments` `P` left join `dbo_sales_clients` on((`P`.`client_id` = `dbo_sales_clients`.`id`))) join `dbo_config_identifications_types` on((`dbo_sales_clients`.`identification_type_id` = `dbo_config_identifications_types`.`id`))) join `dbo_config_currencies` on((`P`.`currency_id` = `dbo_config_currencies`.`id`))) join `dbo_config_exchange_rates` `ER` on((`ER`.`id` = `P`.`exchange_rate_id`))) join `dbo_system_users` on((`P`.`user_id` = `dbo_system_users`.`id`))) join `dbo_finance_banks` `dfb` on((`dfb`.`id` = `P`.`bank_id`))) join `dbo_finance_bank_payment_types` `dfbpt` on((`dfbpt`.`id` = `P`.`payment_type_id`))) join `dbo_finance_payment_types` on((`P`.`payment_type_id` = `dbo_finance_payment_types`.`id`))) order by `P`.`createdAt` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_subcategories`
--

/*!50001 DROP VIEW IF EXISTS `view_subcategories`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_subcategories` AS select `dbo_storage_subcategories`.`id` AS `id`,`dbo_storage_subcategories`.`name` AS `name`,`dbo_storage_categories`.`name` AS `category`,`dbo_storage_subcategories`.`createdAt` AS `createdAt`,`dbo_storage_subcategories`.`updatedAt` AS `updatedAt` from (`dbo_storage_subcategories` join `dbo_storage_categories` on((`dbo_storage_subcategories`.`category_id` = `dbo_storage_categories`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_taxes`
--

/*!50001 DROP VIEW IF EXISTS `view_taxes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_taxes` AS select `dbo_config_taxes`.`id` AS `id`,`dbo_config_taxes`.`percentage` AS `percentage`,`dbo_config_taxes`.`observation` AS `observation` from `dbo_config_taxes` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_total_cash_bs`
--

/*!50001 DROP VIEW IF EXISTS `view_total_cash_bs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_total_cash_bs` AS select `CRCAC`.`cash_register_close_id` AS `cash_register_close_id`,format(`CRCAC`.`total`,2,'de_DE') AS `total_bs`,format(`CRCAC`.`total_invoices`,2,'de_DE') AS `total_invoices_bs`,format(`CRCAC`.`subtotal`,2,'de_DE') AS `subtotal_bs`,format(`CRCAC`.`electronicTotal`,2,'de_DE') AS `electronicTotal_bs`,format(`CRCAC`.`cashTotal`,2,'de_DE') AS `cashTotal_bs`,format(`CRCAC`.`tax`,2,'de_DE') AS `tax_bs`,format(`CRCAC`.`tax_to_pay`,2,'de_DE') AS `tax_to_pay_bs`,format(`CRCAC`.`retention_tax`,2,'de_DE') AS `retention_tax_bs` from `dbo_pos_cash_register_closes_all_currencies` `CRCAC` where (`CRCAC`.`currency_id` = 2) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_total_cash_bs_footer`
--

/*!50001 DROP VIEW IF EXISTS `view_total_cash_bs_footer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_total_cash_bs_footer` AS select `CRCAC`.`cash_register_close_id` AS `cash_register_close_id`,`CRCAC`.`total` AS `total_bs`,`CRCAC`.`total_invoices` AS `total_invoices_bs`,`CRCAC`.`subtotal` AS `subtotal_bs`,`CRCAC`.`electronicTotal` AS `electronicTotal_bs`,`CRCAC`.`cashTotal` AS `cashTotal_bs`,`CRCAC`.`tax` AS `tax_bs`,`CRCAC`.`tax_to_pay` AS `tax_to_pay_bs`,`CRCAC`.`retention_tax` AS `retention_tax_bs` from `dbo_pos_cash_register_closes_all_currencies` `CRCAC` where (`CRCAC`.`currency_id` = 2) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_total_cash_usd`
--

/*!50001 DROP VIEW IF EXISTS `view_total_cash_usd`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_total_cash_usd` AS select `CRCAC`.`cash_register_close_id` AS `cash_register_close_id`,format(`CRCAC`.`total`,2,'de_DE') AS `total_usd`,format(`CRCAC`.`total_invoices`,2,'de_DE') AS `total_invoices_usd`,format(`CRCAC`.`subtotal`,2,'de_DE') AS `subtotal_usd`,format(`CRCAC`.`electronicTotal`,2,'de_DE') AS `electronicTotal_usd`,format(`CRCAC`.`cashTotal`,2,'de_DE') AS `cashTotal_usd`,format(`CRCAC`.`tax`,2,'de_DE') AS `tax_usd`,format(`CRCAC`.`tax_to_pay`,2,'de_DE') AS `tax_to_pay_usd`,format(`CRCAC`.`retention_tax`,2,'de_DE') AS `retention_tax_usd` from `dbo_pos_cash_register_closes_all_currencies` `CRCAC` where (`CRCAC`.`currency_id` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_total_cash_usd_footer`
--

/*!50001 DROP VIEW IF EXISTS `view_total_cash_usd_footer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_total_cash_usd_footer` AS select `CRCAC`.`cash_register_close_id` AS `cash_register_close_id`,`CRCAC`.`total` AS `total_usd`,`CRCAC`.`total_invoices` AS `total_invoices_usd`,`CRCAC`.`subtotal` AS `subtotal_usd`,`CRCAC`.`electronicTotal` AS `electronicTotal_usd`,`CRCAC`.`cashTotal` AS `cashTotal_usd`,`CRCAC`.`tax` AS `tax_usd`,`CRCAC`.`tax_to_pay` AS `tax_to_pay_usd`,`CRCAC`.`retention_tax` AS `retention_tax_usd` from `dbo_pos_cash_register_closes_all_currencies` `CRCAC` where (`CRCAC`.`currency_id` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_totals_cash`
--

/*!50001 DROP VIEW IF EXISTS `view_totals_cash`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_totals_cash` AS select (`CRCAC`.`id` * 1000) AS `CRC_id`,date_format(`CRCAC`.`closeDate`,'%d-%m-%Y %r') AS `closeDate`,date_format(`CRC`.`createdAt`,'%d-%m-%Y %r') AS `createdAt`,`CRCAC`.`user_id` AS `user_id`,`User`.`name` AS `name`,`TCB`.`total_bs` AS `total_bs`,`TCB`.`total_invoices_bs` AS `total_invoices_bs`,`TCB`.`subtotal_bs` AS `subtotal_bs`,`TCB`.`tax_bs` AS `tax_bs`,`TCB`.`tax_to_pay_bs` AS `tax_to_pay_bs`,`TCB`.`retention_tax_bs` AS `retention_tax_bs`,`TCB`.`electronicTotal_bs` AS `electronicTotal_bs`,`TCB`.`cashTotal_bs` AS `cashTotal_bs`,`TCU`.`total_usd` AS `total_usd`,`TCU`.`total_invoices_usd` AS `total_invoices_usd`,`TCU`.`subtotal_usd` AS `subtotal_usd`,`TCU`.`tax_usd` AS `tax_usd`,`TCU`.`tax_to_pay_usd` AS `tax_to_pay_usd`,`TCU`.`retention_tax_usd` AS `retention_tax_usd`,`TCU`.`electronicTotal_usd` AS `electronicTotal_usd`,`TCU`.`cashTotal_usd` AS `cashTotal_usd` from ((((`dbo_pos_cash_register_closes_all_currencies` `CRCAC` join `dbo_system_users` `User` on((`CRCAC`.`user_id` = `User`.`id`))) join `view_total_cash_bs` `TCB` on((`TCB`.`cash_register_close_id` = `CRCAC`.`cash_register_close_id`))) join `view_total_cash_usd` `TCU` on((`TCU`.`cash_register_close_id` = `CRCAC`.`cash_register_close_id`))) join `dbo_pos_cash_register_closes` `CRC` on((`CRCAC`.`cash_register_close_id` = `CRC`.`id`))) group by `CRCAC`.`cash_register_close_id` order by `CRCAC`.`id` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_totals_cash_footer`
--

/*!50001 DROP VIEW IF EXISTS `view_totals_cash_footer`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_totals_cash_footer` AS select (`CRCAC`.`id` * 1000) AS `CRC_id`,date_format(`CRCAC`.`closeDate`,'%d-%m-%Y %r') AS `closeDate`,date_format(`CRC`.`createdAt`,'%d-%m-%Y %r') AS `createdAt`,`CRCAC`.`user_id` AS `user_id`,`User`.`name` AS `name`,`TCB`.`total_bs` AS `total_bs`,`TCB`.`total_invoices_bs` AS `total_invoices_bs`,`TCB`.`subtotal_bs` AS `subtotal_bs`,`TCB`.`tax_bs` AS `tax_bs`,`TCB`.`tax_to_pay_bs` AS `tax_to_pay_bs`,`TCB`.`retention_tax_bs` AS `retention_tax_bs`,`TCB`.`electronicTotal_bs` AS `electronicTotal_bs`,`TCB`.`cashTotal_bs` AS `cashTotal_bs`,`TCU`.`total_usd` AS `total_usd`,`TCU`.`total_invoices_usd` AS `total_invoices_usd`,`TCU`.`subtotal_usd` AS `subtotal_usd`,`TCU`.`tax_usd` AS `tax_usd`,`TCU`.`tax_to_pay_usd` AS `tax_to_pay_usd`,`TCU`.`retention_tax_usd` AS `retention_tax_usd`,`TCU`.`electronicTotal_usd` AS `electronicTotal_usd`,`TCU`.`cashTotal_usd` AS `cashTotal_usd` from ((((`dbo_pos_cash_register_closes_all_currencies` `CRCAC` join `dbo_system_users` `User` on((`CRCAC`.`user_id` = `User`.`id`))) join `view_total_cash_bs_footer` `TCB` on((`TCB`.`cash_register_close_id` = `CRCAC`.`cash_register_close_id`))) join `view_total_cash_usd_footer` `TCU` on((`TCU`.`cash_register_close_id` = `CRCAC`.`cash_register_close_id`))) join `dbo_pos_cash_register_closes` `CRC` on((`CRCAC`.`cash_register_close_id` = `CRC`.`id`))) group by `CRCAC`.`cash_register_close_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_transactions`
--

/*!50001 DROP VIEW IF EXISTS `view_transactions`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_transactions` AS select (case when (`dbo_storage_transactions`.`entry_type_id` = 17) then 'NOTA DE DÉBITO' when (`dbo_storage_transactions`.`entry_type_id` = 16) then 'NOTA DE CRÉDITO' when (`dbo_storage_transactions`.`entry_type_id` = 2) then 'FACTURA' when (`dbo_storage_transactions`.`entry_type_id` = 13) then 'FACTURA GASTOS' when (`dbo_storage_transactions`.`entry_type_id` = 14) then 'FACTURA BIENES' when (`dbo_storage_transactions`.`entry_type_id` = 15) then 'FACTURA SERVICIOS' end) AS `document_type`,`dbo_storage_transactions`.`id` AS `id`,`dbo_storage_transactions`.`number` AS `number`,`dbo_storage_transactions`.`credit_note_number` AS `credit_note_number`,`dbo_storage_transactions`.`debit_note_number` AS `debit_note_number`,`dbo_storage_transactions`.`control_number` AS `control_number`,`dbo_storage_transactions`.`company_id` AS `company_id`,`dbo_storage_transactions`.`status_id` AS `status_id`,`dbo_system_users`.`name` AS `user`,`dbo_storage_transactions`.`exchange_rate_provider` AS `exchange_rate_provider`,`dbo_config_companies`.`name` AS `name_company`,`dbo_storage_transaction_statuses`.`name` AS `status`,`dbo_storage_inventory_entry_types`.`name` AS `entry_types_name`,date_format(`dbo_storage_transactions`.`createdAt`,'%d-%m-%Y') AS `createdAt`,if((`dbo_storage_transactions`.`creditday_id` > 1),'CREDITO','CONTADO') AS `credit_days`,`dbo_storage_transactions`.`updatedAt` AS `updatedAt`,`dbo_config_taxes`.`observation` AS `observation`,`dbo_storage_transactions`.`total_quantity` AS `total_quantity`,`dbo_storage_transactions`.`total_product` AS `total_product`,`dbo_storage_transactions`.`subtotal` AS `subtotal`,`dbo_storage_transactions`.`tax_amount` AS `tax`,`dbo_storage_transactions`.`total` AS `total`,`dbo_storage_transactions`.`invoice_number` AS `invoice_number`,`dbo_config_currencies`.`name` AS `currency`,date_format(`dbo_storage_transactions`.`expire_date_transaction`,'%d-%m-%Y') AS `expire_date_transaction`,date_format(`dbo_storage_transactions`.`transaction_date`,'%d-%m-%Y') AS `transaction_date`,format(`dbo_config_exchange_rates`.`exchange_rate`,2) AS `exchange_rate`,date_format(`dbo_storage_transactions`.`createdAt`,'%d-%m-%Y') AS `created_at` from (((((((`dbo_storage_transactions` join `dbo_storage_transaction_statuses` on((`dbo_storage_transactions`.`status_id` = `dbo_storage_transaction_statuses`.`id`))) join `dbo_storage_inventory_entry_types` on((`dbo_storage_transactions`.`entry_type_id` = `dbo_storage_inventory_entry_types`.`id`))) join `dbo_config_currencies` on((`dbo_config_currencies`.`id` = `dbo_storage_transactions`.`currency_id`))) join `dbo_config_exchange_rates` on((`dbo_config_exchange_rates`.`id` = `dbo_storage_transactions`.`exchange_rate_id`))) left join `dbo_config_taxes` on((`dbo_storage_transactions`.`tax_id` = `dbo_config_taxes`.`id`))) left join `dbo_config_companies` on((`dbo_storage_transactions`.`company_id` = `dbo_config_companies`.`id`))) left join `dbo_system_users` on((`dbo_system_users`.`id` = `dbo_storage_transactions`.`user_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_types_currencies`
--

/*!50001 DROP VIEW IF EXISTS `view_types_currencies`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_types_currencies` AS select `dbo_type_currencies`.`id` AS `id`,`dbo_type_currencies`.`name` AS `name` from `dbo_type_currencies` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_users`
--

/*!50001 DROP VIEW IF EXISTS `view_users`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_users` AS select `dbo_system_users`.`id` AS `id`,`dbo_system_users`.`username` AS `username`,`dbo_system_users`.`password` AS `password`,`dbo_system_users`.`name` AS `name`,`dbo_system_users`.`last_name` AS `last_name`,`dbo_system_users`.`rol_id` AS `rol_id`,`dbo_system_rols`.`name` AS `rol`,`dbo_system_users`.`createdAt` AS `createdAt`,`dbo_system_users`.`updatedAt` AS `updatedAt`,group_concat(`dbo_system_rols`.`name` order by `dbo_system_rols`.`name` ASC separator ', ') AS `user_roles` from ((`dbo_system_users` left join `dbo_system_user_roles` on((`dbo_system_users`.`id` = `dbo_system_user_roles`.`user_id`))) left join `dbo_system_rols` on((`dbo_system_rols`.`id` = `dbo_system_user_roles`.`role_id`))) group by `dbo_system_users`.`id` order by `dbo_system_users`.`id` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_users_types`
--

/*!50001 DROP VIEW IF EXISTS `view_users_types`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013  SQL SECURITY DEFINER */
/*!50001 VIEW `view_users_types` AS select `dbo_system_rols`.`id` AS `id`,`dbo_system_rols`.`name` AS `name` from `dbo_system_rols` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-17  3:03:13
